package com.organdonation.controller;

import com.organdonation.model.Hospital;
import com.organdonation.model.HospitalDAO;
import com.organdonation.model.Notification;
import com.organdonation.model.NotificationDAO;
import com.organdonation.view.HospitalDashboardView;
import com.organdonation.view.HospitalLoginView;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

public class HospitalLoginController {
    private HospitalLoginView view;
    private HospitalDAO model;
    private NotificationDAO notificationDAO;

    public HospitalLoginController(HospitalLoginView view, HospitalDAO model) {
        this.view = view;
        this.model = model;
        this.notificationDAO = new NotificationDAO();
        
        this.view.addLoginListener(new LoginListener());
        this.view.addRegisterHospitalListener(new RegisterHospitalListener());
        this.view.addBackListener(new BackListener());
        
        System.out.println("🏥 HospitalLoginController initialized");
    }

    class LoginListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String email = view.getEmail();
            String password = view.getPassword();

            System.out.println("🏥 Hospital login attempt: " + email);

            if (email.isEmpty() || password.isEmpty()) {
                view.showMessage("Please enter both email and password.");
                return;
            }

            Hospital hospital = model.validate(email, password);

            if (hospital != null) {
                System.out.println("✅ Hospital login successful: " + hospital.getName());
                view.showMessage("Login Successful! Welcome, " + hospital.getName() + ".");
                view.dispose();

                HospitalDashboardView dashboard = new HospitalDashboardView(hospital.getName());
                new HospitalDashboardController(dashboard, hospital); 
                dashboard.setVisible(true);
            } else {
                System.out.println("❌ Hospital login failed");
                view.showMessage("Invalid email or password.");
            }
        }
    }
    
    class RegisterHospitalListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String name = view.getHospitalName();
            String email = view.getRegisterEmail();
            String password = view.getRegisterPassword();
            String confirmPassword = view.getHospitalConfirmPassword();
            String pinCode = view.getPinCode();
            String district = view.getDistrict();
            String state = view.getHospitalState();

            System.out.println("🏥 Hospital registration: " + name);

            if (name.isEmpty() || email.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
                view.showMessage("Please fill all required fields.");
                return;
            }
            if (!password.equals(confirmPassword)) {
                view.showMessage("Passwords do not match.");
                return;
            }

            Hospital hospital = new Hospital();
            hospital.setName(name);
            hospital.setEmail(email);
            hospital.setPassword(password);
            
            if (model.registerHospital(hospital)) {
                System.out.println("✅ Hospital registered: " + name);
                view.showMessage("Hospital account created! Please log in.");
                
                Notification notif = new Notification();
                notif.setUserId("admin");
                notif.setUserType(Notification.UserType.admin);
                notif.setMessage("New Hospital Registered");
                notif.setDetails("Hospital: " + name + " (" + email + ")");
                notif.setUrgency(Notification.Urgency.low); 
                notificationDAO.createNotification(notif);
                
            } else {
                System.out.println("❌ Hospital registration failed");
                view.showMessage("Error creating account. Email might be in use.");
            }
        }
    }

    class BackListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            System.out.println("🔙 Back to Portal Selection from Hospital Login");
            view.dispose();
            NavigationManager.showLandingView();
        }
    }
}