package com.organdonation.controller;

/**
 * Central navigation manager to handle navigation between different views
 * This solves the back button and logout navigation issues
 */
public class NavigationManager {
    private static LandingController landingController;
    
    /**
     * Set the landing controller reference for navigation
     */
    public static void setLandingController(LandingController controller) {
        landingController = controller;
        System.out.println("📍 NavigationManager: LandingController set successfully");
    }
    
    /**
     * Show the landing view from anywhere in the application
     */
    public static void showLandingView() {
        System.out.println("📍 NavigationManager: Showing landing view");
        if (landingController != null) {
            landingController.showLandingView();
        } else {
            System.out.println("❌ NavigationManager: LandingController not set!");
            // Fallback - you could create a new landing view here if needed
        }
    }
    
    /**
     * Check if landing controller is available
     */
    public static boolean isLandingControllerSet() {
        return landingController != null;
    }
}