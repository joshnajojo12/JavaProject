package com.organdonation.controller;

import com.organdonation.model.Notification;
import com.organdonation.model.NotificationDAO;
import com.organdonation.view.NotificationBell;
import com.organdonation.view.NotificationPopup;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class NotificationController {
    private NotificationDAO notificationDAO;
    private NotificationBell notificationBell;
    private NotificationPopup notificationPopup;
    private String userId;
    private String userType;

    public NotificationController(NotificationBell bell, String userId, String userType) {
        this.notificationDAO = new NotificationDAO();
        this.notificationBell = bell;
        this.notificationPopup = new NotificationPopup();
        this.userId = userId;
        this.userType = userType;

        // Add listener to the bell icon
        this.notificationBell.addActionListener(new ShowNotificationsListener());
        
        // Add listener to the "Mark all as read" button in the popup
        this.notificationPopup.addMarkAllReadListener(new MarkAllReadListener());

        // Initial load
        updateNotificationCount();
    }

    /**
     * Fetches the unread count from the DAO and updates the bell UI.
     */
    public void updateNotificationCount() {
        int count = notificationDAO.getUnreadNotificationCount(userId, userType);
        notificationBell.setCount(count);
    }

    /**
     * Listener for when the bell icon is clicked.
     */
    class ShowNotificationsListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            // Fetch the latest unread notifications
            List<Notification> unreadNotifications = notificationDAO.getUnreadNotifications(userId, userType);
            
            // Update the popup panel with the new list
            notificationPopup.updateNotifications(unreadNotifications);
            
            // Show the popup relative to the bell button
            notificationPopup.show(notificationBell.getButton(), 0, notificationBell.getButton().getHeight());
        }
    }

    /**
     * Listener for the "Mark all as read" button.
     */
    class MarkAllReadListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            // Call DAO to mark all as read
            notificationDAO.markAllAsRead(userId, userType);
            
            // Update the count (should be 0)
            updateNotificationCount();
            
            // Hide the popup
            notificationPopup.hide();
        }
    }
}