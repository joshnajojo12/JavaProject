package com.organdonation.controller;

import com.organdonation.model.*;
import com.organdonation.view.AdminDashboardView;
import com.organdonation.view.LandingView;
import com.organdonation.view.MedicalReportDialog;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
// NEW IMPORTS FOR WINDOW LISTENER
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.List;

public class AdminDashboardController {
    private AdminDashboardView view;
    private DonorDAO donorDAO;
    private RecipientDAO recipientDAO;
    private MatchDAO matchDAO;
    private NotificationDAO notificationDAO;
    private NotificationController notificationController;
    
    // NEW: DAO for getting hospital info
    private HospitalDAO hospitalDAO;

    public AdminDashboardController(AdminDashboardView view) {
        this.view = view;
        this.donorDAO = new DonorDAO();
        this.recipientDAO = new RecipientDAO();
        this.matchDAO = new MatchDAO();
        this.notificationDAO = new NotificationDAO();
        
        // NEW: Initialize hospitalDAO
        this.hospitalDAO = new HospitalDAO(); 
        
        debugMatching();
        
        this.view.addApproveMatchListener(new ApproveMatchListener());
        this.view.addDeleteDonorListener(new DeleteDonorListener());
        this.view.addFindMatchListener(new FindMatchListener());
        this.view.addDeleteRecipientListener(new DeleteRecipientListener());
        // MODIFIED: View Listeners will now open forms/dialogs with refresh logic
        this.view.addViewDonorMedicalReportListener(new ViewDonorMedicalReportListener());
        this.view.addViewRecipientMedicalReportListener(new ViewRecipientMedicalReportListener());
        this.view.addLogoutListener(new LogoutListener());

        this.notificationController = new NotificationController(
            view.getNotificationBell(), 
            "admin", 
            Notification.UserType.admin.name()
        );

        refreshAllData(true);
    }

    private void debugMatching() {
        System.out.println("=== DEBUG MATCHING SYSTEM ===");
        matchDAO.debugDatabaseStatus();
        List<Recipient> recipients = recipientDAO.getAllRecipients();
        System.out.println("Total recipients in database: " + recipients.size());
        
        int waitingRecipients = 0;
        for (Recipient recipient : recipients) {
            if ("Waiting".equals(recipient.getStatus())) {
                waitingRecipients++;
                System.out.println("Waiting recipient: " + recipient.getName() + 
                                 " (Organ: " + recipient.getOrganNeeded() + 
                                 ", Blood: " + recipient.getBloodGroup() + 
                                 ", ID: " + recipient.getId() + ")");
                
                List<Match> matches = matchDAO.findMatchesForRecipient(recipient);
                System.out.println("Found " + matches.size() + " matches for " + recipient.getName());
                
                for (Match match : matches) {
                    System.out.println("  - Match: " + match.getDonorName() + " (ID: " + match.getDonorId() + ")");
                }
            }
        }
        System.out.println("Total waiting recipients: " + waitingRecipients);
        System.out.println("=== END DEBUG MATCHING SYSTEM ===");
    }

    private void refreshAllData(boolean clearMatches) { 
        loadDashboardData(); 
        loadDonorsTable(); 
        loadRecipientsTable(); 
        if(clearMatches) {
            loadMatchesTable(null);
        }
        notificationController.updateNotificationCount();
    }

    private void loadDashboardData() { 
        try {
            int totalDonors = donorDAO.getDonorCount();
            int totalRecipients = recipientDAO.getRecipientCount();
            int urgentRecipients = recipientDAO.getUrgentRecipientCount();
            int availableKidneyDonors = donorDAO.getAvailableDonorCountByOrgan("Kidney");
            int availableBoneMarrowDonors = donorDAO.getAvailableDonorCountByOrgan("Bone Marrow");
            int availableLiverDonors = donorDAO.getAvailableDonorCountByOrgan("Liver");
            int matchesCompleted = matchDAO.getCompletedMatchCount();
            
            view.updateDashboardStats(
                String.valueOf(totalDonors), 
                String.valueOf(totalRecipients), 
                String.valueOf(urgentRecipients),
                String.valueOf(availableKidneyDonors),
                String.valueOf(availableBoneMarrowDonors),
                String.valueOf(matchesCompleted),
                String.valueOf(availableLiverDonors)
            );
            
        } catch (Exception e) {
            e.printStackTrace();
            view.updateDashboardStats("0", "0", "0", "0", "0", "0", "0");
        }
    }

    private void loadDonorsTable() { 
        DefaultTableModel m = view.donorModel;
        m.setRowCount(0);
        List<Donor> l = donorDAO.getAllDonors();
        for(Donor o : l) {
            m.addRow(new Object[]{
                o.getId(), 
                o.getName(), 
                o.getAge(), 
                o.getBloodGroup(), 
                o.getOrganDonating(), 
                o.getStatus()
            });
        }
    }

    private void loadRecipientsTable() { 
        DefaultTableModel m = view.recipientModel;
        m.setRowCount(0);
        List<Recipient> l = recipientDAO.getAllRecipients();
        for(Recipient o : l) {
            m.addRow(new Object[]{
                o.getId(), 
                o.getName(), 
                o.getAge(), 
                o.getOrganNeeded(), 
                o.getUrgencyLevel(), 
                o.getStatus()
            });
        }
    }

    private void loadMatchesTable(List<Match> matches) { 
        DefaultTableModel m = view.matchModel;
        m.setRowCount(0);
        if(matches != null) {
            for(Match o : matches) {
                m.addRow(new Object[]{
                    o.getDonorId(), 
                    o.getDonorName(), 
                    o.getRecipientId(), 
                    o.getRecipientName(), 
                    o.getOrgan(), 
                    o.getStatus()
                });
            }
        }
    }

    class LogoutListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            int choice = JOptionPane.showConfirmDialog(
                view, 
                "Are you sure you want to logout from Admin Portal?", 
                "Confirm Logout", 
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE
            );
            
            if (choice == JOptionPane.YES_OPTION) {
                view.dispose();
                SwingUtilities.invokeLater(() -> {
                    // Use NavigationManager to show landing page
                    NavigationManager.showLandingView();
                });
            }
        }
    }
    class ApproveMatchListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            int selectedRow = view.getSelectedMatchRow();
            if (selectedRow >= 0) {
                int donorId = view.getDonorIdFromSelectedMatch(selectedRow); 
                int recipientId = view.getRecipientIdFromSelectedMatch(selectedRow);
                
                if (donorId <= 0) {
                    JOptionPane.showMessageDialog(view, 
                        "Invalid donor selection. Please select a valid match.",
                        "Invalid Selection", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                int choice = JOptionPane.showConfirmDialog(view, 
                    "Approve this match?\nDonor ID: " + donorId + " → Recipient ID: " + recipientId,
                    "Confirm Approval", JOptionPane.YES_NO_OPTION);
                    
                if (choice == JOptionPane.YES_OPTION) {
                    if (matchDAO.approveMatch(donorId, recipientId)) { 
                        JOptionPane.showMessageDialog(view, "Match approved successfully!"); 
                        createHospitalNotifications(donorId, recipientId);
                        refreshAllData(true); // Refresh is already here!
                    } else { 
                        JOptionPane.showMessageDialog(view, 
                            "Failed to approve match.\nCheck console for details.",
                            "Approval Failed", JOptionPane.ERROR_MESSAGE); 
                    }
                }
            } else { 
                JOptionPane.showMessageDialog(view, "Please select a match from the table first.", "No Selection", JOptionPane.WARNING_MESSAGE); 
            }
        }
    }

    // MODIFIED: This method now has safeguards
    private void createHospitalNotifications(int donorId, int recipientId) {
        Donor donor = donorDAO.getDonorById(donorId);
        Recipient recipient = recipientDAO.getRecipientById(recipientId);
        
        if (donor == null || recipient == null) {
            System.err.println("Could not create hospital notifications: donor or recipient not found.");
            return;
        }

        // Use the class-level hospitalDAO
        Hospital donorHospital = hospitalDAO.getHospitalById(donor.getHospitalId());
        Hospital recipientHospital = hospitalDAO.getHospitalById(recipient.getHospitalId());
        
        // --- 1. Notification for Donor's Hospital ---
        
        // NEW SAFEGUARD: Check if the donor's hospital ID is valid
        if (donor.getHospitalId() > 0 && donorHospital != null) {
            Notification donorNotif = new Notification();
            donorNotif.setUserId(String.valueOf(donor.getHospitalId()));
            donorNotif.setUserType(Notification.UserType.hospital);
            donorNotif.setMessage("Your donor (" + donor.getName() + ") has been matched!");
            donorNotif.setUrgency(Notification.Urgency.high);
            String donorNotifDetails = String.format(
                "Recipient: %s (Age: %d, Blood: %s)\nFrom: %s",
                recipient.getName(),
                recipient.getAge(),
                recipient.getBloodGroup(),
                recipientHospital != null ? recipientHospital.getName() : "Unknown Hospital"
            );
            donorNotif.setDetails(donorNotifDetails);
            notificationDAO.createNotification(donorNotif);
            System.out.println("Sent notification to Donor's hospital (ID: " + donor.getHospitalId() + ")");
        } else {
            // Log an error instead of sending to "hospital 0"
            System.err.println("Skipped sending notification to Donor's hospital: Invalid hospital_id (" + donor.getHospitalId() + ")");
        }


        // --- 2. Notification for Recipient's Hospital ---
        
        // NEW SAFEGUARD: Check if the recipient's hospital ID is valid
        if (recipient.getHospitalId() > 0 && recipientHospital != null) {
            Notification recipientNotif = new Notification();
            recipientNotif.setUserId(String.valueOf(recipient.getHospitalId()));
            recipientNotif.setUserType(Notification.UserType.hospital);
            recipientNotif.setMessage("Your recipient (" + recipient.getName() + ") has a match!");
            
            try {
                recipientNotif.setUrgency(Notification.Urgency.valueOf(recipient.getUrgencyLevel().toLowerCase()));
            } catch (Exception e) {
                recipientNotif.setUrgency(Notification.Urgency.high); // fallback
            }

            String recipientNotifDetails = String.format(
                "Donor: %s (Age: %d, Blood: %s)\nFrom: %s",
                donor.getName(),
                donor.getAge(),
                donor.getBloodGroup(),
                donorHospital != null ? donorHospital.getName() : "Unknown Hospital"
            );
            recipientNotif.setDetails(recipientNotifDetails);
            notificationDAO.createNotification(recipientNotif);
            System.out.println("Sent notification to Recipient's hospital (ID: " + recipient.getHospitalId() + ")");
        } else {
            // Log an error instead of sending to "hospital 0"
            System.err.println("Skipped sending notification to Recipient's hospital: Invalid hospital_id (" + recipient.getHospitalId() + ")");
        }
    }

    class DeleteDonorListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            int donorId = view.getSelectedDonorId();
            if (donorId != -1) {
                int choice = JOptionPane.showConfirmDialog(view, 
                    "Permanently delete this donor (ID: " + donorId + ")?",
                    "Confirm Deletion", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
                if (choice == JOptionPane.YES_OPTION) {
                    if (donorDAO.deleteDonor(donorId)) { 
                        JOptionPane.showMessageDialog(view, "Donor deleted successfully!"); 
                        refreshAllData(true);
                    } else { 
                        JOptionPane.showMessageDialog(view, "Failed to delete donor.", "Error", JOptionPane.ERROR_MESSAGE); 
                    }
                }
            } else { 
                JOptionPane.showMessageDialog(view, "Please select a donor from the table first.", "No Selection", JOptionPane.WARNING_MESSAGE); 
            }
        }
    }

    class FindMatchListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            int recipientId = view.getSelectedRecipientId();
            
            if (recipientId != -1) {
                Recipient recipient = recipientDAO.getRecipientById(recipientId);
                if (recipient != null) {
                    List<Match> potentialMatches = matchDAO.findMatchesForRecipient(recipient);
                    loadMatchesTable(potentialMatches);
                    
                    JTabbedPane tabbedPane = (JTabbedPane) view.getContentPane().getComponent(1);
                    tabbedPane.setSelectedIndex(3); 
                    
                    if (potentialMatches.isEmpty()) { 
                        JOptionPane.showMessageDialog(view, 
                            "No potential donors found for:\n" +
                            "Name: " + recipient.getName() + "\n" +
                            "Organ Needed: " + recipient.getOrganNeeded() + "\n" +
                            "Blood Group: " + recipient.getBloodGroup(),
                            "No Matches Found", 
                            JOptionPane.INFORMATION_MESSAGE);
                    } else { 
                        JOptionPane.showMessageDialog(view, 
                            "Found " + potentialMatches.size() + " potential donor(s)!\n\n" +
                            "Switched to 'Donor-Recipient Matching' tab to view details.",
                            "Matches Found", 
                            JOptionPane.INFORMATION_MESSAGE); 
                        
                        Notification notif = new Notification();
                        notif.setUserId("admin");
                        notif.setUserType(Notification.UserType.admin);
                        notif.setMessage(potentialMatches.size() + " new match(es) found for " + recipient.getName());
                        notif.setDetails("Recipient ID: " + recipient.getId() + ". Please review in the 'Matching' tab.");
                        notif.setUrgency(Notification.Urgency.high);
                        notificationDAO.createNotification(notif);
                        notificationController.updateNotificationCount();
                    }
                } else {
                    JOptionPane.showMessageDialog(view, 
                        "Error: Could not load recipient details from database.\n" +
                        "Recipient ID: " + recipientId,
                        "Database Error", 
                        JOptionPane.ERROR_MESSAGE);
                }
            } else { 
                JOptionPane.showMessageDialog(view, 
                    "Please select a recipient from the 'Manage Recipients' table first.",
                    "No Recipient Selected", 
                    JOptionPane.WARNING_MESSAGE); 
            }
        }
    }

    class DeleteRecipientListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            int recipientId = view.getSelectedRecipientId();

            if (recipientId != -1) {
                int choice = JOptionPane.showConfirmDialog(view, 
                    "Are you sure you want to permanently delete this recipient (ID: " + recipientId + ")?",
                    "Confirm Deletion", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

                if (choice == JOptionPane.YES_OPTION) {
                    if (recipientDAO.deleteRecipient(recipientId)) {
                        JOptionPane.showMessageDialog(view, "Recipient deleted successfully!");
                        refreshAllData(true);
                    } else {
                        JOptionPane.showMessageDialog(view, "Failed to delete recipient.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            } else {
                JOptionPane.showMessageDialog(view, 
                    "Please select a recipient from the table first.", 
                    "No Recipient Selected", 
                    JOptionPane.WARNING_MESSAGE);
            }
        }
    }
    
    class ViewDonorMedicalReportListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            int donorId = view.getSelectedDonorId();
            if (donorId != -1) {
                Donor donor = donorDAO.getDonorById(donorId);
                if (donor != null) {
                    MedicalReportDialog reportDialog = new MedicalReportDialog(view, donor);
                    
                    // NEW: Add listener to refresh data when the dialog closes
                    reportDialog.addWindowListener(new WindowAdapter() {
                        @Override
                        public void windowClosed(WindowEvent e) {
                            refreshAllData(false); // Refresh tables, no need to clear matches
                        }
                    });
                    
                    reportDialog.setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(view, 
                        "Could not load donor medical data.\n" +
                        "Donor ID: " + donorId,
                        "Database Error", 
                        JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(view, 
                    "Please select a donor from the table first to view their medical report.",
                    "No Donor Selected", 
                    JOptionPane.WARNING_MESSAGE);
            }
        }
    }
    
    class ViewRecipientMedicalReportListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            int recipientId = view.getSelectedRecipientId();
            if (recipientId != -1) {
                Recipient recipient = recipientDAO.getRecipientById(recipientId);
                if (recipient != null) {
                    MedicalReportDialog reportDialog = new MedicalReportDialog(view, recipient);
                    
                    // NEW: Add listener to refresh data when the dialog closes
                    reportDialog.addWindowListener(new WindowAdapter() {
                        @Override
                        public void windowClosed(WindowEvent e) {
                            refreshAllData(false); // Refresh tables, no need to clear matches
                        }
                    });
                    
                    reportDialog.setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(view, 
                        "Could not load recipient medical data.\n" +
                        "Recipient ID: " + recipientId,
                        "Database Error", 
                        JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(view, 
                    "Please select a recipient from the table first to view their medical report.",
                    "No Recipient Selected", 
                    JOptionPane.WARNING_MESSAGE);
            }
        }
    }
}