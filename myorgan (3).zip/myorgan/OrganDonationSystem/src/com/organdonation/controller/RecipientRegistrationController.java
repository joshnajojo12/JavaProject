package com.organdonation.controller;

import com.organdonation.model.Recipient;
import com.organdonation.model.RecipientDAO;
import com.organdonation.model.AgeValidator;
import com.organdonation.model.Notification;
import com.organdonation.model.NotificationDAO;
import com.organdonation.view.RecipientRegistrationView;
import javax.swing.JOptionPane;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class RecipientRegistrationController {
    private RecipientRegistrationView view;
    private RecipientDAO model;
    private int hospitalId;
    private NotificationDAO notificationDAO;
    private Integer editingRecipientId = null; // Tracks the ID of the recipient being edited

    public RecipientRegistrationController(RecipientRegistrationView view, int hospitalId) {
        this.view = view;
        this.model = new RecipientDAO();
        this.hospitalId = hospitalId;
        this.view.addRegisterListener(new RegisterListener());
        this.notificationDAO = new NotificationDAO();
    }
    
    // NEW: Constructor for EDIT mode
    public RecipientRegistrationController(RecipientRegistrationView view, int hospitalId, Recipient recipientToEdit) {
        this(view, hospitalId); // Call primary constructor
        this.editingRecipientId = recipientToEdit.getId(); // Set edit mode
        this.view.setRecipientDetailsForEdit(recipientToEdit); // *** Populates fields ***
    }


    class RegisterListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                Recipient recipient = view.getRecipientDetails(editingRecipientId);
                
                // Validate required fields
                if (recipient.getName().isEmpty() || recipient.getGender() == null) {
                    view.showMessage("Please fill in all required fields (Name, Gender, etc.).", "Validation Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                // Validate age for transplant
                if (!validateRecipientAge(recipient.getAge(), recipient.getOrganNeeded())) {
                    return;
                }
                
                // Validate BMI for transplant consideration
                if (!view.validateBMIForTransplant()) {
                    String bmiStatus = view.getCurrentBMIStatus();
                    String healthSummary = view.getHealthSummaryPreview();
                    
                    int response = JOptionPane.showConfirmDialog(
                        view, 
                        "BMI may indicate higher surgical risk.\n\n" +
                        bmiStatus + "\n\n" +
                        "Health Summary:\n" + healthSummary + "\n\n" +
                        "Do you want to continue registration anyway?", 
                        "BMI Validation Warning", 
                        JOptionPane.YES_NO_OPTION, 
                        JOptionPane.WARNING_MESSAGE
                    );
                    if (response != JOptionPane.YES_OPTION) {
                        return;
                    }
                }
                
                // Check for communicable diseases
                if (recipient.isHasCommunicableDisease()) {
                    int response = JOptionPane.showConfirmDialog(
                        view,
                        "Communicable disease detected. This may affect transplant eligibility.\n" +
                        "Do you want to continue registration?",
                        "Medical Alert",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.WARNING_MESSAGE
                    );
                    if (response != JOptionPane.YES_OPTION) {
                        return;
                    }
                }
                
                recipient.setHospitalId(hospitalId);

                boolean success;
                String successMessage;

                // Check if we are adding or updating
                if (editingRecipientId != null) {
                    // UPDATE MODE
                    success = model.updateRecipient(recipient);
                    successMessage = "Recipient updated successfully!";
                } else {
                    // ADD MODE
                    success = model.addRecipient(recipient);
                    successMessage = "Recipient registered successfully!";
                }

                if (success) {
                    view.showMessage(successMessage, "Success", JOptionPane.INFORMATION_MESSAGE);
                    
                    // Send notification only for NEW urgent registrations
                    if (editingRecipientId == null) {
                        String urgency = recipient.getUrgencyLevel();
                        if ("Urgent".equals(urgency) || "High".equals(urgency)) {
                            createUrgentRecipientNotification(recipient);
                        }
                    }
                    
                    view.dispose();
                } else {
                    view.showMessage("Failed to process recipient.", "Database Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (NumberFormatException ex) {
                view.showMessage("Invalid number format. Please check Age, Height, and Weight.", "Input Error", JOptionPane.ERROR_MESSAGE);
            } catch (java.text.ParseException ex) {
                view.showMessage("Invalid date format. Please use yyyy-mm-dd.", "Input Error", JOptionPane.ERROR_MESSAGE);
            } catch (Exception ex) {
                view.showMessage("An unexpected error occurred: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                ex.printStackTrace();
            }
        }

        private void createUrgentRecipientNotification(Recipient recipient) {
            // ... (implementation exists in your original code)
            Notification notif = new Notification();
            // ...
            // notificationDAO.createNotification(notif);
        }
        
        private boolean validateRecipientAge(int age, String organ) {
            // ... (implementation exists in your original code)
            return true;
        }
    }
    
    public static boolean isSuitableForTransplant(Recipient recipient) {
        // ... (implementation exists in your original code)
        return true;
    }
    
    public static String getRecipientSuitabilitySummary(Recipient recipient) {
        // ... (implementation exists in your original code)
        return "";
    }
}