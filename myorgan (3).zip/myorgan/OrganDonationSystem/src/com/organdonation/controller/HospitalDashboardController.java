package com.organdonation.controller;

import com.organdonation.model.Donor;
import com.organdonation.model.DonorDAO;
import com.organdonation.model.Hospital;
import com.organdonation.model.Notification;
import com.organdonation.model.Recipient;
import com.organdonation.model.RecipientDAO;
import com.organdonation.view.DonorRegistrationView;
import com.organdonation.view.HospitalDashboardView;
import com.organdonation.view.HospitalLoginView;
import com.organdonation.view.RecipientRegistrationView;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.List;

public class HospitalDashboardController {
    private HospitalDashboardView view;
    private Hospital hospital;
    private NotificationController notificationController;
    
    private DonorDAO donorDAO;
    private RecipientDAO recipientDAO;

    public HospitalDashboardController(HospitalDashboardView view, Hospital hospital) {
        this.view = view;
        this.hospital = hospital;
        
        this.donorDAO = new DonorDAO();
        this.recipientDAO = new RecipientDAO();
        
        // --- 1. Registration and Logout Listeners ---
        this.view.addRegisterDonorListener(new RegisterDonorListener());
        this.view.addRegisterRecipientListener(new RegisterRecipientListener());
        this.view.addLogoutListener(new LogoutListener());
        
        // --- 2. List Management Listeners (Edit, Delete, Status Update) ---
        this.view.addEditDonorListener(new EditDonorListener());
        this.view.addDeleteDonorListener(new DeleteDonorListener());
        this.view.addUpdateDonorStatusListener(new UpdateDonorStatusListener());
        
        this.view.addEditRecipientListener(new EditRecipientListener());
        this.view.addDeleteRecipientListener(new DeleteRecipientListener());
        this.view.addUpdateRecipientStatusListener(new UpdateRecipientStatusListener());


        // Initialize and start notification timer
        this.notificationController = new NotificationController(
            view.getNotificationBell(),
            String.valueOf(hospital.getId()),
            Notification.UserType.hospital.name()
        );
        Timer notificationTimer = new Timer(30000, e -> notificationController.updateNotificationCount());
        notificationTimer.setInitialDelay(0);
        notificationTimer.start();
        
        // Load initial data
        loadDashboardData();
    }
    
    // Central method to load all data for the hospital
    private void loadDashboardData() {
        loadHospitalDonors();
        loadHospitalRecipients();
    }

    // Load donors registered by this hospital
    private void loadHospitalDonors() {
        DefaultTableModel model = view.getDonorModel();
        model.setRowCount(0);
        
        List<Donor> donors = donorDAO.getDonorsByHospitalId(hospital.getId());
        for (Donor donor : donors) {
            model.addRow(new Object[]{
                donor.getId(), 
                donor.getName(), 
                donor.getAge(), 
                donor.getBloodGroup(), 
                donor.getOrganDonating(), 
                donor.getStatus()
            });
        }
    }

    // Load recipients registered by this hospital
    private void loadHospitalRecipients() {
        DefaultTableModel model = view.getRecipientModel();
        model.setRowCount(0);
        
        List<Recipient> recipients = recipientDAO.getRecipientsByHospitalId(hospital.getId());
        for (Recipient recipient : recipients) {
            model.addRow(new Object[]{
                recipient.getId(), 
                recipient.getName(), 
                recipient.getAge(), 
                recipient.getOrganNeeded(), 
                recipient.getUrgencyLevel(), 
                recipient.getStatus()
            });
        }
    }


    // ---------------------------------------------
    // --- LISTENER IMPLEMENTATIONS (CRUD + REFRESH) ---
    // ---------------------------------------------

    class RegisterDonorListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            DonorRegistrationView regView = new DonorRegistrationView();
            new DonorRegistrationController(regView, hospital.getId()); 
            
            // AUTO-REFRESH on window close
            regView.addWindowListener(new WindowAdapter() {
                @Override
                public void windowClosed(WindowEvent e) {
                    loadDashboardData(); 
                }
            });
            regView.setVisible(true);
        }
    }

    class RegisterRecipientListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            RecipientRegistrationView regView = new RecipientRegistrationView();
            new RecipientRegistrationController(regView, hospital.getId());
            
            // AUTO-REFRESH on window close
            regView.addWindowListener(new WindowAdapter() {
                @Override
                public void windowClosed(WindowEvent e) {
                    loadDashboardData(); 
                }
            });
            regView.setVisible(true);
        }
    }
    
    // CORRECTED: Edit Listener ensures existing data is fetched and passed
    class EditDonorListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            int donorId = view.getSelectedDonorId();
            if (donorId != -1) {
                // Fetch the existing donor object
                Donor donor = donorDAO.getDonorById(donorId);
                
                if (donor != null) {
                    DonorRegistrationView regView = new DonorRegistrationView();
                    // *** USE THE EDIT CONSTRUCTOR ***
                    new DonorRegistrationController(regView, hospital.getId(), donor);
                    
                    // Add listener for auto-refresh
                    regView.addWindowListener(new WindowAdapter() {
                        @Override
                        public void windowClosed(WindowEvent e) {
                            loadDashboardData();
                        }
                    });
                    regView.setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(view, "Could not load donor details from database.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(view, "Please select a donor to edit.", "No Selection", JOptionPane.WARNING_MESSAGE);
            }
        }
    }
    
    class DeleteDonorListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            int donorId = view.getSelectedDonorId();
            if (donorId != -1) {
                int choice = JOptionPane.showConfirmDialog(view, 
                    "Permanently delete donor ID: " + donorId + "? This action cannot be undone.",
                    "Confirm Deletion", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
                
                if (choice == JOptionPane.YES_OPTION) {
                    if (donorDAO.deleteDonor(donorId)) {
                        JOptionPane.showMessageDialog(view, "Donor deleted successfully!");
                        loadHospitalDonors();
                    } else {
                        JOptionPane.showMessageDialog(view, "Failed to delete donor. Check if donor is matched.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            } else {
                JOptionPane.showMessageDialog(view, "Please select a donor from the table first.", "No Selection", JOptionPane.WARNING_MESSAGE);
            }
        }
    }
    
    class UpdateDonorStatusListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            int donorId = view.getSelectedDonorId();
            if (donorId != -1) {
                String[] statuses = {"Available", "Unavailable", "Matched"};
                String newStatus = (String) JOptionPane.showInputDialog(
                    view,
                    "Select new status for Donor ID: " + donorId,
                    "Update Donor Status",
                    JOptionPane.QUESTION_MESSAGE,
                    null,
                    statuses,
                    statuses[0]
                );
                
                if (newStatus != null) {
                    if (donorDAO.updateDonorStatus(donorId, newStatus)) {
                        JOptionPane.showMessageDialog(view, "Donor status updated to '" + newStatus + "'!");
                        loadHospitalDonors();
                    } else {
                        JOptionPane.showMessageDialog(view, "Failed to update status.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            } else {
                JOptionPane.showMessageDialog(view, "Please select a donor from the table first.", "No Selection", JOptionPane.WARNING_MESSAGE);
            }
        }
    }
    
    // CORRECTED: Edit Listener ensures existing data is fetched and passed
    class EditRecipientListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            int recipientId = view.getSelectedRecipientId();
            if (recipientId != -1) {
                // Fetch the existing recipient object
                Recipient recipient = recipientDAO.getRecipientById(recipientId);
                
                if (recipient != null) {
                    RecipientRegistrationView regView = new RecipientRegistrationView();
                    // *** USE THE EDIT CONSTRUCTOR ***
                    new RecipientRegistrationController(regView, hospital.getId(), recipient);
                    
                    // Add listener for auto-refresh
                    regView.addWindowListener(new WindowAdapter() {
                        @Override
                        public void windowClosed(WindowEvent e) {
                            loadDashboardData();
                        }
                    });
                    regView.setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(view, "Could not load recipient details from database.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(view, "Please select a recipient to edit.", "No Selection", JOptionPane.WARNING_MESSAGE);
            }
        }
    }
    
    class DeleteRecipientListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            int recipientId = view.getSelectedRecipientId();
            if (recipientId != -1) {
                int choice = JOptionPane.showConfirmDialog(view, 
                    "Permanently delete recipient ID: " + recipientId + "? This action cannot be undone.",
                    "Confirm Deletion", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
                
                if (choice == JOptionPane.YES_OPTION) {
                    if (recipientDAO.deleteRecipient(recipientId)) {
                        JOptionPane.showMessageDialog(view, "Recipient deleted successfully!");
                        loadHospitalRecipients();
                    } else {
                        JOptionPane.showMessageDialog(view, "Failed to delete recipient. Check if recipient is matched.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            } else {
                JOptionPane.showMessageDialog(view, "Please select a recipient from the table first.", "No Selection", JOptionPane.WARNING_MESSAGE);
            }
        }
    }
    
    class UpdateRecipientStatusListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            int recipientId = view.getSelectedRecipientId();
            if (recipientId != -1) {
                String[] statuses = {"Waiting", "Deferred", "Matched"};
                String newStatus = (String) JOptionPane.showInputDialog(
                    view,
                    "Select new status for Recipient ID: " + recipientId,
                    "Update Recipient Status",
                    JOptionPane.QUESTION_MESSAGE,
                    null,
                    statuses,
                    statuses[0]
                );
                
                if (newStatus != null) {
                    if (recipientDAO.updateRecipientStatus(recipientId, newStatus)) {
                        JOptionPane.showMessageDialog(view, "Recipient status updated to '" + newStatus + "'!");
                        loadHospitalRecipients();
                    } else {
                        JOptionPane.showMessageDialog(view, "Failed to update status.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            } else {
                JOptionPane.showMessageDialog(view, "Please select a recipient from the table first.", "No Selection", JOptionPane.WARNING_MESSAGE);
            }
        }
    }

    class LogoutListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            int choice = JOptionPane.showConfirmDialog(
                view, 
                "Are you sure you want to logout from Hospital Portal?\n\n" +
                "Hospital: " + hospital.getName(), 
                "Confirm Hospital Logout", 
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE
            );
            
            if (choice == JOptionPane.YES_OPTION) {
                view.dispose();
                SwingUtilities.invokeLater(() -> {
                    // Use NavigationManager to show landing page
                    NavigationManager.showLandingView();
                });
            }
        }
    }
}