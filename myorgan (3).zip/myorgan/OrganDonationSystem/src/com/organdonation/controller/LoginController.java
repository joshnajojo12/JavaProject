package com.organdonation.controller;

import com.organdonation.model.Admin;
import com.organdonation.model.AdminDAO;
import com.organdonation.view.AdminDashboardView;
import com.organdonation.view.LoginView;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.SwingUtilities;
import javax.swing.JOptionPane;

public class LoginController {
    private LoginView view;
    private AdminDAO model;

    public LoginController(LoginView view, AdminDAO model) {
        this.view = view;
        this.model = model;
        
        this.view.addLoginListener(new LoginListener());
        this.view.addBackListener(new BackListener());
        this.view.setUsernameFocus();
        
        System.out.println("🔧 LoginController initialized");
    }

    class LoginListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String username = view.getUsername();
            String password = view.getPassword();

            System.out.println("🔐 Admin login attempt: " + username);

            if (!validateAdminLogin(username, password)) {
                return;
            }

            Admin admin = model.validate(username, password);

            if (admin != null) {
                System.out.println("✅ Admin login successful");
                view.showMessage("Login Successful! Welcome, " + username + ".");
                view.dispose();

                SwingUtilities.invokeLater(() -> {
                    AdminDashboardView dashboard = new AdminDashboardView();
                    new AdminDashboardController(dashboard);
                    dashboard.setVisible(true);
                });
            } else {
                System.out.println("❌ Admin login failed");
                view.showMessage("Invalid username or password.");
                view.clearPasswordField();
                view.setUsernameFocus();
            }
        }
    }

    class BackListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            System.out.println("🔙 Back to Portal Selection from Admin Login");
            view.dispose();
            NavigationManager.showLandingView();
        }
    }
    
    private boolean validateAdminLogin(String username, String password) {
        if (username.isEmpty() || password.isEmpty()) {
            view.showMessage("Please enter both username and password.");
            return false;
        }
        return true;
    }
}