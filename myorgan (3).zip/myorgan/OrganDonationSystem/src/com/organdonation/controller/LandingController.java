package com.organdonation.controller;

import com.organdonation.model.AdminDAO;
import com.organdonation.model.HospitalDAO;
import com.organdonation.view.HospitalLoginView;
import com.organdonation.view.LandingView;
import com.organdonation.view.LoginView;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.SwingUtilities;

public class LandingController {
    private LandingView view;
    private AdminDAO adminDAO;
    private HospitalDAO hospitalDAO;

    public LandingController(LandingView view, AdminDAO adminDAO, HospitalDAO hospitalDAO) {
        this.view = view;
        this.adminDAO = adminDAO;
        this.hospitalDAO = hospitalDAO;

        this.view.addHospitalPortalListener(new HospitalPortalListener());
        this.view.addAdminPortalListener(new AdminPortalListener());
        
        System.out.println("🌐 LandingController initialized");
    }

    class AdminPortalListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            System.out.println("👤 Admin Portal button clicked");
            openAdminLogin();
        }
    }

    class HospitalPortalListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            System.out.println("🏥 Hospital Portal button clicked");
            openHospitalLogin();
        }
    }
    
    private void openAdminLogin() {
        SwingUtilities.invokeLater(() -> {
            LoginView adminLoginView = new LoginView();
            new LoginController(adminLoginView, adminDAO);
            adminLoginView.setVisible(true);
        });
    }
    
    private void openHospitalLogin() {
        SwingUtilities.invokeLater(() -> {
            HospitalLoginView hospitalLoginView = new HospitalLoginView();
            new HospitalLoginController(hospitalLoginView, hospitalDAO);
            hospitalLoginView.setVisible(true);
        });
    }
    
    // Method to show landing view again
    public void showLandingView() {
        System.out.println("🔄 Showing Landing Page");
        SwingUtilities.invokeLater(() -> {
            view.setVisible(true);
            view.toFront();
            view.requestFocus();
        });
    }
}