package com.organdonation.controller;

import com.organdonation.model.Donor;
import com.organdonation.model.DonorDAO;
import com.organdonation.model.AgeValidator;
import com.organdonation.view.DonorRegistrationView;
import javax.swing.JOptionPane;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class DonorRegistrationController {
    private DonorRegistrationView view;
    private DonorDAO model;
    private int hospitalId;
    private Integer editingDonorId = null; // Tracks the ID of the donor being edited

    public DonorRegistrationController(DonorRegistrationView view, int hospitalId) {
        this.view = view;
        this.model = new DonorDAO();
        this.hospitalId = hospitalId;
        this.view.addRegisterListener(new RegisterListener());
    }

    // NEW: Constructor for EDIT mode
    public DonorRegistrationController(DonorRegistrationView view, int hospitalId, Donor donorToEdit) {
        this(view, hospitalId); // Call primary constructor
        this.editingDonorId = donorToEdit.getId(); // Set edit mode
        this.view.setDonorDetailsForEdit(donorToEdit); // *** Populates fields ***
    }

    class RegisterListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                Donor donor = view.getDonorDetails(editingDonorId);
                
                // Validate required fields
                if (donor.getName().isEmpty() || donor.getGender() == null) {
                    view.showMessage("Please fill in all required fields (Name, Gender, etc.).", "Validation Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                // Validate age for organ donation
                if (!validateDonorAge(donor.getAge(), donor.getOrganDonating())) {
                    return;
                }
                
                // Validate BMI for donation suitability
                if (!view.validateBMIForDonation()) {
                    String bmiStatus = view.getCurrentBMIStatus();
                    int response = JOptionPane.showConfirmDialog(
                        view, 
                        "BMI may not be ideal for donation. " + bmiStatus + 
                        "\nDo you want to continue registration anyway?", 
                        "BMI Validation", 
                        JOptionPane.YES_NO_OPTION, 
                        JOptionPane.WARNING_MESSAGE
                    );
                    if (response != JOptionPane.YES_OPTION) {
                        return;
                    }
                }
                
                donor.setHospitalId(hospitalId);
                
                boolean success;
                String successMessage;

                // Check if we are adding or updating
                if (editingDonorId != null) {
                    // UPDATE MODE
                    success = model.updateDonor(donor);
                    successMessage = "Donor updated successfully!";
                } else {
                    // ADD MODE
                    success = model.addDonor(donor);
                    successMessage = "Donor registered successfully!";
                }

                if (success) {
                    view.showMessage(successMessage, "Success", JOptionPane.INFORMATION_MESSAGE);
                    view.dispose();
                } else {
                    view.showMessage("Failed to process donor. Please check the console for errors.", "Database Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (NumberFormatException ex) {
                view.showMessage("Invalid number format. Please check Age, Height, and Weight fields.", "Input Error", JOptionPane.ERROR_MESSAGE);
            } catch (java.text.ParseException ex) {
                view.showMessage("Invalid date format. Please use yyyy-mm-dd.", "Input Error", JOptionPane.ERROR_MESSAGE);
            } catch (Exception ex) {
                view.showMessage("An unexpected error occurred: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                ex.printStackTrace();
            }
        }
        
        private boolean validateDonorAge(int age, String organ) {
            if (!AgeValidator.isValidDonorAge(age, organ)) {
                String requirements = AgeValidator.getAgeRequirements(organ, true);
                String message = String.format(
                    "Age %d is not suitable for %s donation.\n\n" +
                    "Required age range: %s\n\n" +
                    "Please adjust the age or select a different organ.",
                    age, organ, requirements
                );
                
                int response = JOptionPane.showConfirmDialog(
                    view, 
                    message, 
                    "Age Validation Warning", 
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.WARNING_MESSAGE
                );
                
                return response == JOptionPane.YES_OPTION;
            }
            return true;
        }
    }
    
    public static boolean meetsMedicalCriteria(Donor donor) {
        // ... (implementation exists in your original code)
        return true; 
    }
    
    public static String getDonorEligibilitySummary(Donor donor) {
        // ... (implementation exists in your original code)
        return "";
    }
}