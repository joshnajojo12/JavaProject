package com.organdonation.controller;

import com.organdonation.model.AdminDAO;
import com.organdonation.model.HospitalDAO;
import com.organdonation.view.LandingView;
import javax.swing.SwingUtilities;

public class App {	 
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            LandingView view = new LandingView();
            AdminDAO adminDAO = new AdminDAO();
            HospitalDAO hospitalDAO = new HospitalDAO();
            LandingController landingController = new LandingController(view, adminDAO, hospitalDAO);
            
            // Set the landing controller in NavigationManager
            NavigationManager.setLandingController(landingController);
            
            view.setVisible(true);
        });
    }
}