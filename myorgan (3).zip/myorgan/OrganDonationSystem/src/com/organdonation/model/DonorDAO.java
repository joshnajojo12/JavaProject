package com.organdonation.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DonorDAO {

    private Connection connection;

    public DonorDAO() {
        this.connection = DBConnection.getConnection();
    }

    // Add a new donor (CREATE)
    public boolean addDonor(Donor donor) {
        String sql = "INSERT INTO donors (name, age, gender, date_of_birth, blood_group, organ_donating, phone_number, email, address, emergency_contact_name, emergency_contact_phone, weight_kg, height_cm, has_diseases, medical_history, status, hospital_id, hla_a1, hla_a2, hla_b1, hla_b2, hla_dr1, hla_dr2, cmv_serostatus, liver_steatosis, glomerular_filtration_rate) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, donor.getName());
            ps.setInt(2, donor.getAge());
            ps.setString(3, donor.getGender());
            ps.setDate(4, new java.sql.Date(donor.getDateOfBirth().getTime()));
            ps.setString(5, donor.getBloodGroup());
            ps.setString(6, donor.getOrganDonating());
            ps.setString(7, donor.getPhoneNumber());
            ps.setString(8, donor.getEmail());
            ps.setString(9, donor.getAddress());
            ps.setString(10, donor.getEmergencyContactName());
            ps.setString(11, donor.getEmergencyContactPhone());
            ps.setDouble(12, donor.getWeightKg());
            ps.setDouble(13, donor.getHeightCm());
            ps.setBoolean(14, donor.isHasDiseases());
            ps.setString(15, donor.getMedicalHistory());
            ps.setString(16, "Available"); // Default status
            ps.setInt(17, donor.getHospitalId());
            ps.setString(18, donor.getHla_a1());
            ps.setString(19, donor.getHla_a2());
            ps.setString(20, donor.getHla_b1());
            ps.setString(21, donor.getHla_b2());
            ps.setString(22, donor.getHla_dr1());
            ps.setString(23, donor.getHla_dr2());
            ps.setString(24, donor.getCmvSerostatus());
            ps.setString(25, donor.getLiverSteatosis());
            ps.setDouble(26, donor.getGlomerularFiltrationRate());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Update an existing donor (UPDATE - Full Details)
    public boolean updateDonor(Donor donor) {
        String sql = "UPDATE donors SET name=?, age=?, gender=?, date_of_birth=?, blood_group=?, organ_donating=?, phone_number=?, email=?, address=?, emergency_contact_name=?, emergency_contact_phone=?, weight_kg=?, height_cm=?, has_diseases=?, medical_history=?, hla_a1=?, hla_a2=?, hla_b1=?, hla_b2=?, hla_dr1=?, hla_dr2=?, cmv_serostatus=?, liver_steatosis=?, glomerular_filtration_rate=? WHERE id=?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            int i = 1;
            ps.setString(i++, donor.getName());
            ps.setInt(i++, donor.getAge());
            ps.setString(i++, donor.getGender());
            ps.setDate(i++, new java.sql.Date(donor.getDateOfBirth().getTime()));
            ps.setString(i++, donor.getBloodGroup());
            ps.setString(i++, donor.getOrganDonating());
            ps.setString(i++, donor.getPhoneNumber());
            ps.setString(i++, donor.getEmail());
            ps.setString(i++, donor.getAddress());
            ps.setString(i++, donor.getEmergencyContactName());
            ps.setString(i++, donor.getEmergencyContactPhone());
            ps.setDouble(i++, donor.getWeightKg());
            ps.setDouble(i++, donor.getHeightCm());
            ps.setBoolean(i++, donor.isHasDiseases());
            ps.setString(i++, donor.getMedicalHistory());
            ps.setString(i++, donor.getHla_a1());
            ps.setString(i++, donor.getHla_a2());
            ps.setString(i++, donor.getHla_b1());
            ps.setString(i++, donor.getHla_b2());
            ps.setString(i++, donor.getHla_dr1());
            ps.setString(i++, donor.getHla_dr2());
            ps.setString(i++, donor.getCmvSerostatus());
            ps.setString(i++, donor.getLiverSteatosis());
            ps.setDouble(i++, donor.getGlomerularFiltrationRate());
            ps.setInt(i++, donor.getId()); // WHERE ID = ?

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Get all donors (READ)
    public List<Donor> getAllDonors() {
        List<Donor> donors = new ArrayList<>();
        String sql = "SELECT * FROM donors";
        try (PreparedStatement ps = connection.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                donors.add(mapResultSetToDonor(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return donors;
    }
    
    // Get donors specific to a hospital ID (READ - Filtered)
    public List<Donor> getDonorsByHospitalId(int hospitalId) {
        List<Donor> donors = new ArrayList<>();
        String sql = "SELECT * FROM donors WHERE hospital_id = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, hospitalId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    donors.add(mapResultSetToDonor(rs));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return donors;
    }

    // Get a single donor by ID (READ - Single)
    public Donor getDonorById(int id) {
        String sql = "SELECT * FROM donors WHERE id = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToDonor(rs);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // Update donor status (UPDATE - Status Only)
    public boolean updateDonorStatus(int id, String newStatus) {
        String sql = "UPDATE donors SET status = ? WHERE id = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, newStatus);
            ps.setInt(2, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Delete a donor (DELETE)
    public boolean deleteDonor(int id) {
        String sql = "DELETE FROM donors WHERE id = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Get count of all donors
    public int getDonorCount() {
        String sql = "SELECT COUNT(*) FROM donors";
        try (PreparedStatement ps = connection.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    // Get count of available donors by organ
    public int getAvailableDonorCountByOrgan(String organ) {
        String sql = "SELECT COUNT(*) FROM donors WHERE organ_donating = ? AND status = 'Available'";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, organ);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    // Helper method to map ResultSet to Donor object
    private Donor mapResultSetToDonor(ResultSet rs) throws SQLException {
        Donor d = new Donor();
        d.setId(rs.getInt("id"));
        d.setName(rs.getString("name"));
        d.setAge(rs.getInt("age"));
        d.setGender(rs.getString("gender"));
        d.setDateOfBirth(rs.getDate("date_of_birth"));
        d.setBloodGroup(rs.getString("blood_group"));
        d.setOrganDonating(rs.getString("organ_donating"));
        d.setPhoneNumber(rs.getString("phone_number"));
        d.setEmail(rs.getString("email"));
        d.setAddress(rs.getString("address"));
        d.setEmergencyContactName(rs.getString("emergency_contact_name"));
        d.setEmergencyContactPhone(rs.getString("emergency_contact_phone"));
        d.setWeightKg(rs.getDouble("weight_kg"));
        d.setHeightCm(rs.getDouble("height_cm"));
        d.setHasDiseases(rs.getBoolean("has_diseases"));
        d.setMedicalHistory(rs.getString("medical_history"));
        d.setStatus(rs.getString("status"));
        d.setHospitalId(rs.getInt("hospital_id"));
        d.setHla_a1(rs.getString("hla_a1"));
        d.setHla_a2(rs.getString("hla_a2"));
        d.setHla_b1(rs.getString("hla_b1"));
        d.setHla_b2(rs.getString("hla_b2"));
        d.setHla_dr1(rs.getString("hla_dr1"));
        d.setHla_dr2(rs.getString("hla_dr2"));
        d.setCmvSerostatus(rs.getString("cmv_serostatus"));
        d.setLiverSteatosis(rs.getString("liver_steatosis"));
        d.setGlomerularFiltrationRate(rs.getDouble("glomerular_filtration_rate"));
        
        return d;
    }
}