package com.organdonation.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MatchDAO {

    private Connection connection;

    public MatchDAO() {
        this.connection = DBConnection.getConnection();
    }

    // Find potential matches for a given recipient
    public List<Match> findMatchesForRecipient(Recipient recipient) {
        List<Match> matches = new ArrayList<>();
        // Find donors who are 'Available', match the organ, and have a compatible blood group
        String sql = "SELECT * FROM donors WHERE status = 'Available' AND organ_donating = ? AND blood_group IN (";
        
        // Determine compatible blood groups
        switch (recipient.getBloodGroup()) {
            case "A+": sql += "'A+', 'A-', 'O+', 'O-'"; break;
            case "A-": sql += "'A-', 'O-'"; break;
            case "B+": sql += "'B+', 'B-', 'O+', 'O-'"; break;
            case "B-": sql += "'B-', 'O-'"; break;
            case "AB+": sql += "'A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'"; break; // Universal recipient
            case "AB-": sql += "'A-', 'B-', 'AB-', 'O-'"; break;
            case "O+": sql += "'O+', 'O-'"; break;
            case "O-": sql += "'O-'"; break;
            default: sql += "''"; // No match if blood group is unknown
        }
        sql += ")";

        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, recipient.getOrganNeeded());
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Match match = new Match();
                    match.setDonorId(rs.getInt("id"));
                    match.setDonorName(rs.getString("name"));
                    match.setRecipientId(recipient.getId());
                    match.setRecipientName(recipient.getName());
                    match.setOrgan(recipient.getOrganNeeded());
                    match.setStatus("Pending"); // New potential match
                    matches.add(match);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return matches;
    }

    // Approve a match and update donor/recipient status
    public boolean approveMatch(int donorId, int recipientId) {
        String updateDonorSql = "UPDATE donors SET status = 'Matched' WHERE id = ?";
        String updateRecipientSql = "UPDATE recipients SET status = 'Matched' WHERE id = ?";
        String insertMatchSql = "INSERT INTO matches (donor_id, recipient_id, organ, status) VALUES (?, ?, (SELECT organ_needed FROM recipients WHERE id = ?), 'Completed')";
        
        try {
            // Start transaction
            connection.setAutoCommit(false);

            try (PreparedStatement psDonor = connection.prepareStatement(updateDonorSql);
                 PreparedStatement psRecipient = connection.prepareStatement(updateRecipientSql);
                 PreparedStatement psMatch = connection.prepareStatement(insertMatchSql)) {

                // Update donor
                psDonor.setInt(1, donorId);
                psDonor.executeUpdate();

                // Update recipient
                psRecipient.setInt(1, recipientId);
                psRecipient.executeUpdate();

                // Insert into matches table
                psMatch.setInt(1, donorId);
                psMatch.setInt(2, recipientId);
                psMatch.setInt(3, recipientId); // For the subquery
                psMatch.executeUpdate();

                // If all good, commit
                connection.commit();
                return true;

            } catch (SQLException e) {
                // If anything fails, rollback
                connection.rollback();
                e.printStackTrace();
                return false;
            } finally {
                // Restore auto-commit
                connection.setAutoCommit(true);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Get count of completed matches
    public int getCompletedMatchCount() {
        String sql = "SELECT COUNT(*) FROM matches WHERE status = 'Completed'";
        try (PreparedStatement ps = connection.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    // Debugging method (as seen in your controller)
    public void debugDatabaseStatus() {
        System.out.println("MatchDAO: Database connection is " + (connection != null ? "OK" : "NULL"));
    }
    
    // Test method (as seen in your controller)
    public void testMatchApproval(int donorId, int recipientId) {
         System.out.println("MatchDAO Test: Approving match for Donor ID " + donorId + " and Recipient ID " + recipientId);
    }
}