package com.organdonation.model;

import java.sql.Timestamp;

public class Notification {
    private int id;
    private String userId;
    private String userType;
    private String message;
    private String details;
    private String urgency;
    private boolean isRead;
    private Timestamp createdAt;

    // Enum for urgency levels
    public enum Urgency {
        low, medium, high, critical
    }

    // Enum for user types
    public enum UserType {
        admin, hospital
    }

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getUserId() { return userId; }
    public void setUserId(String userId) { this.userId = userId; }

    public String getUserType() { return userType; }
    public void setUserType(String userType) { this.userType = userType; }
    public void setUserType(UserType userType) { this.userType = userType.name(); }

    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }

    public String getDetails() { return details; }
    public void setDetails(String details) { this.details = details; }

    public String getUrgency() { return urgency; }
    public void setUrgency(String urgency) { this.urgency = urgency; }
    public void setUrgency(Urgency urgency) { this.urgency = urgency.name(); }

    public boolean isRead() { return isRead; }
    public void setRead(boolean isRead) { this.isRead = isRead; }

    public Timestamp getCreatedAt() { return createdAt; }
    public void setCreatedAt(Timestamp createdAt) { this.createdAt = createdAt; }
}