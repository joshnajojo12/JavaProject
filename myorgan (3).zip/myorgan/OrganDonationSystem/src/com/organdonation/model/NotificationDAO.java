package com.organdonation.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class NotificationDAO {

    private Connection connection;

    public NotificationDAO() {
        // MODIFIED: Removed the try-catch block as your DBConnection.getConnection()
        // does not throw an SQLException, which was causing the compilation error.
        this.connection = DBConnection.getConnection();

        // Added a null check to prevent future errors
        if (this.connection == null) {
            System.err.println("FATAL: Database connection is null. NotificationDAO will not work.");
        }
    }

    // Create a new notification
    public boolean createNotification(Notification notification) {
        String sql = "INSERT INTO notifications (user_id, user_type, message, details, urgency) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, notification.getUserId());
            ps.setString(2, notification.getUserType());
            ps.setString(3, notification.getMessage());
            ps.setString(4, notification.getDetails());
            ps.setString(5, notification.getUrgency());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error creating notification: " + e.getMessage());
            return false;
        }
    }

    // Get unread notifications for a user
    public List<Notification> getUnreadNotifications(String userId, String userType) {
        List<Notification> notifications = new ArrayList<>();
        String sql = "SELECT * FROM notifications WHERE user_id = ? AND user_type = ? AND is_read = 0 ORDER BY created_at DESC";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, userId);
            ps.setString(2, userType);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    notifications.add(mapResultSetToNotification(rs));
                }
            }
        } catch (SQLException e) {
            System.err.println("Error fetching unread notifications: " + e.getMessage());
        }
        return notifications;
    }

    // Get the count of unread notifications
    public int getUnreadNotificationCount(String userId, String userType) {
        String sql = "SELECT COUNT(*) FROM notifications WHERE user_id = ? AND user_type = ? AND is_read = 0";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, userId);
            ps.setString(2, userType);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error counting unread notifications: " + e.getMessage());
        }
        return 0;
    }

    // Mark a single notification as read
    public boolean markAsRead(int notificationId) {
        String sql = "UPDATE notifications SET is_read = 1 WHERE notification_id = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, notificationId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error marking notification as read: " + e.getMessage());
            return false;
        }
    }

    // Mark all notifications for a user as read
    public boolean markAllAsRead(String userId, String userType) {
        String sql = "UPDATE notifications SET is_read = 1 WHERE user_id = ? AND user_type = ? AND is_read = 0";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, userId);
            ps.setString(2, userType);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error marking all notifications as read: " + e.getMessage());
            return false;
        }
    }

    private Notification mapResultSetToNotification(ResultSet rs) throws SQLException {
        Notification n = new Notification();
        n.setId(rs.getInt("notification_id"));
        n.setUserId(rs.getString("user_id"));
        n.setUserType(rs.getString("user_type"));
        n.setMessage(rs.getString("message"));
        n.setDetails(rs.getString("details"));
        n.setUrgency(rs.getString("urgency"));
        n.setRead(rs.getBoolean("is_read"));
        n.setCreatedAt(rs.getTimestamp("created_at"));
        return n;
    }
}