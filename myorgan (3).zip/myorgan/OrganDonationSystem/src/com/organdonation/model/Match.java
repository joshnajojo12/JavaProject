package com.organdonation.model;

public class Match {
    private int donorId;
    private String donorName;
    private int recipientId;
    private String recipientName;
    private String organ;
    private String status;

    // --- Add Getters and Setters for all fields below ---

    public int getDonorId() { return donorId; }
    public void setDonorId(int donorId) { this.donorId = donorId; }
    public String getDonorName() { return donorName; }
    public void setDonorName(String donorName) { this.donorName = donorName; }
    public int getRecipientId() { return recipientId; }
    public void setRecipientId(int recipientId) { this.recipientId = recipientId; }
    public String getRecipientName() { return recipientName; }
    public void setRecipientName(String recipientName) { this.recipientName = recipientName; }
    public String getOrgan() { return organ; }
    public void setOrgan(String organ) { this.organ = organ; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}