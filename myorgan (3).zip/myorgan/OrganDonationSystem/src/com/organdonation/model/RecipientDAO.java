package com.organdonation.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class RecipientDAO {

    private Connection connection;

    public RecipientDAO() {
        this.connection = DBConnection.getConnection();
    }

    // Add a new recipient (CREATE)
    public boolean addRecipient(Recipient recipient) {
        String sql = "INSERT INTO recipients (name, age, gender, date_of_birth, blood_group, organ_needed, urgency_level, phone_number, email, address, diagnosis, weight_kg, height_cm, has_communicable_disease, medical_history, status, hospital_id, hla_a1, hla_a2, hla_b1, hla_b2, hla_dr1, hla_dr2, pra_percent, cmv_serostatus, liver_steatosis, glomerular_filtration_rate) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, recipient.getName());
            ps.setInt(2, recipient.getAge());
            ps.setString(3, recipient.getGender());
            ps.setDate(4, new java.sql.Date(recipient.getDateOfBirth().getTime()));
            ps.setString(5, recipient.getBloodGroup());
            ps.setString(6, recipient.getOrganNeeded());
            ps.setString(7, recipient.getUrgencyLevel());
            ps.setString(8, recipient.getPhoneNumber());
            ps.setString(9, recipient.getEmail());
            ps.setString(10, recipient.getAddress());
            ps.setString(11, recipient.getDiagnosis());
            ps.setDouble(12, recipient.getWeightKg());
            ps.setDouble(13, recipient.getHeightCm());
            ps.setBoolean(14, recipient.isHasCommunicableDisease());
            ps.setString(15, recipient.getMedicalHistory());
            ps.setString(16, "Waiting"); // Default status
            ps.setInt(17, recipient.getHospitalId());
            ps.setString(18, recipient.getHla_a1());
            ps.setString(19, recipient.getHla_a2());
            ps.setString(20, recipient.getHla_b1());
            ps.setString(21, recipient.getHla_b2());
            ps.setString(22, recipient.getHla_dr1());
            ps.setString(23, recipient.getHla_dr2());
            ps.setDouble(24, recipient.getPraPercent());
            ps.setString(25, recipient.getCmvSerostatus());
            ps.setString(26, recipient.getLiverSteatosis());
            ps.setDouble(27, recipient.getGlomerularFiltrationRate());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Update an existing recipient (UPDATE - Full Details)
    public boolean updateRecipient(Recipient recipient) {
        String sql = "UPDATE recipients SET name=?, age=?, gender=?, date_of_birth=?, blood_group=?, organ_needed=?, urgency_level=?, phone_number=?, email=?, address=?, diagnosis=?, weight_kg=?, height_cm=?, has_communicable_disease=?, medical_history=?, hla_a1=?, hla_a2=?, hla_b1=?, hla_b2=?, hla_dr1=?, hla_dr2=?, pra_percent=?, cmv_serostatus=?, liver_steatosis=?, glomerular_filtration_rate=? WHERE id=?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            int i = 1;
            ps.setString(i++, recipient.getName());
            ps.setInt(i++, recipient.getAge());
            ps.setString(i++, recipient.getGender());
            ps.setDate(i++, new java.sql.Date(recipient.getDateOfBirth().getTime()));
            ps.setString(i++, recipient.getBloodGroup());
            ps.setString(i++, recipient.getOrganNeeded());
            ps.setString(i++, recipient.getUrgencyLevel());
            ps.setString(i++, recipient.getPhoneNumber());
            ps.setString(i++, recipient.getEmail());
            ps.setString(i++, recipient.getAddress());
            ps.setString(i++, recipient.getDiagnosis());
            ps.setDouble(i++, recipient.getWeightKg());
            ps.setDouble(i++, recipient.getHeightCm());
            ps.setBoolean(i++, recipient.isHasCommunicableDisease());
            ps.setString(i++, recipient.getMedicalHistory());
            ps.setString(i++, recipient.getHla_a1());
            ps.setString(i++, recipient.getHla_a2());
            ps.setString(i++, recipient.getHla_b1());
            ps.setString(i++, recipient.getHla_b2());
            ps.setString(i++, recipient.getHla_dr1());
            ps.setString(i++, recipient.getHla_dr2());
            ps.setInt(i++, recipient.getPraPercent());
            ps.setString(i++, recipient.getCmvSerostatus());
            ps.setString(i++, recipient.getLiverSteatosis());
            ps.setDouble(i++, recipient.getGlomerularFiltrationRate());
            ps.setInt(i++, recipient.getId()); // WHERE ID = ?

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Get all recipients (READ)
    public List<Recipient> getAllRecipients() {
        List<Recipient> recipients = new ArrayList<>();
        String sql = "SELECT * FROM recipients";
        try (PreparedStatement ps = connection.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                recipients.add(mapResultSetToRecipient(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return recipients;
    }
    
    // Get recipients specific to a hospital ID (READ - Filtered)
    public List<Recipient> getRecipientsByHospitalId(int hospitalId) {
        List<Recipient> recipients = new ArrayList<>();
        String sql = "SELECT * FROM recipients WHERE hospital_id = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, hospitalId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    recipients.add(mapResultSetToRecipient(rs));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return recipients;
    }

    // Get a single recipient by ID (READ - Single)
    public Recipient getRecipientById(int id) {
        String sql = "SELECT * FROM recipients WHERE id = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToRecipient(rs);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // Update recipient status (UPDATE - Status Only)
    public boolean updateRecipientStatus(int id, String newStatus) {
        String sql = "UPDATE recipients SET status = ? WHERE id = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, newStatus);
            ps.setInt(2, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Delete a recipient (DELETE)
    public boolean deleteRecipient(int id) {
        String sql = "DELETE FROM recipients WHERE id = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    } // CLOSING BRACE ADDED HERE

    // Get count of all recipients
    public int getRecipientCount() {
        String sql = "SELECT COUNT(*) FROM recipients";
        try (PreparedStatement ps = connection.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    // Get count of urgent recipients
    public int getUrgentRecipientCount() {
        String sql = "SELECT COUNT(*) FROM recipients WHERE urgency_level = 'Urgent' AND status = 'Waiting'";
        try (PreparedStatement ps = connection.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    // Helper method to map ResultSet to Recipient object
    private Recipient mapResultSetToRecipient(ResultSet rs) throws SQLException {
        Recipient r = new Recipient();
        r.setId(rs.getInt("id"));
        r.setName(rs.getString("name"));
        r.setAge(rs.getInt("age"));
        r.setGender(rs.getString("gender"));
        r.setDateOfBirth(rs.getDate("date_of_birth"));
        r.setBloodGroup(rs.getString("blood_group"));
        r.setOrganNeeded(rs.getString("organ_needed"));
        r.setUrgencyLevel(rs.getString("urgency_level"));
        r.setPhoneNumber(rs.getString("phone_number"));
        r.setEmail(rs.getString("email"));
        r.setAddress(rs.getString("address"));
        r.setDiagnosis(rs.getString("diagnosis"));
        r.setWeightKg(rs.getDouble("weight_kg"));
        r.setHeightCm(rs.getDouble("height_cm"));
        r.setHasCommunicableDisease(rs.getBoolean("has_communicable_disease"));
        r.setMedicalHistory(rs.getString("medical_history"));
        r.setStatus(rs.getString("status"));
        r.setHospitalId(rs.getInt("hospital_id"));
        r.setHla_a1(rs.getString("hla_a1"));
        r.setHla_a2(rs.getString("hla_a2"));
        r.setHla_b1(rs.getString("hla_b1"));
        r.setHla_b2(rs.getString("hla_b2"));
        r.setHla_dr1(rs.getString("hla_dr1"));
        r.setHla_dr2(rs.getString("hla_dr2"));
        r.setPraPercent(rs.getInt("pra_percent"));
        r.setCmvSerostatus(rs.getString("cmv_serostatus"));
        r.setLiverSteatosis(rs.getString("liver_steatosis"));
        r.setGlomerularFiltrationRate(rs.getDouble("glomerular_filtration_rate"));
        
        return r;
    }
}