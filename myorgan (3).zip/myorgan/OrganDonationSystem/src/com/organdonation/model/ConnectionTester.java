package com.organdonation.model;

import java.sql.Connection;

public class ConnectionTester {

    public static void main(String[] args) {
        System.out.println("--- Database Connection Test ---");
        System.out.println("Attempting to get a connection...");

        // Call the getConnection() method from your DBConnection class
        Connection conn = DBConnection.getConnection();

        // Check if the connection was successful
        if (conn != null) {
            System.out.println("\nSUCCESS!");
            System.out.println("Connection to the database was successful.");
            System.out.println("You can now run your main App.java file.");
            try {
                conn.close(); // Close the connection after testing
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            System.err.println("\nFAILURE!");
            System.err.println("Failed to make connection to the database.");
            System.err.println("Please check the red error messages above this text in the console.");
            System.err.println("Also, double-check that your XAMPP MySQL server is running.");
        }
    }
}