package com.organdonation.model;

import java.util.Date;

public class Donor {
    private int id;
    private String name;
    private int age;
    private String gender;
    private Date dateOfBirth;
    private String bloodGroup;
    private String organDonating;
    private String phoneNumber;
    private String email;
    private String address;
    private String emergencyContactName;
    private String emergencyContactPhone;
    private double weightKg;
    private double heightCm;
    private boolean hasDiseases;
    private String medicalHistory;
    // New detailed HLA fields
    private String hla_a1;
    private String hla_a2;
    private String hla_b1;
    private String hla_b2;
    private String hla_dr1;
    private String hla_dr2;
    private String status;
    private int hospitalId;
    
    // NEW MEDICAL FIELDS
    private double glomerularFiltrationRate; // GFR for kidney donors
    private String cmvSerostatus; // CMV status: Positive, Negative, Unknown
    private String liverSteatosis; // Liver fat: None, Mild, Moderate, Severe
    

    // --- Getters and Setters for all fields ---

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public int getAge() { return age; }
    public void setAge(int age) { this.age = age; }
    public String getGender() { return gender; }
    public void setGender(String gender) { this.gender = gender; }
    public Date getDateOfBirth() { return dateOfBirth; }
    public void setDateOfBirth(Date dateOfBirth) { this.dateOfBirth = dateOfBirth; }
    public String getBloodGroup() { return bloodGroup; }
    public void setBloodGroup(String bloodGroup) { this.bloodGroup = bloodGroup; }
    public String getOrganDonating() { return organDonating; }
    public void setOrganDonating(String organDonating) { this.organDonating = organDonating; }
    public String getPhoneNumber() { return phoneNumber; }
    public void setPhoneNumber(String phoneNumber) { this.phoneNumber = phoneNumber; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }
    public String getEmergencyContactName() { return emergencyContactName; }
    public void setEmergencyContactName(String n) { this.emergencyContactName = n; }
    public String getEmergencyContactPhone() { return emergencyContactPhone; }
    public void setEmergencyContactPhone(String p) { this.emergencyContactPhone = p; }
    public double getWeightKg() { return weightKg; }
    public void setWeightKg(double weightKg) { this.weightKg = weightKg; }
    public double getHeightCm() { return heightCm; }
    public void setHeightCm(double heightCm) { this.heightCm = heightCm; }
    public boolean isHasDiseases() { return hasDiseases; }
    public void setHasDiseases(boolean hasDiseases) { this.hasDiseases = hasDiseases; }
    public String getMedicalHistory() { return medicalHistory; }
    public void setMedicalHistory(String medicalHistory) { this.medicalHistory = medicalHistory; }
    public String getHla_a1() { return hla_a1; }
    public void setHla_a1(String hla_a1) { this.hla_a1 = hla_a1; }
    public String getHla_a2() { return hla_a2; }
    public void setHla_a2(String hla_a2) { this.hla_a2 = hla_a2; }
    public String getHla_b1() { return hla_b1; }
    public void setHla_b1(String hla_b1) { this.hla_b1 = hla_b1; }
    public String getHla_b2() { return hla_b2; }
    public void setHla_b2(String hla_b2) { this.hla_b2 = hla_b2; }
    public String getHla_dr1() { return hla_dr1; }
    public void setHla_dr1(String hla_dr1) { this.hla_dr1 = hla_dr1; }
    public String getHla_dr2() { return hla_dr2; }
    public void setHla_dr2(String hla_dr2) { this.hla_dr2 = hla_dr2; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public int getHospitalId() { return hospitalId; }
    public void setHospitalId(int hospitalId) { this.hospitalId = hospitalId; }
    
    // --- NEW MEDICAL FIELD GETTERS AND SETTERS ---
    
    public double getGlomerularFiltrationRate() { return glomerularFiltrationRate; }
    public void setGlomerularFiltrationRate(double glomerularFiltrationRate) { 
        this.glomerularFiltrationRate = glomerularFiltrationRate; 
    }
    
    public String getCmvSerostatus() { return cmvSerostatus; }
    public void setCmvSerostatus(String cmvSerostatus) { 
        this.cmvSerostatus = cmvSerostatus; 
    }
    
    public String getLiverSteatosis() { return liverSteatosis; }
    public void setLiverSteatosis(String liverSteatosis) { 
        this.liverSteatosis = liverSteatosis; 
    }
    
    // --- NEW BMI CALCULATION METHODS ---
    
    /**
     * Calculates BMI using weight in kg and height in cm
     * Formula: BMI = weight(kg) / (height(m) * height(m))
     */
    public double calculateBMI() {
        if (heightCm > 0) {
            double heightInMeters = heightCm / 100.0;
            return weightKg / (heightInMeters * heightInMeters);
        }
        return 0;
    }
    
    /**
     * Returns BMI category based on calculated BMI
     */
    public String getBMICategory() {
        double bmi = calculateBMI();
        if (bmi == 0) return "Unknown";
        else if (bmi < 18.5) return "Underweight";
        else if (bmi < 25) return "Normal weight";
        else if (bmi < 30) return "Overweight";
        else return "Obese";
    }
    
    /**
     * Returns formatted BMI string with category
     */
    public String getFormattedBMI() {
        double bmi = calculateBMI();
        if (bmi == 0) return "BMI: Not available";
        return String.format("BMI: %.1f (%s)", bmi, getBMICategory());
    }
    
    /**
     * Checks if donor's BMI is within acceptable range for organ donation
     * Generally, BMI between 18.5 and 35 is acceptable for most organ donations
     */
    public boolean isBMIAcceptableForDonation() {
        double bmi = calculateBMI();
        return bmi >= 18.5 && bmi <= 35;
    }
    
    /**
     * Gets BMI status for donation with reason
     */
    public String getBMIDonationStatus() {
        double bmi = calculateBMI();
        if (bmi == 0) return "Height/Weight data missing";
        else if (bmi < 18.5) return "Underweight - may not be suitable";
        else if (bmi <= 30) return "Within acceptable range";
        else if (bmi <= 35) return "Overweight - requires medical evaluation";
        else return "Obese - may not be suitable";
    }
    
    // --- NEW MEDICAL VALIDATION METHODS ---
    
    /**
     * Checks if kidney function is suitable for donation
     * Normal GFR is 90+ ml/min/1.73m²
     */
    public boolean isKidneyFunctionSuitable() {
        if ("Kidney".equals(this.organDonating)) {
            return glomerularFiltrationRate >= 90;
        }
        return true; // Not donating kidney, so no issue
    }
    
    /**
     * Checks if liver is suitable for donation based on steatosis
     */
    public boolean isLiverSuitable() {
        if ("Liver".equals(this.organDonating)) {
            return !"Severe".equals(liverSteatosis);
        }
        return true; // Not donating liver, so no issue
    }
    
    /**
     * Gets comprehensive medical suitability status
     */
    public String getMedicalSuitabilityStatus() {
        StringBuilder status = new StringBuilder();
        
        if ("Kidney".equals(this.organDonating)) {
            if (glomerularFiltrationRate < 90) {
                status.append("Low GFR (").append(glomerularFiltrationRate).append(") - may affect kidney donation. ");
            } else {
                status.append("Good kidney function. ");
            }
        }
        
        if ("Liver".equals(this.organDonating)) {
            if ("Severe".equals(liverSteatosis)) {
                status.append("Severe liver steatosis - not suitable for donation. ");
            } else if ("Moderate".equals(liverSteatosis)) {
                status.append("Moderate liver steatosis - requires evaluation. ");
            } else {
                status.append("Liver condition acceptable. ");
            }
        }
        
        // CMV status information
        if (cmvSerostatus != null && !"Unknown".equals(cmvSerostatus)) {
            status.append("CMV ").append(cmvSerostatus).append(". ");
        }
        
        if (status.length() == 0) {
            status.append("Medical parameters within acceptable range.");
        }
        
        return status.toString();
    }
    
    /**
     * Checks if donor meets all medical criteria for donation
     */
    public boolean meetsAllMedicalCriteria() {
        boolean bmiOk = isBMIAcceptableForDonation();
        boolean kidneyOk = isKidneyFunctionSuitable();
        boolean liverOk = isLiverSuitable();
        boolean noMajorDiseases = !hasDiseases;
        
        return bmiOk && kidneyOk && liverOk && noMajorDiseases;
    }
}