package com.organdonation.model;

public class AgeValidator {
    
    // Age limits for different organ donations (Donors)
    public static boolean isValidDonorAge(int age, String organ) {
        if (organ == null) return false;
        
        switch (organ.toLowerCase()) {
            case "kidney":
                return age >= 18 && age <= 70;
            case "liver":
                return age >= 18 && age <= 65;
            case "heart":
                return age >= 18 && age <= 55;
            case "lungs":
                return age >= 18 && age <= 65;
            case "pancreas":
                return age >= 18 && age <= 50;
            case "eyes":
                return age >= 18 && age <= 75;
            case "tissue":
                return age >= 18 && age <= 70;
            default:
                return age >= 18 && age <= 65;
        }
    }
    
    // Age limits for recipients (generally more flexible)
    public static boolean isValidRecipientAge(int age, String organ) {
        if (organ == null) return false;
        
        // Recipients can be older than donors for some organs
        switch (organ.toLowerCase()) {
            case "kidney":
                return age <= 75;  // Kidney recipients can be older
            case "liver":
                return age <= 70;
            case "heart":
                return age <= 70;
            case "lungs":
                return age <= 70;
            case "pancreas":
                return age <= 60;
            case "eyes":
                return age <= 85;  // Cornea recipients have wider age range
            case "tissue":
                return age <= 75;
            default:
                return age <= 80;
        }
    }
    
    // Get age requirements as formatted string
    public static String getAgeRequirements(String organ, boolean isDonor) {
        if (organ == null) return "18-65 years";
        
        if (isDonor) {
            switch (organ.toLowerCase()) {
                case "kidney": return "18-70 years";
                case "liver": return "18-65 years"; 
                case "heart": return "18-55 years";
                case "lungs": return "18-65 years";
                case "pancreas": return "18-50 years";
                case "eyes": return "18-75 years";
                case "tissue": return "18-70 years";
                default: return "18-65 years";
            }
        } else {
            switch (organ.toLowerCase()) {
                case "kidney": return "Up to 75 years";
                case "liver": return "Up to 70 years";
                case "heart": return "Up to 70 years";
                case "lungs": return "Up to 70 years";
                case "pancreas": return "Up to 60 years";
                case "eyes": return "Up to 85 years";
                case "tissue": return "Up to 75 years";
                default: return "Up to 80 years";
            }
        }
    }
    
    // Check if age difference between donor and recipient is acceptable
    public static boolean isAgeDifferenceAcceptable(int donorAge, int recipientAge, String organ) {
        int ageDifference = Math.abs(donorAge - recipientAge);
        
        switch (organ.toLowerCase()) {
            case "kidney":
                return ageDifference <= 20;  // Kidney allows wider age difference
            case "liver":
                return ageDifference <= 15;
            case "heart":
                return ageDifference <= 10;  // Heart requires closer age match
            case "lungs":
                return ageDifference <= 15;
            case "pancreas":
                return ageDifference <= 15;
            default:
                return ageDifference <= 20;
        }
    }
    
    // Get ideal age range for matching
    public static String getIdealAgeRange(String organ) {
        switch (organ.toLowerCase()) {
            case "kidney": return "Donor: 18-70, Recipient: up to 75";
            case "liver": return "Donor: 18-65, Recipient: up to 70";
            case "heart": return "Donor: 18-55, Recipient: up to 70";
            case "lungs": return "Donor: 18-65, Recipient: up to 70";
            case "pancreas": return "Donor: 18-50, Recipient: up to 60";
            case "eyes": return "Donor: 18-75, Recipient: up to 85";
            case "tissue": return "Donor: 18-70, Recipient: up to 75";
            default: return "Donor: 18-65, Recipient: up to 80";
        }
    }
}