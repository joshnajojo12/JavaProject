package com.organdonation.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class HospitalDAO {

    private Connection connection;

    public HospitalDAO() {
        this.connection = DBConnection.getConnection();
    }

    // Register a new hospital (from LandingController)
    public boolean registerHospital(Hospital hospital) {
        String sql = "INSERT INTO hospitals (name, email, password) VALUES (?, ?, ?)";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, hospital.getName());
            ps.setString(2, hospital.getEmail());
            ps.setString(3, hospital.getPassword()); // In a real app, hash this!
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Validate hospital login (from HospitalLoginController)
    public Hospital validate(String email, String password) {
        String sql = "SELECT * FROM hospitals WHERE email = ? AND password = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, email);
            ps.setString(2, password);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Hospital hospital = new Hospital();
                    hospital.setId(rs.getInt("id"));
                    hospital.setName(rs.getString("name"));
                    hospital.setEmail(rs.getString("email"));
                    return hospital;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // Get hospital by ID (NEEDED FOR NOTIFICATIONS)
    public Hospital getHospitalById(int id) {
        String sql = "SELECT * FROM hospitals WHERE id = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Hospital hospital = new Hospital();
                    hospital.setId(rs.getInt("id"));
                    hospital.setName(rs.getString("name"));
                    hospital.setEmail(rs.getString("email"));
                    return hospital;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}