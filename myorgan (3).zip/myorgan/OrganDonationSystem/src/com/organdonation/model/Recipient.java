package com.organdonation.model;

import java.util.Date;

public class Recipient {
    private int id;
    private String name;
    private int age;
    private String gender;
    private Date dateOfBirth;
    private String bloodGroup;
    private String organNeeded;
    private String urgencyLevel;
    private String phoneNumber;
    private String email;
    private String address;
    private String diagnosis;
    private double weightKg;
    private double heightCm;
    private boolean hasCommunicableDisease;
    private String medicalHistory;
    // New detailed HLA and PRA fields
    private String hla_a1;
    private String hla_a2;
    private String hla_b1;
    private String hla_b2;
    private String hla_dr1;
    private String hla_dr2;
    private int praPercent;
    private String status;
    private int hospitalId;
    
    // NEW MEDICAL FIELDS
    private double glomerularFiltrationRate; // GFR for kidney recipients
    private String cmvSerostatus; // CMV status: Positive, Negative, Unknown
    private String liverSteatosis; // Liver fat: None, Mild, Moderate, Severe
    
    // --- Getters and Setters for all fields ---

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public int getAge() { return age; }
    public void setAge(int age) { this.age = age; }
    public String getGender() { return gender; }
    public void setGender(String gender) { this.gender = gender; }
    public Date getDateOfBirth() { return dateOfBirth; }
    public void setDateOfBirth(Date dateOfBirth) { this.dateOfBirth = dateOfBirth; }
    public String getBloodGroup() { return bloodGroup; }
    public void setBloodGroup(String bloodGroup) { this.bloodGroup = bloodGroup; }
    public String getOrganNeeded() { return organNeeded; }
    public void setOrganNeeded(String organNeeded) { this.organNeeded = organNeeded; }
    public String getUrgencyLevel() { return urgencyLevel; }
    public void setUrgencyLevel(String urgencyLevel) { this.urgencyLevel = urgencyLevel; }
    public String getPhoneNumber() { return phoneNumber; }
    public void setPhoneNumber(String phoneNumber) { this.phoneNumber = phoneNumber; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }
    public String getDiagnosis() { return diagnosis; }
    public void setDiagnosis(String diagnosis) { this.diagnosis = diagnosis; }
    public double getWeightKg() { return weightKg; }
    public void setWeightKg(double weightKg) { this.weightKg = weightKg; }
    public double getHeightCm() { return heightCm; }
    public void setHeightCm(double heightCm) { this.heightCm = heightCm; }
    public boolean isHasCommunicableDisease() { return hasCommunicableDisease; }
    public void setHasCommunicableDisease(boolean hacd) { this.hasCommunicableDisease = hacd; }
    public String getMedicalHistory() { return medicalHistory; }
    public void setMedicalHistory(String medicalHistory) { this.medicalHistory = medicalHistory; }
    public String getHla_a1() { return hla_a1; }
    public void setHla_a1(String hla_a1) { this.hla_a1 = hla_a1; }
    public String getHla_a2() { return hla_a2; }
    public void setHla_a2(String hla_a2) { this.hla_a2 = hla_a2; }
    public String getHla_b1() { return hla_b1; }
    public void setHla_b1(String hla_b1) { this.hla_b1 = hla_b1; }
    public String getHla_b2() { return hla_b2; }
    public void setHla_b2(String hla_b2) { this.hla_b2 = hla_b2; }
    public String getHla_dr1() { return hla_dr1; }
    public void setHla_dr1(String hla_dr1) { this.hla_dr1 = hla_dr1; }
    public String getHla_dr2() { return hla_dr2; }
    public void setHla_dr2(String hla_dr2) { this.hla_dr2 = hla_dr2; }
    public int getPraPercent() { return praPercent; }
    public void setPraPercent(int praPercent) { this.praPercent = praPercent; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public int getHospitalId() { return hospitalId; }
    public void setHospitalId(int hospitalId) { this.hospitalId = hospitalId; }
    
    // --- NEW MEDICAL FIELD GETTERS AND SETTERS ---
    
    public double getGlomerularFiltrationRate() { return glomerularFiltrationRate; }
    public void setGlomerularFiltrationRate(double glomerularFiltrationRate) { 
        this.glomerularFiltrationRate = glomerularFiltrationRate; 
    }
    
    public String getCmvSerostatus() { return cmvSerostatus; }
    public void setCmvSerostatus(String cmvSerostatus) { 
        this.cmvSerostatus = cmvSerostatus; 
    }
    
    public String getLiverSteatosis() { return liverSteatosis; }
    public void setLiverSteatosis(String liverSteatosis) { 
        this.liverSteatosis = liverSteatosis; 
    }
    
    // --- NEW BMI CALCULATION METHODS ---
    
    /**
     * Calculates BMI using weight in kg and height in cm
     * Formula: BMI = weight(kg) / (height(m) * height(m))
     */
    public double calculateBMI() {
        if (heightCm > 0) {
            double heightInMeters = heightCm / 100.0;
            return weightKg / (heightInMeters * heightInMeters);
        }
        return 0;
    }
    
    /**
     * Returns BMI category based on calculated BMI
     */
    public String getBMICategory() {
        double bmi = calculateBMI();
        if (bmi == 0) return "Unknown";
        else if (bmi < 18.5) return "Underweight";
        else if (bmi < 25) return "Normal weight";
        else if (bmi < 30) return "Overweight";
        else return "Obese";
    }
    
    /**
     * Returns formatted BMI string with category
     */
    public String getFormattedBMI() {
        double bmi = calculateBMI();
        if (bmi == 0) return "BMI: Not available";
        return String.format("BMI: %.1f (%s)", bmi, getBMICategory());
    }
    
    /**
     * Checks if recipient's BMI is within acceptable range for transplant
     * Recipients can have wider BMI range depending on organ and urgency
     */
    public boolean isBMIAcceptableForTransplant() {
        double bmi = calculateBMI();
        // Wider range for recipients, especially for urgent cases
        return bmi >= 16.0 && bmi <= 40.0;
    }
    
    /**
     * Gets BMI status for transplant with medical considerations
     */
    public String getBMITransplantStatus() {
        double bmi = calculateBMI();
        if (bmi == 0) return "Height/Weight data missing";
        else if (bmi < 16.0) return "Severely underweight - high surgical risk";
        else if (bmi < 18.5) return "Underweight - requires nutritional support";
        else if (bmi <= 30) return "Good candidate for transplant";
        else if (bmi <= 35) return "Overweight - requires medical evaluation";
        else if (bmi <= 40) return "Obese - higher surgical risk, case-by-case";
        else return "Severely obese - very high surgical risk";
    }
    
    // --- NEW MEDICAL ASSESSMENT METHODS ---
    
    /**
     * Determines kidney disease stage based on GFR
     */
    public String getKidneyDiseaseStage() {
        if (glomerularFiltrationRate >= 90) return "Stage 1 - Normal";
        else if (glomerularFiltrationRate >= 60) return "Stage 2 - Mild";
        else if (glomerularFiltrationRate >= 30) return "Stage 3 - Moderate";
        else if (glomerularFiltrationRate >= 15) return "Stage 4 - Severe";
        else return "Stage 5 - Kidney Failure";
    }
    
    /**
     * Checks if liver condition indicates need for transplant
     */
    public boolean hasSevereLiverCondition() {
        if ("Liver".equals(this.organNeeded)) {
            return "Severe".equals(liverSteatosis) || "Moderate".equals(liverSteatosis);
        }
        return false;
    }
    
    /**
     * Gets CMV matching requirements
     * CMV-negative recipients should ideally get CMV-negative organs
     */
    public String getCMVMatchRequirement() {
        if ("Negative".equals(cmvSerostatus)) {
            return "Requires CMV-negative donor";
        } else if ("Positive".equals(cmvSerostatus)) {
            return "Can accept CMV-positive or negative donor";
        }
        return "CMV status unknown";
    }
    
    /**
     * Gets comprehensive medical assessment
     */
    public String getMedicalAssessment() {
        StringBuilder assessment = new StringBuilder();
        
        if ("Kidney".equals(this.organNeeded)) {
            assessment.append("Kidney Disease Stage: ").append(getKidneyDiseaseStage()).append("\n");
            assessment.append("GFR: ").append(glomerularFiltrationRate).append(" ml/min/1.73m²\n");
        }
        
        if ("Liver".equals(this.organNeeded)) {
            assessment.append("Liver Steatosis: ").append(liverSteatosis).append("\n");
            if (hasSevereLiverCondition()) {
                assessment.append("Liver condition indicates transplant need.\n");
            }
        }
        
        if (cmvSerostatus != null && !"Unknown".equals(cmvSerostatus)) {
            assessment.append("CMV Status: ").append(cmvSerostatus).append(" - ").append(getCMVMatchRequirement()).append("\n");
        }
        
        if (assessment.length() == 0) {
            assessment.append("Basic medical assessment complete.");
        }
        
        return assessment.toString();
    }
    
    /**
     * Gets comprehensive health summary including BMI, PRA and new medical fields
     */
    public String getHealthSummary() {
        StringBuilder summary = new StringBuilder();
        summary.append("Organ Needed: ").append(organNeeded).append("\n");
        summary.append("Urgency: ").append(urgencyLevel).append("\n");
        summary.append("BMI: ").append(getFormattedBMI()).append("\n");
        summary.append("PRA: ").append(praPercent).append("%\n");
        
        // Add new medical fields to summary
        if ("Kidney".equals(this.organNeeded) && glomerularFiltrationRate > 0) {
            summary.append("GFR: ").append(glomerularFiltrationRate).append(" (").append(getKidneyDiseaseStage()).append(")\n");
        }
        
        if (cmvSerostatus != null && !"Unknown".equals(cmvSerostatus)) {
            summary.append("CMV: ").append(cmvSerostatus).append("\n");
        }
        
        if (liverSteatosis != null && !"None".equals(liverSteatosis)) {
            summary.append("Liver Steatosis: ").append(liverSteatosis).append("\n");
        }
        
        if (praPercent > 50) {
            summary.append("High PRA - may require specialized matching");
        } else if (praPercent > 20) {
            summary.append("Moderate PRA - consider HLA matching carefully");
        } else {
            summary.append("Low PRA - standard matching acceptable");
        }
        
        return summary.toString();
    }
    
    /**
     * Checks overall transplant suitability considering all medical factors
     */
    public boolean isMedicallySuitableForTransplant() {	
        boolean bmiOk = isBMIAcceptableForTransplant();
        boolean noCommunicableDisease = !hasCommunicableDisease;
        
        // For kidney recipients, very low GFR indicates need for transplant
        boolean kidneyConditionOk = true;
        if ("Kidney".equals(this.organNeeded)) {
            kidneyConditionOk = glomerularFiltrationRate < 15; // Stage 5 kidney failure
        }
        
        return bmiOk && noCommunicableDisease && kidneyConditionOk;
    }
}