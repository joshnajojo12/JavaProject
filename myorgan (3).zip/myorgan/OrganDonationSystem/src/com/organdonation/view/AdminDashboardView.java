package com.organdonation.view;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionListener;

public class AdminDashboardView extends JFrame {
    private static final long serialVersionUID = 1L;
    
    public DefaultTableModel donorModel, recipientModel, matchModel;
    private JLabel totalDonorsValueLabel, totalRecipientsValueLabel, urgentRecipientsValueLabel;
    private JButton approveMatchButton, deleteDonorButton, findMatchButton;
    private JTable matchTable, donorTable, recipientTable;

    // --- Button declarations ---
    private JButton deleteRecipientButton;
    private JButton logoutButton;
    private JButton addDonorButton, editDonorButton;
    private JButton addRecipientButton;
    
    // --- Medical Report Buttons ---
    private JButton viewDonorMedicalReportButton, viewRecipientMedicalReportButton;

    // --- Labels for dashboard statistics ---
    private JLabel availableKidneyDonorsValueLabel, availableBoneMarrowDonorsValueLabel, availableLiverDonorsValueLabel, matchesCompletedValueLabel;

    // NEW: Notification Bell
    private NotificationBell notificationBell;

    public AdminDashboardView() {
        setTitle("Organ Donation Management System - Admin Portal");
        setSize(1100, 750); // Increased size for better spacing
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        
        createHeader();
        
        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.setFont(new Font("Arial", Font.BOLD, 14));
        tabbedPane.addTab("Dashboard", createDashboardPanel());
        tabbedPane.addTab("Manage Donors", createDonorPanel());
        tabbedPane.addTab("Manage Recipients", createRecipientPanel());
        tabbedPane.addTab("Donor-Recipient Matching", createMatchingPanel());
        add(tabbedPane, BorderLayout.CENTER);
    }
    
    private void createHeader() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(new Color(45, 118, 232));
        header.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));
        
        // Title on left
        JLabel title = new JLabel("Organ Donation Management System - Admin Portal");
        title.setForeground(Color.WHITE);
        title.setFont(new Font("Arial", Font.BOLD, 20));
        header.add(title, BorderLayout.WEST);
        
        // MODIFIED: Right panel for notification and logout
        JPanel rightHeaderPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        rightHeaderPanel.setOpaque(false); // Make it transparent

        // NEW: Notification Bell
        notificationBell = new NotificationBell();
        rightHeaderPanel.add(notificationBell);

        // Logout button
        logoutButton = new JButton("Logout");
        logoutButton.setBackground(new Color(220, 53, 69));
        logoutButton.setForeground(Color.WHITE);
        logoutButton.setFont(new Font("Arial", Font.BOLD, 14));
        logoutButton.setPreferredSize(new Dimension(100, 35));
        logoutButton.setFocusPainted(false);
        rightHeaderPanel.add(logoutButton);
        
        header.add(rightHeaderPanel, BorderLayout.EAST);
        add(header, BorderLayout.NORTH);
    }
    
    private JPanel createDashboardPanel() {
        JPanel panel = new JPanel(new GridLayout(2, 4, 15, 15)); // 2x4 grid for better alignment
        panel.setBorder(BorderFactory.createEmptyBorder(25, 25, 25, 25));
        panel.setBackground(new Color(240, 245, 250));
        
        totalDonorsValueLabel = new JLabel("0", SwingConstants.CENTER);
        totalRecipientsValueLabel = new JLabel("0", SwingConstants.CENTER);
        urgentRecipientsValueLabel = new JLabel("0", SwingConstants.CENTER);
        availableKidneyDonorsValueLabel = new JLabel("0", SwingConstants.CENTER);
        availableBoneMarrowDonorsValueLabel = new JLabel("0", SwingConstants.CENTER);
        availableLiverDonorsValueLabel = new JLabel("0", SwingConstants.CENTER);
        matchesCompletedValueLabel = new JLabel("0", SwingConstants.CENTER);
        
        // Create cards in proper order
        panel.add(createCard("Total Donors", totalDonorsValueLabel, new Color(70, 130, 180)));
        panel.add(createCard("Total Recipients", totalRecipientsValueLabel, new Color(60, 179, 113)));
        panel.add(createCard("Urgent Recipients", urgentRecipientsValueLabel, new Color(205, 92, 92)));
        panel.add(createCard("Kidney Donors", availableKidneyDonorsValueLabel, new Color(255, 165, 0)));
        panel.add(createCard("Bone Marrow Donors", availableBoneMarrowDonorsValueLabel, new Color(147, 112, 219)));
        panel.add(createCard("Liver Donors", availableLiverDonorsValueLabel, new Color(50, 205, 50)));
        panel.add(createCard("Matches Completed", matchesCompletedValueLabel, new Color(106, 90, 205)));
        
        return panel;
    }
    
    private JPanel createCard(String title, JLabel valueLabel, Color color) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(color);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(color.darker(), 2),
            BorderFactory.createEmptyBorder(20, 15, 20, 15)
        ));
        
        JLabel titleLabel = new JLabel("<html><center>" + title + "</center></html>");
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 16));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        
        valueLabel.setForeground(Color.WHITE);
        valueLabel.setFont(new Font("Arial", Font.BOLD, 42));
        valueLabel.setHorizontalAlignment(SwingConstants.CENTER);
        
        card.add(titleLabel, BorderLayout.NORTH);
        card.add(valueLabel, BorderLayout.CENTER);
        
        return card;
    }
    
    private JPanel createDonorPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        
        String[] columns = {"ID", "Name", "Age", "Blood Group", "Organ", "Status"};
        donorModel = new DefaultTableModel(columns, 0);
        donorTable = new JTable(donorModel);
        donorTable.setSelectionBackground(new Color(173, 216, 230));
        donorTable.setFont(new Font("Arial", Font.PLAIN, 12));
        JScrollPane scrollPane = new JScrollPane(donorTable);
        scrollPane.setPreferredSize(new Dimension(800, 400));
        panel.add(scrollPane, BorderLayout.CENTER);
        
        JPanel controls = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        controls.setBorder(BorderFactory.createTitledBorder("Donor Management Actions"));
        
        // Add Donor button with professional styling
        addDonorButton = new JButton("Add Donor");
        styleButton(addDonorButton, new Color(70, 130, 180));
        addDonorButton.addActionListener(e -> openDonorRegistrationForm());
        controls.add(addDonorButton);
        
        // Edit Donor button
        editDonorButton = new JButton("Edit Donor");
        styleButton(editDonorButton, new Color(100, 149, 237));
        controls.add(editDonorButton);
        
        // Delete Donor button
        deleteDonorButton = new JButton("Delete Donor");
        styleButton(deleteDonorButton, new Color(220, 53, 69));
        controls.add(deleteDonorButton);
        
        // Medical Report Button for Donors
        viewDonorMedicalReportButton = new JButton("View Medical Report");
        styleButton(viewDonorMedicalReportButton, new Color(60, 179, 113));
        controls.add(viewDonorMedicalReportButton);
        
        panel.add(controls, BorderLayout.SOUTH);
        
        return panel;
    }
    
    private JPanel createMatchingPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        
        String[] columns = {"Donor ID", "Donor Name", "Recipient ID", "Recipient Name", "Organ", "Status"};
        matchModel = new DefaultTableModel(columns, 0);
        matchTable = new JTable(matchModel);
        matchTable.setSelectionBackground(new Color(173, 216, 230));
        matchTable.setFont(new Font("Arial", Font.PLAIN, 12));
        panel.add(new JScrollPane(matchTable), BorderLayout.CENTER);
        
        JPanel controls = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        controls.setBorder(BorderFactory.createTitledBorder("Match Management"));
        
        approveMatchButton = new JButton("Approve Selected Match");
        styleButton(approveMatchButton, new Color(60, 179, 113));
        controls.add(approveMatchButton);
        
        panel.add(controls, BorderLayout.SOUTH);
        
        return panel;
    }

    private JPanel createRecipientPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        
        String[] columns = {"ID", "Name", "Age", "Organ Needed", "Urgency", "Status"};
        recipientModel = new DefaultTableModel(columns, 0);
        recipientTable = new JTable(recipientModel);
        recipientTable.setSelectionBackground(new Color(173, 216, 230));
        recipientTable.setFont(new Font("Arial", Font.PLAIN, 12));
        panel.add(new JScrollPane(recipientTable), BorderLayout.CENTER);
        
        JPanel controls = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        controls.setBorder(BorderFactory.createTitledBorder("Recipient Management Actions"));
        
        // Add Recipient button
        addRecipientButton = new JButton("Add Recipient");
        styleButton(addRecipientButton, new Color(70, 130, 180));
        addRecipientButton.addActionListener(e -> openRecipientRegistrationForm());
        controls.add(addRecipientButton);
        
        // Delete Recipient button
        deleteRecipientButton = new JButton("Delete Recipient");
        styleButton(deleteRecipientButton, new Color(220, 53, 69));
        controls.add(deleteRecipientButton);
        
        // Find Match button
        findMatchButton = new JButton("Find Match for Selected");
        styleButton(findMatchButton, new Color(147, 112, 219));
        controls.add(findMatchButton);
        
        // Medical Report Button for Recipients
        viewRecipientMedicalReportButton = new JButton("View Medical Report");
        styleButton(viewRecipientMedicalReportButton, new Color(60, 179, 113));
        controls.add(viewRecipientMedicalReportButton);
        
        panel.add(controls, BorderLayout.SOUTH);

        return panel;
    }
    
    // Helper method to style buttons consistently
    private void styleButton(JButton button, Color color) {
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Arial", Font.BOLD, 12));
        button.setPreferredSize(new Dimension(160, 35));
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(color.darker(), 1),
            BorderFactory.createEmptyBorder(8, 15, 8, 15)
        ));
    }
    
    // FIXED: Method to open Donor Registration Form
    private void openDonorRegistrationForm() {
        try {
            DonorRegistrationView registrationView = new DonorRegistrationView();
            registrationView.setVisible(true);
            
            int defaultHospitalId = 1;
            new com.organdonation.controller.DonorRegistrationController(registrationView, defaultHospitalId);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, 
                "Error opening donor registration form: " + e.getMessage(), 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }
    
    // FIXED: Method to open Recipient Registration Form
    private void openRecipientRegistrationForm() {
        try {
            RecipientRegistrationView registrationView = new RecipientRegistrationView();
            registrationView.setVisible(true);
            
            int defaultHospitalId = 1;
            new com.organdonation.controller.RecipientRegistrationController(registrationView, defaultHospitalId);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, 
                "Error opening recipient registration form: " + e.getMessage(), 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }
    
    // COMPLETE Dashboard statistics update method
    public void updateDashboardStats(String donors, String recipients, String urgent,
                                   String kidneyDonors, String boneMarrowDonors, 
                                   String matchesCompleted, String liverDonors) {
        totalDonorsValueLabel.setText(donors);
        totalRecipientsValueLabel.setText(recipients);
        urgentRecipientsValueLabel.setText(urgent);
        availableKidneyDonorsValueLabel.setText(kidneyDonors);
        availableBoneMarrowDonorsValueLabel.setText(boneMarrowDonors);
        matchesCompletedValueLabel.setText(matchesCompleted);
        availableLiverDonorsValueLabel.setText(liverDonors);
    }

    // NEW: Getter for the notification bell
    public NotificationBell getNotificationBell() {
        return notificationBell;
    }
    
    // Listener methods
    public void addApproveMatchListener(ActionListener l) {
        approveMatchButton.addActionListener(l);
    }
    
    public int getSelectedMatchRow() {
        return matchTable.getSelectedRow();
    }
    
    public int getDonorIdFromSelectedMatch(int row) {
        return (int) matchModel.getValueAt(row, 0);
    }
    
    public int getRecipientIdFromSelectedMatch(int row) {
        return (int) matchModel.getValueAt(row, 2);
    }
    
    public void addDeleteDonorListener(ActionListener l) {
        deleteDonorButton.addActionListener(l);
    }
    
    public int getSelectedDonorId() {
        int r = donorTable.getSelectedRow();
        return r >= 0 ? (int) donorModel.getValueAt(r, 0) : -1;
    }
    
    public void addFindMatchListener(ActionListener listener) {
        findMatchButton.addActionListener(listener);
    }
    
    public int getSelectedRecipientId() {
        int r = recipientTable.getSelectedRow();
        return r >= 0 ? (int) recipientModel.getValueAt(r, 0) : -1;
    }

    // --- NEW METHOD FOR DELETING A RECIPIENT ---
    public void addDeleteRecipientListener(ActionListener listener) {
        deleteRecipientButton.addActionListener(listener);
    }
    
    // --- NEW METHODS FOR MEDICAL REPORTS ---
    public void addViewDonorMedicalReportListener(ActionListener listener) {
        viewDonorMedicalReportButton.addActionListener(listener);
    }
    
    public void addViewRecipientMedicalReportListener(ActionListener listener) {
        viewRecipientMedicalReportButton.addActionListener(listener);
    }
    
    public void addLogoutListener(ActionListener listener) {
        logoutButton.addActionListener(listener);
    }
    
    // New method for Edit Donor button
    public void addEditDonorListener(ActionListener listener) {
        editDonorButton.addActionListener(listener);
    }
}