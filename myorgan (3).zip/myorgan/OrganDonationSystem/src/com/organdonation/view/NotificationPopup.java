package com.organdonation.view;

import com.organdonation.model.Notification;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.util.List;

public class NotificationPopup {

    private JPopupMenu popupMenu;
    private JList<Notification> notificationList;
    private DefaultListModel<Notification> listModel;
    private JButton markAllReadButton;

    public NotificationPopup() {
        popupMenu = new JPopupMenu();
        popupMenu.setLayout(new BorderLayout());

        listModel = new DefaultListModel<>();
        notificationList = new JList<>(listModel);
        notificationList.setCellRenderer(new NotificationListRenderer());
        notificationList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JScrollPane scrollPane = new JScrollPane(notificationList);
        scrollPane.setPreferredSize(new Dimension(350, 400));
        scrollPane.setBorder(BorderFactory.createEmptyBorder());

        markAllReadButton = new JButton("Mark all as read");
        markAllReadButton.setFocusPainted(false);

        popupMenu.add(scrollPane, BorderLayout.CENTER);
        popupMenu.add(markAllReadButton, BorderLayout.SOUTH);
    }

    public void updateNotifications(List<Notification> notifications) {
        listModel.clear();
        if (notifications.isEmpty()) {
            // Show a "no notifications" message
            JPanel noNotifsPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
            noNotifsPanel.add(new JLabel("No unread notifications."));
            noNotifsPanel.setPreferredSize(new Dimension(350, 50));
            popupMenu.removeAll();
            popupMenu.add(noNotifsPanel, BorderLayout.CENTER);
        } else {
            // Add notifications to the list
            for (Notification n : notifications) {
                listModel.addElement(n);
            }
            // Ensure the main view is back
            popupMenu.removeAll();
            popupMenu.add(new JScrollPane(notificationList), BorderLayout.CENTER);
            popupMenu.add(markAllReadButton, BorderLayout.SOUTH);
        }
    }

    public void show(Component invoker, int x, int y) {
        popupMenu.show(invoker, x, y);
    }

    public void addMarkAllReadListener(ActionListener listener) {
        markAllReadButton.addActionListener(listener);
    }

    public void hide() {
        popupMenu.setVisible(false);
    }
}