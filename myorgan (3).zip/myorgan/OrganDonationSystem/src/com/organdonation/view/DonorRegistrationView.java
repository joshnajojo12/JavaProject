package com.organdonation.view;

import com.organdonation.model.Donor;
import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class DonorRegistrationView extends JFrame {
    private static final long serialVersionUID = 1L;
    
    // Personal Info Components    
    private JTextField nameField, ageField, dobField, phoneField, emailField, addressField;
    private JTextField emergencyNameField, emergencyPhoneField;
    private JRadioButton maleButton, femaleButton, otherButton;
    private ButtonGroup genderGroup;

    // Medical Info Components
    private JComboBox<String> bloodGroupCombo, organCombo;
    private JTextField weightField, heightField;
    private JCheckBox diabetesCheck, cancerCheck, heartDiseaseCheck;
    private JTextArea medicalHistoryArea;
    private JTextField hlaA1Field, hlaA2Field, hlaB1Field, hlaB2Field, hlaDr1Field, hlaDr2Field;
    
    // NEW: BMI Display Components
    private JLabel bmiValueLabel, bmiCategoryLabel, bmiDonationStatusLabel;
    
    // NEW: Medical Field Components
    private JTextField gfrField;
    private JComboBox<String> cmvCombo, liverSteatosisCombo;
    
    private JButton registerButton;

    public DonorRegistrationView() {
        setTitle("Comprehensive Donor Registration");
        setSize(700, 800);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.addTab("Personal & Contact", createPersonalInfoPanel());
        tabbedPane.addTab("Medical Information", createMedicalInfoPanel());

        registerButton = new JButton("Complete Registration");
        registerButton.setBackground(new Color(0, 102, 204));
        registerButton.setForeground(Color.WHITE);
        registerButton.setFont(new Font("Arial", Font.BOLD, 14));
        
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.setBackground(Color.WHITE);
        buttonPanel.add(registerButton);

        add(tabbedPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
        
        // Set visible after all components are added
        setVisible(true);
    }
    
    private JPanel createPersonalInfoPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.WEST;
        
        int row = 0;
        
        // Title
        JLabel titleLabel = new JLabel("Personal Information");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        titleLabel.setForeground(new Color(0, 102, 204));
        gbc.gridx = 0; gbc.gridy = row++; gbc.gridwidth = 2;
        panel.add(titleLabel, gbc);
        gbc.gridwidth = 1;
        
        // Name
        gbc.gridx = 0; gbc.gridy = row;
        panel.add(new JLabel("Full Name:"), gbc);
        gbc.gridx = 1;
        nameField = new JTextField(20);
        nameField.setFont(new Font("Arial", Font.PLAIN, 14));
        panel.add(nameField, gbc);
        row++;
        
        // Date of Birth with Calendar Picker - NEW FEATURE
        gbc.gridx = 0; gbc.gridy = row;
        panel.add(new JLabel("Date of Birth:"), gbc);
        gbc.gridx = 1; gbc.gridy = row;
        
        // Create a panel for date field and calendar button
        JPanel dobPanel = new JPanel(new BorderLayout(5, 0));
        dobField = new JTextField(15);
        dobField.setToolTipText("Click calendar to select date");
        dobField.setFont(new Font("Arial", Font.PLAIN, 14));
        dobPanel.add(dobField, BorderLayout.CENTER);
        
        JButton calendarButton = new JButton("📅");
        calendarButton.setToolTipText("Select date from calendar");
        calendarButton.addActionListener(e -> showCalendarDialog());
        dobPanel.add(calendarButton, BorderLayout.EAST);
        
        panel.add(dobPanel, gbc);
        row++;
        
        // Age (calculated from DOB) - NEW FEATURE
        gbc.gridx = 0; gbc.gridy = row;
        panel.add(new JLabel("Age:"), gbc);
        gbc.gridx = 1; gbc.gridy = row;
        ageField = new JTextField(20);
        ageField.setEditable(false); // Age is calculated automatically
        ageField.setBackground(new Color(240, 240, 240)); // Gray background to indicate read-only
        ageField.setFont(new Font("Arial", Font.PLAIN, 14));
        panel.add(ageField, gbc);
        row++;
        
        // Gender
        gbc.gridx = 0; gbc.gridy = row;
        panel.add(new JLabel("Gender:"), gbc);
        gbc.gridx = 1;
        JPanel genderPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        genderPanel.setBackground(Color.WHITE);
        maleButton = new JRadioButton("Male");
        femaleButton = new JRadioButton("Female");
        otherButton = new JRadioButton("Other");
        genderGroup = new ButtonGroup();
        genderGroup.add(maleButton);
        genderGroup.add(femaleButton);
        genderGroup.add(otherButton);
        genderPanel.add(maleButton);
        genderPanel.add(femaleButton);
        genderPanel.add(otherButton);
        panel.add(genderPanel, gbc);
        row++;
        
        // Phone
        gbc.gridx = 0; gbc.gridy = row;
        panel.add(new JLabel("Phone:"), gbc);
        gbc.gridx = 1;
        phoneField = new JTextField(20);
        phoneField.setFont(new Font("Arial", Font.PLAIN, 14));
        panel.add(phoneField, gbc);
        row++;
        
        // Email
        gbc.gridx = 0; gbc.gridy = row;
        panel.add(new JLabel("Email:"), gbc);
        gbc.gridx = 1;
        emailField = new JTextField(20);
        emailField.setFont(new Font("Arial", Font.PLAIN, 14));
        panel.add(emailField, gbc);
        row++;
        
        // Address
        gbc.gridx = 0; gbc.gridy = row;
        panel.add(new JLabel("Address:"), gbc);
        gbc.gridx = 1;
        addressField = new JTextField(20);
        addressField.setFont(new Font("Arial", Font.PLAIN, 14));
        panel.add(addressField, gbc);
        row++;
        
        // Emergency Contact Name
        gbc.gridx = 0; gbc.gridy = row;
        panel.add(new JLabel("Emergency Contact Name:"), gbc);
        gbc.gridx = 1;
        emergencyNameField = new JTextField(20);
        emergencyNameField.setFont(new Font("Arial", Font.PLAIN, 14));
        panel.add(emergencyNameField, gbc);
        row++;
        
        // Emergency Contact Phone
        gbc.gridx = 0; gbc.gridy = row;
        panel.add(new JLabel("Emergency Contact Phone:"), gbc);
        gbc.gridx = 1;
        emergencyPhoneField = new JTextField(20);
        emergencyPhoneField.setFont(new Font("Arial", Font.PLAIN, 14));
        panel.add(emergencyPhoneField, gbc);
        
        return panel;
    }

    // NEW: Enhanced Calendar Dialog Method with Year Navigation
    private void showCalendarDialog() {
        JDialog calendarDialog = new JDialog(this, "Select Date of Birth", true);
        calendarDialog.setLayout(new BorderLayout());
        calendarDialog.setSize(350, 350);
        calendarDialog.setLocationRelativeTo(this);

        // Create calendar panel
        JPanel calendarPanel = new JPanel(new BorderLayout());
        
        // Month and year navigation
        JPanel navigationPanel = new JPanel(new GridLayout(2, 1));
        JPanel monthPanel = new JPanel(new FlowLayout());
        JPanel yearPanel = new JPanel(new FlowLayout());
        
        JButton prevYearButton = new JButton("<<");
        JButton prevMonthButton = new JButton("←");
        JLabel monthYearLabel = new JLabel("", JLabel.CENTER);
        JButton nextMonthButton = new JButton("→");
        JButton nextYearButton = new JButton(">>");
        
        monthPanel.add(prevYearButton);
        monthPanel.add(prevMonthButton);
        monthPanel.add(monthYearLabel);
        monthPanel.add(nextMonthButton);
        monthPanel.add(nextYearButton);
        
        // Year quick navigation
        JLabel yearLabel = new JLabel("Year: ", JLabel.CENTER);
        JSpinner yearSpinner = new JSpinner(new SpinnerNumberModel(
            Calendar.getInstance().get(Calendar.YEAR), 
            1900, 
            Calendar.getInstance().get(Calendar.YEAR), 
            1
        ));
        JButton goToYearButton = new JButton("Go to Year");
        
        yearPanel.add(yearLabel);
        yearPanel.add(yearSpinner);
        yearPanel.add(goToYearButton);
        
        navigationPanel.add(monthPanel);
        navigationPanel.add(yearPanel);
        
        // Calendar grid
        JPanel daysPanel = new JPanel(new GridLayout(0, 7, 2, 2));
        
        // Initialize calendar
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.DAY_OF_MONTH, 1);
        
        // Update calendar display
        Runnable updateCalendar = () -> {
            daysPanel.removeAll();
            monthYearLabel.setText(new SimpleDateFormat("MMMM yyyy").format(calendar.getTime()));
            
            // Update year spinner to match current calendar year
            yearSpinner.setValue(calendar.get(Calendar.YEAR));
            
            // Add day headers
            String[] days = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};
            for (String day : days) {
                JLabel dayLabel = new JLabel(day, JLabel.CENTER);
                dayLabel.setFont(new Font("Arial", Font.BOLD, 10));
                dayLabel.setBackground(new Color(220, 220, 220));
                dayLabel.setOpaque(true);
                daysPanel.add(dayLabel);
            }
            
            // Get first day of month and number of days
            int firstDayOfWeek = calendar.get(Calendar.DAY_OF_WEEK);
            int daysInMonth = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
            
            // Add empty cells for days before first day of month
            for (int i = 1; i < firstDayOfWeek; i++) {
                daysPanel.add(new JLabel(""));
            }
            
            // Add day buttons
            Calendar today = Calendar.getInstance();
            today.add(Calendar.YEAR, -18); // 18 years ago
            
            for (int day = 1; day <= daysInMonth; day++) {
                final int currentDay = day;
                JButton dayButton = new JButton(String.valueOf(day));
                dayButton.setMargin(new Insets(2, 2, 2, 2));
                dayButton.setFont(new Font("Arial", Font.PLAIN, 10));
                
                // Check if this date would make donor under 18
                Calendar testDate = (Calendar) calendar.clone();
                testDate.set(Calendar.DAY_OF_MONTH, currentDay);
                
                if (testDate.after(today)) {
                    dayButton.setEnabled(false);
                    dayButton.setBackground(Color.LIGHT_GRAY);
                    dayButton.setToolTipText("Donor must be at least 18 years old");
                } else {
                    // Color coding for different decades
                    int year = testDate.get(Calendar.YEAR);
                    int currentYear = Calendar.getInstance().get(Calendar.YEAR);
                    int age = currentYear - year;
                    
                    if (age >= 18 && age <= 35) {
                        dayButton.setBackground(new Color(200, 255, 200)); // Light green for young adults
                    } else if (age <= 50) {
                        dayButton.setBackground(new Color(255, 255, 200)); // Light yellow for middle age
                    } else {
                        dayButton.setBackground(new Color(255, 200, 200)); // Light red for older donors
                    }
                    dayButton.setOpaque(true);
                    dayButton.setBorderPainted(false);
                }
                
                dayButton.addActionListener(e -> {
                    // Set selected date in format yyyy-MM-dd
                    Calendar selectedDate = (Calendar) calendar.clone();
                    selectedDate.set(Calendar.DAY_OF_MONTH, currentDay);
                    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                    dobField.setText(dateFormat.format(selectedDate.getTime()));
                    
                    // Calculate and display age
                    calculateAndDisplayAge(selectedDate.getTime());
                    
                    calendarDialog.dispose();
                });
                daysPanel.add(dayButton);
            }
            
            daysPanel.revalidate();
            daysPanel.repaint();
        };
        
        // Navigation button listeners
        prevMonthButton.addActionListener(e -> {
            calendar.add(Calendar.MONTH, -1);
            updateCalendar.run();
        });
        
        nextMonthButton.addActionListener(e -> {
            calendar.add(Calendar.MONTH, 1);
            updateCalendar.run();
        });
        
        prevYearButton.addActionListener(e -> {
            calendar.add(Calendar.YEAR, -1);
            updateCalendar.run();
        });
        
        nextYearButton.addActionListener(e -> {
            int currentYear = calendar.get(Calendar.YEAR);
            int maxYear = Calendar.getInstance().get(Calendar.YEAR) - 18;
            if (currentYear < maxYear) {
                calendar.add(Calendar.YEAR, 1);
                updateCalendar.run();
            }
        });
        
        goToYearButton.addActionListener(e -> {
            int selectedYear = (Integer) yearSpinner.getValue();
            int currentYear = calendar.get(Calendar.YEAR);
            int maxYear = Calendar.getInstance().get(Calendar.YEAR) - 18;
            
            if (selectedYear <= maxYear) {
                calendar.set(Calendar.YEAR, selectedYear);
                updateCalendar.run();
            } else {
                JOptionPane.showMessageDialog(calendarDialog, 
                    "Year cannot be after " + maxYear + " (donor must be at least 18 years old)", 
                    "Invalid Year", 
                    JOptionPane.WARNING_MESSAGE);
            }
        });
        
        // Initial calendar setup
        updateCalendar.run();
        
        // Add components to dialog
        calendarPanel.add(navigationPanel, BorderLayout.NORTH);
        calendarPanel.add(daysPanel, BorderLayout.CENTER);
        
        // Close button and today's info
        JPanel bottomPanel = new JPanel(new BorderLayout());
        JButton closeButton = new JButton("Close");
        closeButton.addActionListener(e -> calendarDialog.dispose());
        
        // Display today's date info
        JLabel todayInfoLabel = new JLabel("Today: " + 
            new SimpleDateFormat("yyyy-MM-dd").format(new Date()), JLabel.CENTER);
        todayInfoLabel.setFont(new Font("Arial", Font.ITALIC, 10));
        
        bottomPanel.add(todayInfoLabel, BorderLayout.CENTER);
        bottomPanel.add(closeButton, BorderLayout.EAST);
        
        calendarDialog.add(calendarPanel, BorderLayout.CENTER);
        calendarDialog.add(bottomPanel, BorderLayout.SOUTH);
        calendarDialog.setVisible(true);
    }
    
    // NEW: Enhanced Calculate and display age based on selected date
    private void calculateAndDisplayAge(Date birthDate) {
        if (birthDate == null) return;
        
        Calendar birthCal = Calendar.getInstance();
        birthCal.setTime(birthDate);
        
        Calendar today = Calendar.getInstance();
        
        int age = today.get(Calendar.YEAR) - birthCal.get(Calendar.YEAR);
        
        // Adjust age if birthday hasn't occurred this year
        if (today.get(Calendar.DAY_OF_YEAR) < birthCal.get(Calendar.DAY_OF_YEAR)) {
            age--;
        }
        
        ageField.setText(String.valueOf(age));
        
        // Enhanced age validation with detailed messages
        String ageMessage;
        Color backgroundColor;
        
        if (age < 18) {
            ageMessage = "Donor must be at least 18 years old for organ donation.";
            backgroundColor = new Color(255, 200, 200); // Light red
            JOptionPane.showMessageDialog(this, ageMessage, "Age Restriction", JOptionPane.WARNING_MESSAGE);
        } else if (age < 25) {
            ageMessage = "Young adult donor - excellent candidate.";
            backgroundColor = new Color(150, 255, 150); // Bright green
        } else if (age < 35) {
            ageMessage = "Adult donor - good candidate.";
            backgroundColor = new Color(200, 255, 200); // Light green
        } else if (age < 50) {
            ageMessage = "Middle-aged donor - suitable with evaluation.";
            backgroundColor = new Color(255, 255, 200); // Light yellow
        } else if (age <= 65) {
            ageMessage = "Older donor - requires comprehensive medical evaluation.";
            backgroundColor = new Color(255, 220, 150); // Light orange
            JOptionPane.showMessageDialog(this, ageMessage, "Age Consideration", JOptionPane.INFORMATION_MESSAGE);
        } else {
            ageMessage = "Senior donor - extensive evaluation required. Age may limit donation options.";
            backgroundColor = new Color(255, 200, 200); // Light red
            JOptionPane.showMessageDialog(this, ageMessage, "Advanced Age Consideration", JOptionPane.WARNING_MESSAGE);
        }
        
        ageField.setBackground(backgroundColor);
        ageField.setToolTipText(ageMessage);
        
        // Also update the tooltip for the date field
        String dobTooltip = String.format("Born: %s | Age: %d years | %s", 
            new SimpleDateFormat("MMMM dd, yyyy").format(birthDate), age, ageMessage);
        dobField.setToolTipText(dobTooltip);
    }
    
    private JPanel createMedicalInfoPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(Color.WHITE);
        
        JTabbedPane medicalTabs = new JTabbedPane();
        medicalTabs.addTab("Basic Medical Info", createBasicMedicalPanel());
        medicalTabs.addTab("HLA Typing", createHLAPanel());
        medicalTabs.addTab("Medical Parameters", createMedicalParametersPanel());
        medicalTabs.addTab("BMI Calculator", createBMIPanel());
        
        panel.add(medicalTabs, BorderLayout.CENTER);
        return panel;
    }
    
    private JPanel createBasicMedicalPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.WEST;
        
        int row = 0;
        
        // Blood Group
        gbc.gridx = 0; gbc.gridy = row;
        panel.add(new JLabel("Blood Group:"), gbc);
        gbc.gridx = 1;
        bloodGroupCombo = new JComboBox<>(new String[]{"A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"});
        bloodGroupCombo.setFont(new Font("Arial", Font.PLAIN, 14));
        panel.add(bloodGroupCombo, gbc);
        row++;
        
        // Organ Type
        gbc.gridx = 0; gbc.gridy = row;
        panel.add(new JLabel("Organ Donating:"), gbc);
        gbc.gridx = 1;
        organCombo = new JComboBox<>(new String[]{"Heart", "Kidney", "Liver", "Lungs", "Pancreas", "Eyes"});
        organCombo.setFont(new Font("Arial", Font.PLAIN, 14));
        panel.add(organCombo, gbc);
        row++;
        
        // Weight
        gbc.gridx = 0; gbc.gridy = row;
        panel.add(new JLabel("Weight (kg):"), gbc);
        gbc.gridx = 1;
        weightField = new JTextField(20);
        weightField.setFont(new Font("Arial", Font.PLAIN, 14));
        panel.add(weightField, gbc);
        row++;
        
        // Height
        gbc.gridx = 0; gbc.gridy = row;
        panel.add(new JLabel("Height (cm):"), gbc);
        gbc.gridx = 1;
        heightField = new JTextField(20);
        heightField.setFont(new Font("Arial", Font.PLAIN, 14));
        panel.add(heightField, gbc);
        row++;
        
        // Medical Conditions
        gbc.gridx = 0; gbc.gridy = row;
        panel.add(new JLabel("Medical Conditions:"), gbc);
        gbc.gridx = 1;
        JPanel conditionsPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        conditionsPanel.setBackground(Color.WHITE);
        diabetesCheck = new JCheckBox("Diabetes");
        cancerCheck = new JCheckBox("Cancer");
        heartDiseaseCheck = new JCheckBox("Heart Disease");
        conditionsPanel.add(diabetesCheck);
        conditionsPanel.add(cancerCheck);
        conditionsPanel.add(heartDiseaseCheck);
        panel.add(conditionsPanel, gbc);
        row++;
        
        // Medical History
        gbc.gridx = 0; gbc.gridy = row;
        panel.add(new JLabel("Medical History:"), gbc);
        gbc.gridx = 1;
        medicalHistoryArea = new JTextArea(4, 20);
        medicalHistoryArea.setFont(new Font("Arial", Font.PLAIN, 14));
        medicalHistoryArea.setLineWrap(true);
        medicalHistoryArea.setWrapStyleWord(true);
        JScrollPane scrollPane = new JScrollPane(medicalHistoryArea);
        panel.add(scrollPane, gbc);
        
        return panel;
    }
    
    private JPanel createHLAPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.WEST;
        
        int row = 0;
        
        // HLA A1
        gbc.gridx = 0; gbc.gridy = row;
        panel.add(new JLabel("HLA A1:"), gbc);
        gbc.gridx = 1;
        hlaA1Field = new JTextField(20);
        hlaA1Field.setFont(new Font("Arial", Font.PLAIN, 14));
        panel.add(hlaA1Field, gbc);
        row++;
        
        // HLA A2
        gbc.gridx = 0; gbc.gridy = row;
        panel.add(new JLabel("HLA A2:"), gbc);
        gbc.gridx = 1;
        hlaA2Field = new JTextField(20);
        hlaA2Field.setFont(new Font("Arial", Font.PLAIN, 14));
        panel.add(hlaA2Field, gbc);
        row++;
        
        // HLA B1
        gbc.gridx = 0; gbc.gridy = row;
        panel.add(new JLabel("HLA B1:"), gbc);
        gbc.gridx = 1;
        hlaB1Field = new JTextField(20);
        hlaB1Field.setFont(new Font("Arial", Font.PLAIN, 14));
        panel.add(hlaB1Field, gbc);
        row++;
        
        // HLA B2
        gbc.gridx = 0; gbc.gridy = row;
        panel.add(new JLabel("HLA B2:"), gbc);
        gbc.gridx = 1;
        hlaB2Field = new JTextField(20);
        hlaB2Field.setFont(new Font("Arial", Font.PLAIN, 14));
        panel.add(hlaB2Field, gbc);
        row++;
        
        // HLA DR1
        gbc.gridx = 0; gbc.gridy = row;
        panel.add(new JLabel("HLA DR1:"), gbc);
        gbc.gridx = 1;
        hlaDr1Field = new JTextField(20);
        hlaDr1Field.setFont(new Font("Arial", Font.PLAIN, 14));
        panel.add(hlaDr1Field, gbc);
        row++;
        
        // HLA DR2
        gbc.gridx = 0; gbc.gridy = row;
        panel.add(new JLabel("HLA DR2:"), gbc);
        gbc.gridx = 1;
        hlaDr2Field = new JTextField(20);
        hlaDr2Field.setFont(new Font("Arial", Font.PLAIN, 14));
        panel.add(hlaDr2Field, gbc);
        
        return panel;
    }
    
    private JPanel createMedicalParametersPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.WEST;
        
        int row = 0;
        
        // GFR
        gbc.gridx = 0; gbc.gridy = row;
        panel.add(new JLabel("Glomerular Filtration Rate:"), gbc);
        gbc.gridx = 1;
        gfrField = new JTextField(20);
        gfrField.setFont(new Font("Arial", Font.PLAIN, 14));
        gfrField.setToolTipText("Normal GFR: 90+ for kidney donors");
        panel.add(gfrField, gbc);
        row++;
        
        // CMV
        gbc.gridx = 0; gbc.gridy = row;
        panel.add(new JLabel("CMV Serostatus:"), gbc);
        gbc.gridx = 1;
        cmvCombo = new JComboBox<>(new String[]{"Positive", "Negative", "Unknown"});
        cmvCombo.setFont(new Font("Arial", Font.PLAIN, 14));
        panel.add(cmvCombo, gbc);
        row++;
        
        // Liver Steatosis
        gbc.gridx = 0; gbc.gridy = row;
        panel.add(new JLabel("Liver Steatosis:"), gbc);
        gbc.gridx = 1;
        liverSteatosisCombo = new JComboBox<>(new String[]{"None", "Mild", "Moderate", "Severe"});
        liverSteatosisCombo.setFont(new Font("Arial", Font.PLAIN, 14));
        panel.add(liverSteatosisCombo, gbc);
        
        return panel;
    }
    
    private JPanel createBMIPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(new Color(240, 248, 255)); // Light blue background
        panel.setBorder(BorderFactory.createTitledBorder("Body Mass Index (BMI) Calculator"));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 5, 10, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.WEST;
        
        // BMI Value
        gbc.gridx = 0; gbc.gridy = 0;
        panel.add(new JLabel("BMI:"), gbc);
        gbc.gridx = 1;
        bmiValueLabel = new JLabel("--");
        bmiValueLabel.setFont(new Font("Arial", Font.BOLD, 14));
        panel.add(bmiValueLabel, gbc);
        
        // BMI Category
        gbc.gridx = 0; gbc.gridy = 1;
        panel.add(new JLabel("Category:"), gbc);
        gbc.gridx = 1;
        bmiCategoryLabel = new JLabel("--");
        bmiCategoryLabel.setFont(new Font("Arial", Font.BOLD, 14));
        panel.add(bmiCategoryLabel, gbc);
        
        // Donation Status
        gbc.gridx = 0; gbc.gridy = 2;
        panel.add(new JLabel("Donation Status:"), gbc);
        gbc.gridx = 1;
        bmiDonationStatusLabel = new JLabel("--");
        bmiDonationStatusLabel.setFont(new Font("Arial", Font.BOLD, 14));
        panel.add(bmiDonationStatusLabel, gbc);
        
        // Calculate BMI Button
        JButton calculateBMIButton = new JButton("Calculate BMI");
        calculateBMIButton.setBackground(new Color(0, 102, 204));
        calculateBMIButton.setForeground(Color.WHITE);
        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        panel.add(calculateBMIButton, gbc);
        
        // Add action listener for BMI calculation
        calculateBMIButton.addActionListener(e -> calculateAndDisplayBMI());
        
        // NEW: Add real-time BMI calculation as user types
        DocumentListener bmiCalculator = new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                calculateAndDisplayBMI();
            }
            @Override
            public void removeUpdate(DocumentEvent e) {
                calculateAndDisplayBMI();
            }
            @Override
            public void changedUpdate(DocumentEvent e) {
                calculateAndDisplayBMI();
            }
        };
        
        weightField.getDocument().addDocumentListener(bmiCalculator);
        heightField.getDocument().addDocumentListener(bmiCalculator);
        
        return panel;
    }
    
    // NEW: Enhanced BMI calculation with real-time updates
    private void calculateAndDisplayBMI() {
        try {
            String weightText = weightField.getText().trim();
            String heightText = heightField.getText().trim();
            
            if (!weightText.isEmpty() && !heightText.isEmpty()) {
                double weight = Double.parseDouble(weightText);
                double height = Double.parseDouble(heightText);
                
                if (height > 0 && weight > 0) {
                    // Calculate BMI
                    double heightInMeters = height / 100.0;
                    double bmi = weight / (heightInMeters * heightInMeters);
                    
                    // Update BMI value
                    bmiValueLabel.setText(String.format("%.1f", bmi));
                    
                    // Update BMI category with color coding
                    String category;
                    Color categoryColor;
                    if (bmi < 18.5) {
                        category = "Underweight";
                        categoryColor = Color.ORANGE;
                    } else if (bmi < 25) {
                        category = "Normal weight";
                        categoryColor = Color.GREEN;
                    } else if (bmi < 30) {
                        category = "Overweight";
                        categoryColor = Color.ORANGE;
                    } else {
                        category = "Obese";
                        categoryColor = Color.RED;
                    }
                    bmiCategoryLabel.setText(category);
                    bmiCategoryLabel.setForeground(categoryColor);
                    
                    // Update donation status
                    String donationStatus;
                    Color statusColor;
                    if (bmi < 18.5) {
                        donationStatus = "Underweight - May not be suitable";
                        statusColor = Color.RED;
                    } else if (bmi <= 30) {
                        donationStatus = "Good candidate for donation";
                        statusColor = Color.GREEN;
                    } else if (bmi <= 35) {
                        donationStatus = "Overweight - Requires evaluation";
                        statusColor = Color.ORANGE;
                    } else {
                        donationStatus = "Obese - May not be suitable";
                        statusColor = Color.RED;
                    }
                    bmiDonationStatusLabel.setText(donationStatus);
                    bmiDonationStatusLabel.setForeground(statusColor);
                    
                    return;
                }
            }
        } catch (NumberFormatException e) {
            // Ignore parsing errors - user might be typing
        }
        
        // Reset display if invalid input
        bmiValueLabel.setText("--");
        bmiCategoryLabel.setText("--");
        bmiCategoryLabel.setForeground(Color.BLACK);
        bmiDonationStatusLabel.setText("--");
        bmiDonationStatusLabel.setForeground(Color.BLACK);
    }
    
    // --- Existing methods remain the same ---
    public void setDonorDetailsForEdit(Donor donor) {
        setTitle("Edit Donor Registration - ID: " + donor.getId());
        registerButton.setText("Save Changes");
        
        nameField.setText(donor.getName());
        ageField.setText(String.valueOf(donor.getAge()));
        if (donor.getDateOfBirth() != null) {
            dobField.setText(new SimpleDateFormat("yyyy-MM-dd").format(donor.getDateOfBirth()));
        }
        
        String gender = donor.getGender();
        if ("Male".equals(gender)) maleButton.setSelected(true); 
        else if ("Female".equals(gender)) femaleButton.setSelected(true); 
        else if ("Other".equals(gender)) otherButton.setSelected(true);
        
        phoneField.setText(donor.getPhoneNumber());
        emailField.setText(donor.getEmail());
        addressField.setText(donor.getAddress());
        emergencyNameField.setText(donor.getEmergencyContactName());
        emergencyPhoneField.setText(donor.getEmergencyContactPhone());

        // Medical Info
        bloodGroupCombo.setSelectedItem(donor.getBloodGroup());
        organCombo.setSelectedItem(donor.getOrganDonating());
        weightField.setText(String.valueOf(donor.getWeightKg()));
        heightField.setText(String.valueOf(donor.getHeightCm()));
        
        medicalHistoryArea.setText(donor.getMedicalHistory());
        
        // HLA values
        hlaA1Field.setText(donor.getHla_a1());
        hlaA2Field.setText(donor.getHla_a2());
        hlaB1Field.setText(donor.getHla_b1());
        hlaB2Field.setText(donor.getHla_b2());
        hlaDr1Field.setText(donor.getHla_dr1());
        hlaDr2Field.setText(donor.getHla_dr2());
        
        // Medical Parameters
        if (donor.getGlomerularFiltrationRate() > 0) {
            gfrField.setText(String.valueOf(donor.getGlomerularFiltrationRate()));
        }
        cmvCombo.setSelectedItem(donor.getCmvSerostatus());
        liverSteatosisCombo.setSelectedItem(donor.getLiverSteatosis());

        calculateAndDisplayBMI();
    }
    
    private Donor getDonorDetails() throws ParseException, NumberFormatException {
        Donor donor = new Donor();
        donor.setName(nameField.getText());
        
        // Age is now calculated automatically from DOB
        if (!ageField.getText().isEmpty()) {
            donor.setAge(Integer.parseInt(ageField.getText()));
        }
        
        donor.setDateOfBirth(new SimpleDateFormat("yyyy-MM-dd").parse(dobField.getText()));
        if (maleButton.isSelected()) donor.setGender("Male"); 
        else if (femaleButton.isSelected()) donor.setGender("Female"); 
        else if (otherButton.isSelected()) donor.setGender("Other");
        donor.setPhoneNumber(phoneField.getText());
        donor.setEmail(emailField.getText());
        donor.setAddress(addressField.getText());
        donor.setEmergencyContactName(emergencyNameField.getText());
        donor.setEmergencyContactPhone(emergencyPhoneField.getText());
        donor.setBloodGroup((String) bloodGroupCombo.getSelectedItem());
        donor.setOrganDonating((String) organCombo.getSelectedItem());
        donor.setHeightCm(Double.parseDouble(heightField.getText()));
        donor.setWeightKg(Double.parseDouble(weightField.getText()));
        donor.setHasDiseases(diabetesCheck.isSelected() || cancerCheck.isSelected() || heartDiseaseCheck.isSelected());
        donor.setMedicalHistory(medicalHistoryArea.getText());

        donor.setHla_a1(hlaA1Field.getText());
        donor.setHla_a2(hlaA2Field.getText());
        donor.setHla_b1(hlaB1Field.getText());
        donor.setHla_b2(hlaB2Field.getText());
        donor.setHla_dr1(hlaDr1Field.getText());
        donor.setHla_dr2(hlaDr2Field.getText());
        
        if (!gfrField.getText().isEmpty()) {
            donor.setGlomerularFiltrationRate(Double.parseDouble(gfrField.getText()));
        }
        donor.setCmvSerostatus((String) cmvCombo.getSelectedItem());
        donor.setLiverSteatosis((String) liverSteatosisCombo.getSelectedItem());
        
        return donor;
    }
    
    public Donor getDonorDetails(Integer donorId) throws ParseException, NumberFormatException {
        Donor donor = getDonorDetails();
        if (donorId != null) {
            donor.setId(donorId);
        }
        return donor;
    }
    
    public boolean validateBMIForDonation() {
        try {
            double weight = Double.parseDouble(weightField.getText());
            double height = Double.parseDouble(heightField.getText()) / 100;
            double bmi = weight / (height * height);
            return bmi >= 18.5 && bmi <= 30;
        } catch (NumberFormatException e) {
            return false;
        }
    }
    
    // NEW: Enhanced medical parameters validation
    public boolean validateMedicalParameters() {
        String selectedOrgan = (String) organCombo.getSelectedItem();
        
        // Validate GFR for kidney donors
        if ("Kidney".equals(selectedOrgan)) {
            try {
                if (!gfrField.getText().isEmpty()) {
                    double gfr = Double.parseDouble(gfrField.getText());
                    if (gfr < 90) {
                        return false; // Low GFR for kidney donation
                    }
                }
            } catch (NumberFormatException e) {
                // GFR not entered or invalid
            }
        }
        
        // Validate liver steatosis for liver donors
        if ("Liver".equals(selectedOrgan)) {
            String steatosis = (String) liverSteatosisCombo.getSelectedItem();
            if ("Severe".equals(steatosis)) {
                return false; // Severe steatosis not suitable
            }
        }
        
        return true;
    }
    
    // NEW: Enhanced medical validation message
    public String getMedicalValidationMessage() {
        StringBuilder message = new StringBuilder();
        String selectedOrgan = (String) organCombo.getSelectedItem();
        
        if ("Kidney".equals(selectedOrgan)) {
            try {
                if (!gfrField.getText().isEmpty()) {
                    double gfr = Double.parseDouble(gfrField.getText());
                    if (gfr < 90) {
                        message.append("Low GFR (").append(gfr).append(") - may affect kidney donation suitability.\n");
                    }
                }
            } catch (NumberFormatException e) {
                message.append("GFR not provided for kidney donation assessment.\n");
            }
        }
        
        if ("Liver".equals(selectedOrgan)) {
            String steatosis = (String) liverSteatosisCombo.getSelectedItem();
            if ("Severe".equals(steatosis)) {
                message.append("Severe liver steatosis - not suitable for donation.\n");
            } else if ("Moderate".equals(steatosis)) {
                message.append("Moderate liver steatosis - requires medical evaluation.\n");
            }
        }
        
        if (message.length() == 0) {
            message.append("Medical parameters appear suitable for donation.");
        }
        
        return message.toString();
    }

    public void addRegisterListener(ActionListener listener) { 
        registerButton.addActionListener(listener); 
    }
    
    public void showMessage(String message, String title, int messageType) { 
        JOptionPane.showMessageDialog(this, message, title, messageType); 
    }
    
    // NEW: Get current BMI for validation messages
    public String getCurrentBMIStatus() {
        try {
            double weight = Double.parseDouble(weightField.getText());
            double height = Double.parseDouble(heightField.getText());
            
            if (height > 0) {
                double heightInMeters = height / 100.0;
                double bmi = weight / (heightInMeters * heightInMeters);
                return String.format("Current BMI: %.1f (%s)", bmi, getBMICategory(bmi));
            }
        } catch (NumberFormatException e) {
            // Invalid input
        }
        return "BMI calculation unavailable";
    }
    
    private String getBMICategory(double bmi) {
        if (bmi < 18.5) return "Underweight";
        else if (bmi < 25) return "Normal weight";
        else if (bmi < 30) return "Overweight";
        else return "Obese";
    }
}