package com.organdonation.view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class NotificationBell extends JLayeredPane {
    private JButton bellButton;
    private JLabel countLabel;

    public NotificationBell() {
        bellButton = new JButton("🔔");
        bellButton.setFont(new Font("Arial", Font.PLAIN, 20)); // Use a font that supports emojis
        bellButton.setFocusPainted(false);
        bellButton.setBorderPainted(false);
        bellButton.setContentAreaFilled(false);
        bellButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        bellButton.setPreferredSize(new Dimension(40, 40));
        bellButton.setBounds(0, 0, 40, 40);

        countLabel = new JLabel();
        countLabel.setFont(new Font("Arial", Font.BOLD, 10));
        countLabel.setForeground(Color.WHITE);
        countLabel.setBackground(Color.RED);
        countLabel.setOpaque(true);
        countLabel.setHorizontalAlignment(SwingConstants.CENTER);
        countLabel.setVerticalAlignment(SwingConstants.CENTER);
        countLabel.setBorder(BorderFactory.createEmptyBorder(2, 2, 2, 2));
        countLabel.setBounds(20, 5, 18, 18); // Position the badge
        countLabel.setVisible(false);

        // Use JLayeredPane to overlay label on button
        setPreferredSize(new Dimension(40, 40));
        add(bellButton, JLayeredPane.DEFAULT_LAYER);
        add(countLabel, JLayeredPane.PALETTE_LAYER);
    }

    public void setCount(int count) {
        if (count > 0) {
            String countText = (count > 9) ? "9+" : String.valueOf(count);
            countLabel.setText(countText);
            countLabel.setVisible(true);
        } else {
            countLabel.setVisible(false);
        }
    }

    public void addActionListener(ActionListener listener) {
        bellButton.addActionListener(listener);
    }

    public JButton getButton() {
        return bellButton;
    }
}