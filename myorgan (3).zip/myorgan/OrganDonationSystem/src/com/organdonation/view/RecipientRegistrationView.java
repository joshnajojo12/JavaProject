package com.organdonation.view;

import com.organdonation.model.Recipient;
import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class RecipientRegistrationView extends JFrame {
    private static final long serialVersionUID = 1L;
    // Personal Info
    private JTextField nameField, ageField, dobField, phoneField, emailField, addressField;
    private JRadioButton maleButton, femaleButton, otherButton;
    private ButtonGroup genderGroup;

    // Medical Info
    private JComboBox<String> bloodGroupCombo, organCombo, urgencyCombo;
    private JTextField weightField, heightField, praField;
    private JRadioButton diseaseYesButton, diseaseNoButton;
    private ButtonGroup diseaseGroup;
    private JTextArea diagnosisArea, medicalHistoryArea;
    private JTextField hlaA1Field, hlaA2Field, hlaB1Field, hlaB2Field, hlaDr1Field, hlaDr2Field;
    
    // NEW: BMI Display Components
    private JLabel bmiValueLabel, bmiCategoryLabel, bmiTransplantStatusLabel;
    
    // NEW: Medical Field Components
    private JTextField gfrField;
    private JComboBox<String> cmvCombo, liverSteatosisCombo;
    
    private JButton registerButton;

    public RecipientRegistrationView() {
        setTitle("Comprehensive Recipient Registration");
        setSize(700, 850); 
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.addTab("Personal & Contact", createPersonalInfoPanel());
        tabbedPane.addTab("Medical Information", createMedicalInfoPanel());

        registerButton = new JButton("Complete Registration");
        registerButton.setBackground(new Color(0, 102, 204));
        registerButton.setForeground(Color.WHITE);
        registerButton.setFont(new Font("Arial", Font.BOLD, 14));
        
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.setBackground(Color.WHITE);
        buttonPanel.add(registerButton);

        add(tabbedPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
        
        setVisible(true);
    }
    
    private JPanel createPersonalInfoPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.WEST;
        
        int row = 0;
        
        // Title
        JLabel titleLabel = new JLabel("Personal Information");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        titleLabel.setForeground(new Color(0, 102, 204));
        gbc.gridx = 0; gbc.gridy = row++; gbc.gridwidth = 2;
        panel.add(titleLabel, gbc);
        gbc.gridwidth = 1;
        
        // Name
        gbc.gridx = 0; gbc.gridy = row;
        panel.add(new JLabel("Full Name:"), gbc);
        gbc.gridx = 1;
        nameField = new JTextField(20);
        nameField.setFont(new Font("Arial", Font.PLAIN, 14));
        panel.add(nameField, gbc);
        row++;
        
        // Date of Birth with Calendar Picker - NEW FEATURE
        gbc.gridx = 0; gbc.gridy = row;
        panel.add(new JLabel("Date of Birth:"), gbc);
        gbc.gridx = 1; gbc.gridy = row;
        
        // Create a panel for date field and calendar button
        JPanel dobPanel = new JPanel(new BorderLayout(5, 0));
        dobField = new JTextField(15);
        dobField.setToolTipText("Click calendar to select date");
        dobField.setFont(new Font("Arial", Font.PLAIN, 14));
        dobPanel.add(dobField, BorderLayout.CENTER);
        
        JButton calendarButton = new JButton("📅");
        calendarButton.setToolTipText("Select date from calendar");
        calendarButton.addActionListener(e -> showCalendarDialog());
        dobPanel.add(calendarButton, BorderLayout.EAST);
        
        panel.add(dobPanel, gbc);
        row++;
        
        // Age (calculated from DOB) - NEW FEATURE
        gbc.gridx = 0; gbc.gridy = row;
        panel.add(new JLabel("Age:"), gbc);
        gbc.gridx = 1; gbc.gridy = row;
        ageField = new JTextField(20);
        ageField.setEditable(false); // Age is calculated automatically
        ageField.setBackground(new Color(240, 240, 240)); // Gray background to indicate read-only
        ageField.setFont(new Font("Arial", Font.PLAIN, 14));
        panel.add(ageField, gbc);
        row++;
        
        // Gender
        gbc.gridx = 0; gbc.gridy = row;
        panel.add(new JLabel("Gender:"), gbc);
        gbc.gridx = 1;
        JPanel genderPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        genderPanel.setBackground(Color.WHITE);
        maleButton = new JRadioButton("Male");
        femaleButton = new JRadioButton("Female");
        otherButton = new JRadioButton("Other");
        genderGroup = new ButtonGroup();
        genderGroup.add(maleButton);
        genderGroup.add(femaleButton);
        genderGroup.add(otherButton);
        genderPanel.add(maleButton);
        genderPanel.add(femaleButton);
        genderPanel.add(otherButton);
        panel.add(genderPanel, gbc);
        row++;
        
        // Phone
        gbc.gridx = 0; gbc.gridy = row;
        panel.add(new JLabel("Phone:"), gbc);
        gbc.gridx = 1;
        phoneField = new JTextField(20);
        phoneField.setFont(new Font("Arial", Font.PLAIN, 14));
        panel.add(phoneField, gbc);
        row++;
        
        // Email
        gbc.gridx = 0; gbc.gridy = row;
        panel.add(new JLabel("Email:"), gbc);
        gbc.gridx = 1;
        emailField = new JTextField(20);
        emailField.setFont(new Font("Arial", Font.PLAIN, 14));
        panel.add(emailField, gbc);
        row++;
        
        // Address
        gbc.gridx = 0; gbc.gridy = row;
        panel.add(new JLabel("Address:"), gbc);
        gbc.gridx = 1;
        addressField = new JTextField(20);
        addressField.setFont(new Font("Arial", Font.PLAIN, 14));
        panel.add(addressField, gbc);
        
        return panel;
    }

    // NEW: Calendar Dialog for Recipient
    private void showCalendarDialog() {
        JDialog calendarDialog = new JDialog(this, "Select Date of Birth", true);
        calendarDialog.setLayout(new BorderLayout());
        calendarDialog.setSize(350, 350);
        calendarDialog.setLocationRelativeTo(this);

        // Create calendar panel
        JPanel calendarPanel = new JPanel(new BorderLayout());
        
        // Month and year navigation
        JPanel navigationPanel = new JPanel(new GridLayout(2, 1));
        JPanel monthPanel = new JPanel(new FlowLayout());
        JPanel yearPanel = new JPanel(new FlowLayout());
        
        JButton prevYearButton = new JButton("<<");
        JButton prevMonthButton = new JButton("←");
        JLabel monthYearLabel = new JLabel("", JLabel.CENTER);
        JButton nextMonthButton = new JButton("→");
        JButton nextYearButton = new JButton(">>");
        
        monthPanel.add(prevYearButton);
        monthPanel.add(prevMonthButton);
        monthPanel.add(monthYearLabel);
        monthPanel.add(nextMonthButton);
        monthPanel.add(nextYearButton);
        
        // Year quick navigation
        JLabel yearLabel = new JLabel("Year: ", JLabel.CENTER);
        JSpinner yearSpinner = new JSpinner(new SpinnerNumberModel(
            Calendar.getInstance().get(Calendar.YEAR), 
            1900, 
            Calendar.getInstance().get(Calendar.YEAR), 
            1
        ));
        JButton goToYearButton = new JButton("Go to Year");
        
        yearPanel.add(yearLabel);
        yearPanel.add(yearSpinner);
        yearPanel.add(goToYearButton);
        
        navigationPanel.add(monthPanel);
        navigationPanel.add(yearPanel);
        
        // Calendar grid
        JPanel daysPanel = new JPanel(new GridLayout(0, 7, 2, 2));
        
        // Initialize calendar
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.DAY_OF_MONTH, 1);
        
        // Update calendar display
        Runnable updateCalendar = () -> {
            daysPanel.removeAll();
            monthYearLabel.setText(new SimpleDateFormat("MMMM yyyy").format(calendar.getTime()));
            
            // Update year spinner to match current calendar year
            yearSpinner.setValue(calendar.get(Calendar.YEAR));
            
            // Add day headers
            String[] days = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};
            for (String day : days) {
                JLabel dayLabel = new JLabel(day, JLabel.CENTER);
                dayLabel.setFont(new Font("Arial", Font.BOLD, 10));
                dayLabel.setBackground(new Color(220, 220, 220));
                dayLabel.setOpaque(true);
                daysPanel.add(dayLabel);
            }
            
            // Get first day of month and number of days
            int firstDayOfWeek = calendar.get(Calendar.DAY_OF_WEEK);
            int daysInMonth = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
            
            // Add empty cells for days before first day of month
            for (int i = 1; i < firstDayOfWeek; i++) {
                daysPanel.add(new JLabel(""));
            }
            
            // Add day buttons
            Calendar today = Calendar.getInstance();
            
            for (int day = 1; day <= daysInMonth; day++) {
                final int currentDay = day;
                JButton dayButton = new JButton(String.valueOf(day));
                dayButton.setMargin(new Insets(2, 2, 2, 2));
                dayButton.setFont(new Font("Arial", Font.PLAIN, 10));
                
                // Check if this date is in the future (no future dates allowed)
                Calendar testDate = (Calendar) calendar.clone();
                testDate.set(Calendar.DAY_OF_MONTH, currentDay);
                
                if (testDate.after(today)) {
                    dayButton.setEnabled(false);
                    dayButton.setBackground(Color.LIGHT_GRAY);
                    dayButton.setToolTipText("Cannot select future dates");
                } else {
                    // Color coding for different age groups
                    int year = testDate.get(Calendar.YEAR);
                    int currentYear = Calendar.getInstance().get(Calendar.YEAR);
                    int age = currentYear - year;
                    
                    if (age < 18) {
                        dayButton.setBackground(new Color(255, 200, 200)); // Light red for minors
                    } else if (age <= 65) {
                        dayButton.setBackground(new Color(200, 255, 200)); // Light green for adults
                    } else {
                        dayButton.setBackground(new Color(255, 255, 200)); // Light yellow for seniors
                    }
                    dayButton.setOpaque(true);
                    dayButton.setBorderPainted(false);
                }
                
                dayButton.addActionListener(e -> {
                    // Set selected date in format yyyy-MM-dd
                    Calendar selectedDate = (Calendar) calendar.clone();
                    selectedDate.set(Calendar.DAY_OF_MONTH, currentDay);
                    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                    dobField.setText(dateFormat.format(selectedDate.getTime()));
                    
                    // Calculate and display age
                    calculateAndDisplayAge(selectedDate.getTime());
                    
                    calendarDialog.dispose();
                });
                daysPanel.add(dayButton);
            }
            
            daysPanel.revalidate();
            daysPanel.repaint();
        };
        
        // Navigation button listeners
        prevMonthButton.addActionListener(e -> {
            calendar.add(Calendar.MONTH, -1);
            updateCalendar.run();
        });
        
        nextMonthButton.addActionListener(e -> {
            calendar.add(Calendar.MONTH, 1);
            updateCalendar.run();
        });
        
        prevYearButton.addActionListener(e -> {
            calendar.add(Calendar.YEAR, -1);
            updateCalendar.run();
        });
        
        nextYearButton.addActionListener(e -> {
            int currentYear = calendar.get(Calendar.YEAR);
            int maxYear = Calendar.getInstance().get(Calendar.YEAR);
            if (currentYear < maxYear) {
                calendar.add(Calendar.YEAR, 1);
                updateCalendar.run();
            }
        });
        
        goToYearButton.addActionListener(e -> {
            int selectedYear = (Integer) yearSpinner.getValue();
            int currentYear = calendar.get(Calendar.YEAR);
            int maxYear = Calendar.getInstance().get(Calendar.YEAR);
            
            if (selectedYear <= maxYear) {
                calendar.set(Calendar.YEAR, selectedYear);
                updateCalendar.run();
            } else {
                JOptionPane.showMessageDialog(calendarDialog, 
                    "Year cannot be after " + maxYear + " (cannot select future dates)", 
                    "Invalid Year", 
                    JOptionPane.WARNING_MESSAGE);
            }
        });
        
        // Initial calendar setup
        updateCalendar.run();
        
        // Add components to dialog
        calendarPanel.add(navigationPanel, BorderLayout.NORTH);
        calendarPanel.add(daysPanel, BorderLayout.CENTER);
        
        // Close button and today's info
        JPanel bottomPanel = new JPanel(new BorderLayout());
        JButton closeButton = new JButton("Close");
        closeButton.addActionListener(e -> calendarDialog.dispose());
        
        // Display today's date info
        JLabel todayInfoLabel = new JLabel("Today: " + 
            new SimpleDateFormat("yyyy-MM-dd").format(new Date()), JLabel.CENTER);
        todayInfoLabel.setFont(new Font("Arial", Font.ITALIC, 10));
        
        bottomPanel.add(todayInfoLabel, BorderLayout.CENTER);
        bottomPanel.add(closeButton, BorderLayout.EAST);
        
        calendarDialog.add(calendarPanel, BorderLayout.CENTER);
        calendarDialog.add(bottomPanel, BorderLayout.SOUTH);
        calendarDialog.setVisible(true);
    }
    
    // NEW: Enhanced Calculate and display age based on selected date
    private void calculateAndDisplayAge(Date birthDate) {
        if (birthDate == null) return;
        
        Calendar birthCal = Calendar.getInstance();
        birthCal.setTime(birthDate);
        
        Calendar today = Calendar.getInstance();
        
        int age = today.get(Calendar.YEAR) - birthCal.get(Calendar.YEAR);
        
        // Adjust age if birthday hasn't occurred this year
        if (today.get(Calendar.DAY_OF_YEAR) < birthCal.get(Calendar.DAY_OF_YEAR)) {
            age--;
        }
        
        ageField.setText(String.valueOf(age));
        
        // Enhanced age validation with detailed messages for recipients
        String ageMessage;
        Color backgroundColor;
        
        if (age < 1) {
            ageMessage = "Infant recipient - specialized pediatric care required.";
            backgroundColor = new Color(255, 200, 200); // Light red
            JOptionPane.showMessageDialog(this, ageMessage, "Pediatric Recipient", JOptionPane.INFORMATION_MESSAGE);
        } else if (age < 18) {
            ageMessage = "Pediatric recipient - specialized care required.";
            backgroundColor = new Color(255, 220, 150); // Light orange
            JOptionPane.showMessageDialog(this, ageMessage, "Pediatric Recipient", JOptionPane.INFORMATION_MESSAGE);
        } else if (age < 65) {
            ageMessage = "Adult recipient - standard transplant protocols apply.";
            backgroundColor = new Color(200, 255, 200); // Light green
        } else if (age <= 75) {
            ageMessage = "Senior recipient - comprehensive geriatric assessment required.";
            backgroundColor = new Color(255, 255, 200); // Light yellow
            JOptionPane.showMessageDialog(this, ageMessage, "Senior Recipient", JOptionPane.INFORMATION_MESSAGE);
        } else {
            ageMessage = "Elderly recipient - individual assessment for transplant suitability.";
            backgroundColor = new Color(255, 200, 200); // Light red
            JOptionPane.showMessageDialog(this, ageMessage, "Elderly Recipient", JOptionPane.WARNING_MESSAGE);
        }
        
        ageField.setBackground(backgroundColor);
        ageField.setToolTipText(ageMessage);
        
        // Also update the tooltip for the date field
        String dobTooltip = String.format("Born: %s | Age: %d years | %s", 
            new SimpleDateFormat("MMMM dd, yyyy").format(birthDate), age, ageMessage);
        dobField.setToolTipText(dobTooltip);
    }
    
    private JPanel createMedicalInfoPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(Color.WHITE);
        
        JTabbedPane medicalTabs = new JTabbedPane();
        medicalTabs.addTab("Basic Medical Info", createBasicMedicalPanel());
        medicalTabs.addTab("HLA Typing", createHLAPanel());
        medicalTabs.addTab("Medical Parameters", createMedicalParametersPanel());
        medicalTabs.addTab("BMI Calculator", createBMIPanel());
        
        panel.add(medicalTabs, BorderLayout.CENTER);
        return panel;
    }
    
    private JPanel createBasicMedicalPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.WEST;
        
        int row = 0;
        
        // Organ Needed
        gbc.gridx = 0; gbc.gridy = row;
        panel.add(new JLabel("Organ Needed:"), gbc);
        gbc.gridx = 1;
        organCombo = new JComboBox<>(new String[]{"Heart", "Kidney", "Liver", "Lungs", "Pancreas", "Eyes"});
        organCombo.setFont(new Font("Arial", Font.PLAIN, 14));
        panel.add(organCombo, gbc);
        row++;
        
        // Blood Group
        gbc.gridx = 0; gbc.gridy = row;
        panel.add(new JLabel("Blood Group:"), gbc);
        gbc.gridx = 1;
        bloodGroupCombo = new JComboBox<>(new String[]{"A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"});
        bloodGroupCombo.setFont(new Font("Arial", Font.PLAIN, 14));
        panel.add(bloodGroupCombo, gbc);
        row++;
        
        // Urgency Level
        gbc.gridx = 0; gbc.gridy = row;
        panel.add(new JLabel("Urgency Level:"), gbc);
        gbc.gridx = 1;
        urgencyCombo = new JComboBox<>(new String[]{"Low", "Medium", "High", "Critical"});
        urgencyCombo.setFont(new Font("Arial", Font.PLAIN, 14));
        panel.add(urgencyCombo, gbc);
        row++;
        
        // Weight
        gbc.gridx = 0; gbc.gridy = row;
        panel.add(new JLabel("Weight (kg):"), gbc);
        gbc.gridx = 1;
        weightField = new JTextField(20);
        weightField.setFont(new Font("Arial", Font.PLAIN, 14));
        panel.add(weightField, gbc);
        row++;
        
        // Height
        gbc.gridx = 0; gbc.gridy = row;
        panel.add(new JLabel("Height (cm):"), gbc);
        gbc.gridx = 1;
        heightField = new JTextField(20);
        heightField.setFont(new Font("Arial", Font.PLAIN, 14));
        panel.add(heightField, gbc);
        row++;
        
        // PRA Percentage
        gbc.gridx = 0; gbc.gridy = row;
        panel.add(new JLabel("PRA Percentage:"), gbc);
        gbc.gridx = 1;
        praField = new JTextField(20);
        praField.setFont(new Font("Arial", Font.PLAIN, 14));
        panel.add(praField, gbc);
        row++;
        
        // Communicable Disease
        gbc.gridx = 0; gbc.gridy = row;
        panel.add(new JLabel("Communicable Disease:"), gbc);
        gbc.gridx = 1;
        JPanel diseasePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        diseasePanel.setBackground(Color.WHITE);
        diseaseYesButton = new JRadioButton("Yes");
        diseaseNoButton = new JRadioButton("No");
        diseaseGroup = new ButtonGroup();
        diseaseGroup.add(diseaseYesButton);
        diseaseGroup.add(diseaseNoButton);
        diseasePanel.add(diseaseYesButton);
        diseasePanel.add(diseaseNoButton);
        diseaseNoButton.setSelected(true);
        panel.add(diseasePanel, gbc);
        row++;
        
        // Diagnosis
        gbc.gridx = 0; gbc.gridy = row;
        panel.add(new JLabel("Diagnosis:"), gbc);
        gbc.gridx = 1;
        diagnosisArea = new JTextArea(4, 20);
        diagnosisArea.setFont(new Font("Arial", Font.PLAIN, 14));
        diagnosisArea.setLineWrap(true);
        diagnosisArea.setWrapStyleWord(true);
        JScrollPane diagnosisScroll = new JScrollPane(diagnosisArea);
        panel.add(diagnosisScroll, gbc);
        row++;
        
        // Medical History
        gbc.gridx = 0; gbc.gridy = row;
        panel.add(new JLabel("Medical History:"), gbc);
        gbc.gridx = 1;
        medicalHistoryArea = new JTextArea(4, 20);
        medicalHistoryArea.setFont(new Font("Arial", Font.PLAIN, 14));
        medicalHistoryArea.setLineWrap(true);
        medicalHistoryArea.setWrapStyleWord(true);
        JScrollPane historyScroll = new JScrollPane(medicalHistoryArea);
        panel.add(historyScroll, gbc);
        
        return panel;
    }
    
    private JPanel createHLAPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.WEST;
        
        int row = 0;
        
        // HLA A1
        gbc.gridx = 0; gbc.gridy = row;
        panel.add(new JLabel("HLA A1:"), gbc);
        gbc.gridx = 1;
        hlaA1Field = new JTextField(20);
        hlaA1Field.setFont(new Font("Arial", Font.PLAIN, 14));
        panel.add(hlaA1Field, gbc);
        row++;
        
        // HLA A2
        gbc.gridx = 0; gbc.gridy = row;
        panel.add(new JLabel("HLA A2:"), gbc);
        gbc.gridx = 1;
        hlaA2Field = new JTextField(20);
        hlaA2Field.setFont(new Font("Arial", Font.PLAIN, 14));
        panel.add(hlaA2Field, gbc);
        row++;
        
        // HLA B1
        gbc.gridx = 0; gbc.gridy = row;
        panel.add(new JLabel("HLA B1:"), gbc);
        gbc.gridx = 1;
        hlaB1Field = new JTextField(20);
        hlaB1Field.setFont(new Font("Arial", Font.PLAIN, 14));
        panel.add(hlaB1Field, gbc);
        row++;
        
        // HLA B2
        gbc.gridx = 0; gbc.gridy = row;
        panel.add(new JLabel("HLA B2:"), gbc);
        gbc.gridx = 1;
        hlaB2Field = new JTextField(20);
        hlaB2Field.setFont(new Font("Arial", Font.PLAIN, 14));
        panel.add(hlaB2Field, gbc);
        row++;
        
        // HLA DR1
        gbc.gridx = 0; gbc.gridy = row;
        panel.add(new JLabel("HLA DR1:"), gbc);
        gbc.gridx = 1;
        hlaDr1Field = new JTextField(20);
        hlaDr1Field.setFont(new Font("Arial", Font.PLAIN, 14));
        panel.add(hlaDr1Field, gbc);
        row++;
        
        // HLA DR2
        gbc.gridx = 0; gbc.gridy = row;
        panel.add(new JLabel("HLA DR2:"), gbc);
        gbc.gridx = 1;
        hlaDr2Field = new JTextField(20);
        hlaDr2Field.setFont(new Font("Arial", Font.PLAIN, 14));
        panel.add(hlaDr2Field, gbc);
        
        return panel;
    }
    
    private JPanel createMedicalParametersPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.WEST;
        
        int row = 0;
        
        // GFR
        gbc.gridx = 0; gbc.gridy = row;
        panel.add(new JLabel("Glomerular Filtration Rate:"), gbc);
        gbc.gridx = 1;
        gfrField = new JTextField(20);
        gfrField.setFont(new Font("Arial", Font.PLAIN, 14));
        gfrField.setToolTipText("Kidney function measurement");
        panel.add(gfrField, gbc);
        row++;
        
        // CMV
        gbc.gridx = 0; gbc.gridy = row;
        panel.add(new JLabel("CMV Serostatus:"), gbc);
        gbc.gridx = 1;
        cmvCombo = new JComboBox<>(new String[]{"Positive", "Negative", "Unknown"});
        cmvCombo.setFont(new Font("Arial", Font.PLAIN, 14));
        cmvCombo.setToolTipText("Cytomegalovirus status for matching");
        panel.add(cmvCombo, gbc);
        row++;
        
        // Liver Steatosis
        gbc.gridx = 0; gbc.gridy = row;
        panel.add(new JLabel("Liver Steatosis:"), gbc);
        gbc.gridx = 1;
        liverSteatosisCombo = new JComboBox<>(new String[]{"None", "Mild", "Moderate", "Severe"});
        liverSteatosisCombo.setFont(new Font("Arial", Font.PLAIN, 14));
        liverSteatosisCombo.setToolTipText("Liver fat content assessment");
        panel.add(liverSteatosisCombo, gbc);
        
        return panel;
    }
    
    private JPanel createBMIPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(new Color(255, 248, 240)); // Light peach background
        panel.setBorder(BorderFactory.createTitledBorder("Body Mass Index (BMI) Calculator"));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 5, 10, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.WEST;
        
        // BMI Value
        gbc.gridx = 0; gbc.gridy = 0;
        panel.add(new JLabel("BMI:"), gbc);
        gbc.gridx = 1;
        bmiValueLabel = new JLabel("--");
        bmiValueLabel.setFont(new Font("Arial", Font.BOLD, 14));
        panel.add(bmiValueLabel, gbc);
        
        // BMI Category
        gbc.gridx = 0; gbc.gridy = 1;
        panel.add(new JLabel("Category:"), gbc);
        gbc.gridx = 1;
        bmiCategoryLabel = new JLabel("--");
        bmiCategoryLabel.setFont(new Font("Arial", Font.BOLD, 14));
        panel.add(bmiCategoryLabel, gbc);
        
        // Transplant Status
        gbc.gridx = 0; gbc.gridy = 2;
        panel.add(new JLabel("Transplant Status:"), gbc);
        gbc.gridx = 1;
        bmiTransplantStatusLabel = new JLabel("--");
        bmiTransplantStatusLabel.setFont(new Font("Arial", Font.BOLD, 14));
        panel.add(bmiTransplantStatusLabel, gbc);
        
        // Calculate BMI Button
        JButton calculateBMIButton = new JButton("Calculate BMI");
        calculateBMIButton.setBackground(new Color(0, 102, 204));
        calculateBMIButton.setForeground(Color.WHITE);
        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        panel.add(calculateBMIButton, gbc);
        
        calculateBMIButton.addActionListener(e -> calculateAndDisplayBMI());
        
        // NEW: Add real-time BMI calculation as user types
        DocumentListener bmiCalculator = new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                calculateAndDisplayBMI();
            }
            @Override
            public void removeUpdate(DocumentEvent e) {
                calculateAndDisplayBMI();
            }
            @Override
            public void changedUpdate(DocumentEvent e) {
                calculateAndDisplayBMI();
            }
        };
        
        weightField.getDocument().addDocumentListener(bmiCalculator);
        heightField.getDocument().addDocumentListener(bmiCalculator);
        
        return panel;
    }
    
    // NEW: Enhanced BMI calculation with real-time updates
    private void calculateAndDisplayBMI() {
        try {
            String weightText = weightField.getText().trim();
            String heightText = heightField.getText().trim();
            
            if (!weightText.isEmpty() && !heightText.isEmpty()) {
                double weight = Double.parseDouble(weightText);
                double height = Double.parseDouble(heightText);
                
                if (height > 0 && weight > 0) {
                    // Calculate BMI
                    double heightInMeters = height / 100.0;
                    double bmi = weight / (heightInMeters * heightInMeters);
                    
                    // Update BMI value
                    bmiValueLabel.setText(String.format("%.1f", bmi));
                    
                    // Update BMI category with color coding
                    String category;
                    Color categoryColor;
                    if (bmi < 16.0) {
                        category = "Severely Underweight";
                        categoryColor = Color.RED;
                    } else if (bmi < 18.5) {
                        category = "Underweight";
                        categoryColor = Color.ORANGE;
                    } else if (bmi < 25) {
                        category = "Normal weight";
                        categoryColor = Color.GREEN;
                    } else if (bmi < 30) {
                        category = "Overweight";
                        categoryColor = Color.ORANGE;
                    } else if (bmi < 35) {
                        category = "Obese (Class I)";
                        categoryColor = Color.ORANGE;
                    } else if (bmi < 40) {
                        category = "Obese (Class II)";
                        categoryColor = Color.RED;
                    } else {
                        category = "Severely Obese";
                        categoryColor = Color.RED;
                    }
                    bmiCategoryLabel.setText(category);
                    bmiCategoryLabel.setForeground(categoryColor);
                    
                    // Update transplant status (wider range for recipients)
                    String transplantStatus;
                    Color statusColor;
                    String urgency = (String) urgencyCombo.getSelectedItem();
                    
                    if (bmi < 16.0) {
                        transplantStatus = "Severely underweight - High surgical risk";
                        statusColor = Color.RED;
                    } else if (bmi < 18.5) {
                        transplantStatus = "Underweight - Requires nutritional support";
                        statusColor = "Urgent".equals(urgency) ? Color.ORANGE : Color.RED;
                    } else if (bmi <= 30) {
                        transplantStatus = "Good candidate for transplant";
                        statusColor = Color.GREEN;
                    } else if (bmi <= 35) {
                        transplantStatus = "Overweight - Requires medical evaluation";
                        statusColor = "Urgent".equals(urgency) ? Color.ORANGE : Color.RED;
                    } else if (bmi <= 40) {
                        transplantStatus = "Obese - Higher surgical risk";
                        statusColor = "Urgent".equals(urgency) ? Color.ORANGE : Color.RED;
                    } else {
                        transplantStatus = "Severely obese - Very high surgical risk";
                        statusColor = Color.RED;
                    }
                    bmiTransplantStatusLabel.setText(transplantStatus);
                    bmiTransplantStatusLabel.setForeground(statusColor);
                    
                    return;
                }
            }
        } catch (NumberFormatException e) {
            // Ignore parsing errors - user might be typing
        }
        
        // Reset display if invalid input
        bmiValueLabel.setText("--");
        bmiCategoryLabel.setText("--");
        bmiCategoryLabel.setForeground(Color.BLACK);
        bmiTransplantStatusLabel.setText("--");
        bmiTransplantStatusLabel.setForeground(Color.BLACK);
    }
    
    // --- Rest of your existing methods remain the same ---
    public void setRecipientDetailsForEdit(Recipient recipient) {
        setTitle("Edit Recipient Registration - ID: " + recipient.getId());
        registerButton.setText("Save Changes");
        
        nameField.setText(recipient.getName());
        ageField.setText(String.valueOf(recipient.getAge()));
        if (recipient.getDateOfBirth() != null) {
             dobField.setText(new SimpleDateFormat("yyyy-MM-dd").format(recipient.getDateOfBirth()));
        }
        
        String gender = recipient.getGender();
        if ("Male".equals(gender)) maleButton.setSelected(true); 
        else if ("Female".equals(gender)) femaleButton.setSelected(true); 
        else if ("Other".equals(gender)) otherButton.setSelected(true);
        
        phoneField.setText(recipient.getPhoneNumber());
        emailField.setText(recipient.getEmail());
        addressField.setText(recipient.getAddress());

        organCombo.setSelectedItem(recipient.getOrganNeeded());
        bloodGroupCombo.setSelectedItem(recipient.getBloodGroup());
        urgencyCombo.setSelectedItem(recipient.getUrgencyLevel());
        weightField.setText(String.valueOf(recipient.getWeightKg()));
        heightField.setText(String.valueOf(recipient.getHeightCm()));
        
        diagnosisArea.setText(recipient.getDiagnosis());
        
        hlaA1Field.setText(recipient.getHla_a1());
        hlaA2Field.setText(recipient.getHla_a2());
        hlaB1Field.setText(recipient.getHla_b1());
        hlaB2Field.setText(recipient.getHla_b2());
        hlaDr1Field.setText(recipient.getHla_dr1());
        hlaDr2Field.setText(recipient.getHla_dr2());
        
        praField.setText(String.valueOf(recipient.getPraPercent()));
        
        if (recipient.isHasCommunicableDisease()) diseaseYesButton.setSelected(true);
        else diseaseNoButton.setSelected(true);
        
        medicalHistoryArea.setText(recipient.getMedicalHistory());

        if (recipient.getGlomerularFiltrationRate() > 0) {
            gfrField.setText(String.valueOf(recipient.getGlomerularFiltrationRate()));
        }
        cmvCombo.setSelectedItem(recipient.getCmvSerostatus());
        liverSteatosisCombo.setSelectedItem(recipient.getLiverSteatosis());

        calculateAndDisplayBMI();
    }
    
    private Recipient getRecipientDetails() throws ParseException, NumberFormatException {
        Recipient r = new Recipient();
        r.setName(nameField.getText());
        
        // Age is now calculated automatically from DOB
        if (!ageField.getText().isEmpty()) {
            r.setAge(Integer.parseInt(ageField.getText()));
        }
        
        r.setDateOfBirth(new SimpleDateFormat("yyyy-MM-dd").parse(dobField.getText()));
        if (maleButton.isSelected()) r.setGender("Male"); 
        else if (femaleButton.isSelected()) r.setGender("Female"); 
        else if (otherButton.isSelected()) r.setGender("Other");
        r.setPhoneNumber(phoneField.getText());
        r.setEmail(emailField.getText());
        r.setAddress(addressField.getText());
        r.setOrganNeeded((String) organCombo.getSelectedItem());
        r.setBloodGroup((String) bloodGroupCombo.getSelectedItem());
        r.setUrgencyLevel((String) urgencyCombo.getSelectedItem());
        r.setHeightCm(Double.parseDouble(heightField.getText()));
        r.setWeightKg(Double.parseDouble(weightField.getText()));
        r.setDiagnosis(diagnosisArea.getText());
        r.setHasCommunicableDisease(diseaseYesButton.isSelected());
        r.setMedicalHistory(medicalHistoryArea.getText());
        r.setPraPercent(Integer.parseInt(praField.getText()));
        r.setHla_a1(hlaA1Field.getText());
        r.setHla_a2(hlaA2Field.getText());
        r.setHla_b1(hlaB1Field.getText());
        r.setHla_b2(hlaB2Field.getText());
        r.setHla_dr1(hlaDr1Field.getText());
        r.setHla_dr2(hlaDr2Field.getText());
        
        if (!gfrField.getText().isEmpty()) {
            r.setGlomerularFiltrationRate(Double.parseDouble(gfrField.getText()));
        }
        r.setCmvSerostatus((String) cmvCombo.getSelectedItem());
        r.setLiverSteatosis((String) liverSteatosisCombo.getSelectedItem());
        
        return r;
    }
    
    public Recipient getRecipientDetails(Integer recipientId) throws ParseException, NumberFormatException {
        Recipient r = getRecipientDetails();
        if (recipientId != null) {
            r.setId(recipientId);
        }
        return r;
    }
    
    // NEW: Enhanced BMI validation for recipients
    public boolean validateBMIForTransplant() {
        try {
            double weight = Double.parseDouble(weightField.getText());
            double height = Double.parseDouble(heightField.getText());
            
            if (height > 0) {
                double heightInMeters = height / 100.0;
                double bmi = weight / (heightInMeters * heightInMeters);
                
                // Wider BMI range for recipients, especially for urgent cases
                String urgency = (String) urgencyCombo.getSelectedItem();
                if ("Urgent".equals(urgency)) {
                    return bmi >= 16.0 && bmi <= 40.0; // Wider range for urgent cases
                } else {
                    return bmi >= 18.5 && bmi <= 35.0; // Standard range for non-urgent
                }
            }
        } catch (NumberFormatException e) {
            // Invalid input
        }
        return false;
    }
    
    // NEW: Enhanced medical parameters validation for recipients
    public boolean validateMedicalParameters() {
        String selectedOrgan = (String) organCombo.getSelectedItem();
        
        // Validate GFR for kidney recipients (low GFR indicates need for transplant)
        if ("Kidney".equals(selectedOrgan)) {
            try {
                if (!gfrField.getText().isEmpty()) {
                    double gfr = Double.parseDouble(gfrField.getText());
                    if (gfr > 30) {
                        return false; // GFR too high for urgent kidney transplant
                    }
                }
            } catch (NumberFormatException e) {
                // GFR not entered or invalid
            }
        }
        
        return true;
    }
    
    // NEW: Enhanced medical assessment message
    public String getMedicalAssessmentMessage() {
        StringBuilder message = new StringBuilder();
        String selectedOrgan = (String) organCombo.getSelectedItem();
        
        if ("Kidney".equals(selectedOrgan)) {
            try {
                if (!gfrField.getText().isEmpty()) {
                    double gfr = Double.parseDouble(gfrField.getText());
                    if (gfr >= 90) {
                        message.append("Normal kidney function (GFR: ").append(gfr).append(").\n");
                    } else if (gfr >= 60) {
                        message.append("Mild kidney disease (GFR: ").append(gfr).append(").\n");
                    } else if (gfr >= 30) {
                        message.append("Moderate kidney disease (GFR: ").append(gfr).append(").\n");
                    } else if (gfr >= 15) {
                        message.append("Severe kidney disease (GFR: ").append(gfr).append(").\n");
                    } else {
                        message.append("Kidney failure (GFR: ").append(gfr).append(") - transplant indicated.\n");
                    }
                }
            } catch (NumberFormatException e) {
                message.append("GFR not provided for kidney assessment.\n");
            }
        }
        
        if ("Liver".equals(selectedOrgan)) {
            String steatosis = (String) liverSteatosisCombo.getSelectedItem();
            if ("Severe".equals(steatosis)) {
                message.append("Severe liver steatosis - transplant indicated.\n");
            } else if ("Moderate".equals(steatosis)) {
                message.append("Moderate liver steatosis - may require transplant.\n");
            } else if ("Mild".equals(steatosis)) {
                message.append("Mild liver steatosis - monitor condition.\n");
            }
        }
        
        // CMV status information
        String cmvStatus = (String) cmvCombo.getSelectedItem();
        if (cmvStatus != null && !"Unknown".equals(cmvStatus)) {
            message.append("CMV ").append(cmvStatus).append(" - ");
            if ("Negative".equals(cmvStatus)) {
                message.append("requires CMV-negative donor.\n");
            } else {
                message.append("can accept CMV-positive or negative donor.\n");
            }
        }
        
        if (message.length() == 0) {
            message.append("Medical assessment complete.");
        }
        
        return message.toString();
    }

    public void addRegisterListener(ActionListener listener) { 
        registerButton.addActionListener(listener); 
    }
    
    public void showMessage(String message, String title, int messageType) { 
        JOptionPane.showMessageDialog(this, message, title, messageType); 
    }
    
    // NEW: Get current BMI for validation messages
    public String getCurrentBMIStatus() {
        try {
            double weight = Double.parseDouble(weightField.getText());
            double height = Double.parseDouble(heightField.getText());
            
            if (height > 0) {
                double heightInMeters = height / 100.0;
                double bmi = weight / (heightInMeters * heightInMeters);
                return String.format("Current BMI: %.1f (%s)", bmi, getBMICategory(bmi));
            }
        } catch (NumberFormatException e) {
            // Invalid input
        }
        return "BMI calculation unavailable";
    }
    
    private String getBMICategory(double bmi) {
        if (bmi < 16.0) return "Severely Underweight";
        else if (bmi < 18.5) return "Underweight";
        else if (bmi < 25) return "Normal weight";
        else if (bmi < 30) return "Overweight";
        else if (bmi < 35) return "Obese (Class I)";
        else if (bmi < 40) return "Obese (Class II)";
        else return "Severely Obese";
    }
    
    // NEW: Enhanced health summary preview
    public String getHealthSummaryPreview() {
        StringBuilder summary = new StringBuilder();
        
        try {
            double weight = Double.parseDouble(weightField.getText());
            double height = Double.parseDouble(heightField.getText());
            
            if (height > 0) {
                double heightInMeters = height / 100.0;
                double bmi = weight / (heightInMeters * heightInMeters);
                
                summary.append("Organ Needed: ").append(organCombo.getSelectedItem()).append("\n");
                summary.append("Urgency: ").append(urgencyCombo.getSelectedItem()).append("\n");
                summary.append("BMI: ").append(String.format("%.1f", bmi)).append(" (").append(getBMICategory(bmi)).append(")\n");
                
                // Add new medical fields to summary
                if (!gfrField.getText().isEmpty()) {
                    double gfr = Double.parseDouble(gfrField.getText());
                    summary.append("GFR: ").append(gfr).append(" ml/min/1.73m²\n");
                }
                
                String cmvStatus = (String) cmvCombo.getSelectedItem();
                if (cmvStatus != null && !"Unknown".equals(cmvStatus)) {
                    summary.append("CMV: ").append(cmvStatus).append("\n");
                }
                
                String liverStatus = (String) liverSteatosisCombo.getSelectedItem();
                if (liverStatus != null && !"None".equals(liverStatus)) {
                    summary.append("Liver: ").append(liverStatus).append(" steatosis\n");
                }
                
                if (!praField.getText().isEmpty()) {
                    int pra = Integer.parseInt(praField.getText());
                    summary.append("PRA: ").append(pra).append("%\n");
                }
                
                summary.append("Blood Group: ").append(bloodGroupCombo.getSelectedItem());
            }
        } catch (NumberFormatException e) {
            summary.append("Complete height/weight for health summary");
        }
        
        return summary.toString();
    }
}