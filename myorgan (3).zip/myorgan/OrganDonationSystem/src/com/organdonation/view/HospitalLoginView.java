package com.organdonation.view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class HospitalLoginView extends JFrame {
    private static final long serialVersionUID = 1L;
    
    private JTextField signInEmailField;
    private JPasswordField signInPasswordField;
    private JButton loginButton;
    private JTextField registerEmailField;
    private JPasswordField registerPasswordField;
    private JTextField hospitalNameField;
    private JPasswordField confirmPasswordField;
    private JButton registerButton; 
    private JTextField pinCodeField;
    private JTextField districtField;
    private JTextField stateField;
    private JTabbedPane tabbedPane; 
    private JButton backButton;

    public HospitalLoginView() {
        setTitle("Hospital Portal Access");
        setSize(500, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout()); 
        
        confirmPasswordField = new JPasswordField(20);
        
        tabbedPane = new JTabbedPane();
        tabbedPane.setFont(new Font("Segoe UI", Font.BOLD, 14));
        
        tabbedPane.addTab("Hospital Sign In", createSignInPanel());
        tabbedPane.addTab("New Hospital Register", createRegisterPanel());

        JPanel backPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        backPanel.setBackground(new Color(240, 248, 255));
        
        backButton = new JButton("← Back to Portal Selection");
        backButton.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        backButton.setBackground(new Color(108, 117, 125));
        backButton.setForeground(Color.WHITE);
        backButton.setFocusPainted(false);
        backButton.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(90, 98, 104), 1),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        backPanel.add(backButton);

        add(backPanel, BorderLayout.NORTH);
        add(tabbedPane, BorderLayout.CENTER);
    }
    
    private JPanel createSignInPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(Color.WHITE);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.CENTER;
        
        int y = 0;

        JLabel title = new JLabel("Existing Hospital Sign In", SwingConstants.CENTER);
        title.setFont(new Font("Segoe UI", Font.BOLD, 18));
        title.setForeground(new Color(45, 118, 232));
        gbc.gridx = 0; gbc.gridy = y++; gbc.gridwidth = 2; panel.add(title, gbc);
        
        gbc.gridwidth = 1; gbc.gridx = 0; gbc.gridy = y++; panel.add(new JLabel("Email Address:"), gbc);
        signInEmailField = new JTextField(20);
        gbc.gridx = 1; panel.add(signInEmailField, gbc); 

        gbc.gridx = 0; gbc.gridy = y++; panel.add(new JLabel("Password:"), gbc);
        signInPasswordField = new JPasswordField(20);
        gbc.gridx = 1; panel.add(signInPasswordField, gbc); 

        gbc.gridx = 1; gbc.gridy = y++;
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.EAST;
        loginButton = new JButton("Sign In"); 
        styleButton(loginButton, new Color(45, 118, 232));
        panel.add(loginButton, gbc);
        
        return panel;
    }
    
    private JPanel createRegisterPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(Color.WHITE);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 10, 5, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.CENTER;
        
        int y = 0;
        
        JLabel title = new JLabel("New Hospital Registration", SwingConstants.CENTER);
        title.setFont(new Font("Segoe UI", Font.BOLD, 18));
        title.setForeground(new Color(40, 167, 69));
        gbc.gridx = 0; gbc.gridy = y++; gbc.gridwidth = 2; panel.add(title, gbc);

        gbc.gridwidth = 1; gbc.gridx = 0; gbc.gridy = y++; panel.add(new JLabel("Hospital Name:"), gbc);
        hospitalNameField = new JTextField(20);
        gbc.gridx = 1; panel.add(hospitalNameField, gbc);

        gbc.gridx = 0; gbc.gridy = y++; panel.add(new JLabel("Email Address:"), gbc);
        registerEmailField = new JTextField(20);
        gbc.gridx = 1; panel.add(registerEmailField, gbc); 

        gbc.gridx = 0; gbc.gridy = y++; panel.add(new JLabel("Password:"), gbc);
        registerPasswordField = new JPasswordField(20);
        gbc.gridx = 1; panel.add(registerPasswordField, gbc);

        gbc.gridx = 0; gbc.gridy = y++; panel.add(new JLabel("Confirm Password:"), gbc);
        gbc.gridx = 1; panel.add(confirmPasswordField, gbc);

        gbc.gridx = 0; gbc.gridy = y++; panel.add(new JLabel("PIN / Zip Code:"), gbc);
        pinCodeField = new JTextField(20);
        gbc.gridx = 1; panel.add(pinCodeField, gbc);
        
        gbc.gridx = 0; gbc.gridy = y++; panel.add(new JLabel("District:"), gbc);
        districtField = new JTextField(20);
        gbc.gridx = 1; panel.add(districtField, gbc);

        gbc.gridx = 0; gbc.gridy = y++; panel.add(new JLabel("State:"), gbc);
        stateField = new JTextField(20);
        gbc.gridx = 1; panel.add(stateField, gbc);
        
        gbc.gridx = 1; gbc.gridy = y++;
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.EAST;
        registerButton = new JButton("Register Hospital"); 
        styleButton(registerButton, new Color(40, 167, 69)); 
        panel.add(registerButton, gbc);
        
        return panel;
    }
    
    private void styleButton(JButton button, Color color) {
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(color.darker(), 1),
            BorderFactory.createEmptyBorder(8, 15, 8, 15)
        ));
    }

    public String getEmail() { return signInEmailField.getText(); }
    public String getPassword() { return new String(signInPasswordField.getPassword()); }
    public String getHospitalName() { return hospitalNameField.getText(); }
    public String getHospitalConfirmPassword() { return new String(confirmPasswordField.getPassword()); }
    public String getRegisterEmail() { return registerEmailField.getText(); }
    public String getRegisterPassword() { return new String(registerPasswordField.getPassword()); }
    public String getPinCode() { return pinCodeField.getText(); }
    public String getDistrict() { return districtField.getText(); }
    public String getHospitalState() { return stateField.getText(); }

    public void addLoginListener(ActionListener listener) {
        loginButton.addActionListener(listener);
    }	
    
    public void addRegisterHospitalListener(ActionListener listener) {
        registerButton.addActionListener(listener);
    }
    
    public void addBackListener(ActionListener listener) {
        backButton.addActionListener(listener);
    }
    
    public void showMessage(String message) {
        JOptionPane.showMessageDialog(this, message);
    }
}