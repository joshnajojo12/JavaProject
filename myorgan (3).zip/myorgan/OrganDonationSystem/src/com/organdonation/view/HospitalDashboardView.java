package com.organdonation.view;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;

public class HospitalDashboardView extends JFrame {
    private static final long serialVersionUID = 1L;
    private JButton registerDonorButton;
    private JButton registerRecipientButton;
    private JButton logoutButton;
    
    // Table Models
    public DefaultTableModel donorModel;
    public DefaultTableModel recipientModel;
    
    // Notification Bell
    private NotificationBell notificationBell;
    
    // Donor List Action Buttons and Table Reference
    private JButton deleteDonorButton;
    private JButton updateDonorStatusButton;
    private JButton editDonorButton;
    private JTable donorTable; 
    
    // Recipient List Action Buttons and Table Reference
    private JButton deleteRecipientButton;
    private JButton updateRecipientStatusButton;
    private JButton editRecipientButton; 
    private JTable recipientTable; 

    // Professional color constants
    private final Color PRIMARY_BLUE = new Color(45, 118, 232);
    private final Color DONOR_RED = new Color(220, 53, 69);
    private final Color RECIPIENT_GREEN = new Color(40, 167, 69);
    private final Color BACKGROUND_COLOR = new Color(245, 248, 250);
    private final Color CARD_WHITE = Color.WHITE;
    private final Color BORDER_COLOR = new Color(220, 220, 220);

    // Responsive dimensions
    private int originalWidth = 1200;
    private int originalHeight = 800;

    public HospitalDashboardView(String hospitalName) {
        setTitle("Hospital Dashboard - Welcome " + hospitalName);
        setSize(originalWidth, originalHeight);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));
        getContentPane().setBackground(BACKGROUND_COLOR);

        // Make window responsive
        addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                revalidate();
                repaint();
            }
        });

        createHeader(hospitalName);
        
        JTabbedPane tabbedPane = createMainContent();
        add(tabbedPane, BorderLayout.CENTER);
        
        setMinimumSize(new Dimension(900, 600)); 
    }
    
    private void createHeader(String hospitalName) {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(PRIMARY_BLUE);
        header.setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 30));
        
        JLabel title = new JLabel("Hospital Management Portal - " + hospitalName);
        title.setForeground(Color.WHITE);
        title.setFont(new Font("Segoe UI", Font.BOLD, 24));
        header.add(title, BorderLayout.WEST);
        
        JPanel rightHeaderPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        rightHeaderPanel.setOpaque(false);
        
        notificationBell = new NotificationBell();
        rightHeaderPanel.add(notificationBell);
        
        logoutButton = new JButton("Logout");
        styleLogoutButton(logoutButton);
        rightHeaderPanel.add(logoutButton);
        
        header.add(rightHeaderPanel, BorderLayout.EAST);
        add(header, BorderLayout.NORTH);
    }

    private JTabbedPane createMainContent() {
        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.setFont(new Font("Segoe UI", Font.BOLD, 14));
        
        tabbedPane.addTab("Registration & Actions", createActionPanel());
        tabbedPane.addTab("Registered Donors", createDonorListPanel());
        tabbedPane.addTab("Registered Recipients", createRecipientListPanel());
        
        return tabbedPane;
    }

    private JPanel createActionPanel() {
        // This method structure remains the same as previously defined
        JPanel mainPanel = new JPanel(new GridBagLayout());
        mainPanel.setBackground(BACKGROUND_COLOR);
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        gbc.insets = new Insets(20, 20, 20, 20);
        
        registerDonorButton = new JButton("Register New Donor");
        gbc.gridx = 0; gbc.gridy = 0;
        mainPanel.add(createPortalCard(
            "DONOR REGISTRATION", 
            "Register a new patient who wishes to become an organ donor.",
            registerDonorButton, "donor"
        ), gbc);

        registerRecipientButton = new JButton("Register New Recipient");
        gbc.gridx = 1; gbc.gridy = 0;
        mainPanel.add(createPortalCard(
            "RECIPIENT REGISTRATION", 
            "Register a new patient requiring an organ transplant.",
            registerRecipientButton, "recipient"
        ), gbc);
        
        return mainPanel;
    }
    
    // CORRECTED: Panel for Donor List with controls
    private JPanel createDonorListPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        
        String[] columns = {"ID", "Name", "Age", "Blood Group", "Organ Donating", "Status"};
        donorModel = new DefaultTableModel(columns, 0);
        donorTable = new JTable(donorModel); // Assigned to class field
        donorTable.setSelectionBackground(new Color(255, 230, 230)); 
        donorTable.setFont(new Font("Arial", Font.PLAIN, 12));
        
        panel.add(new JScrollPane(donorTable), BorderLayout.CENTER);
        
        // --- CORRECTED: Controls Panel ---
        JPanel controls = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 5));
        
        editDonorButton = new JButton("Edit Selected");
        styleButton(editDonorButton, new Color(45, 118, 232)); // Primary Blue
        controls.add(editDonorButton);
        
        updateDonorStatusButton = new JButton("Update Status");
        styleButton(updateDonorStatusButton, new Color(70, 130, 180)); // Medium Blue
        controls.add(updateDonorStatusButton);
        
        deleteDonorButton = new JButton("Delete Donor");
        styleButton(deleteDonorButton, new Color(220, 53, 69)); // Red for Delete
        controls.add(deleteDonorButton);
        
        panel.add(controls, BorderLayout.SOUTH);
        
        return panel;
    }

    // CORRECTED: Panel for Recipient List with controls
    private JPanel createRecipientListPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        
        String[] columns = {"ID", "Name", "Age", "Organ Needed", "Urgency", "Status"};
        recipientModel = new DefaultTableModel(columns, 0);
        recipientTable = new JTable(recipientModel); // Assigned to class field
        recipientTable.setSelectionBackground(new Color(230, 255, 230)); 
        recipientTable.setFont(new Font("Arial", Font.PLAIN, 12));
        
        panel.add(new JScrollPane(recipientTable), BorderLayout.CENTER);
        
        // --- CORRECTED: Controls Panel ---
        JPanel controls = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 5));
        
        editRecipientButton = new JButton("Edit Selected");
        styleButton(editRecipientButton, new Color(45, 118, 232)); // Primary Blue
        controls.add(editRecipientButton);
        
        updateRecipientStatusButton = new JButton("Update Status");
        styleButton(updateRecipientStatusButton, new Color(70, 130, 180)); // Medium Blue
        controls.add(updateRecipientStatusButton);
        
        deleteRecipientButton = new JButton("Delete Recipient");
        styleButton(deleteRecipientButton, new Color(220, 53, 69)); // Red for Delete
        controls.add(deleteRecipientButton);
        
        panel.add(controls, BorderLayout.SOUTH);
        
        return panel;
    }
    
    private JPanel createPortalCard(String title, String description, JButton button, String type) {
        // Helper method for the Action Panel (unchanged functional code)
        JPanel panel = new JPanel(new BorderLayout(15, 15));
        panel.setBackground(CARD_WHITE);
        panel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BORDER_COLOR, 1),
            BorderFactory.createEmptyBorder(25, 25, 25, 25)
        ));

        JLabel titleLabel = new JLabel(title, SwingConstants.CENTER);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 22));
        titleLabel.setForeground(PRIMARY_BLUE);
        panel.add(titleLabel, BorderLayout.NORTH);

        JTextArea descriptionArea = new JTextArea(description);
        descriptionArea.setWrapStyleWord(true);
        descriptionArea.setLineWrap(true);
        descriptionArea.setEditable(false);
        descriptionArea.setBackground(CARD_WHITE);
        panel.add(descriptionArea, BorderLayout.CENTER);
        
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.setBackground(CARD_WHITE);
        styleResponsiveButton(button, type);
        buttonPanel.add(button);
        
        panel.add(buttonPanel, BorderLayout.SOUTH);
        
        return panel;
    }
    
    // --- Helper Styling Methods (assuming full methods are in your code) ---
    private void styleResponsiveButton(JButton button, String type) { 
        // Logic to style register donor/recipient buttons
        Color buttonColor = "donor".equals(type) ? DONOR_RED : RECIPIENT_GREEN;
        button.setBackground(buttonColor);
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Segoe UI", Font.BOLD, 15));
        button.setPreferredSize(new Dimension(200, 45));
        button.setFocusPainted(false);
    }
    
    private void styleLogoutButton(JButton button) { 
        // Logic to style logout button
        button.setBackground(new Color(231, 76, 60));
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.setPreferredSize(new Dimension(100, 35));
        button.setFocusPainted(false);
    }
    
    private void styleButton(JButton button, Color color) {
        // Helper method to style buttons in the list panels
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Arial", Font.BOLD, 12));
        button.setFocusPainted(false);
    }

    // --- Getters for selected IDs and Listener Setters (Unchanged from previous step) ---
    public DefaultTableModel getDonorModel() { return donorModel; }
    public DefaultTableModel getRecipientModel() { return recipientModel; }
    public NotificationBell getNotificationBell() { return notificationBell; }

    public int getSelectedDonorId() {
        int r = donorTable.getSelectedRow();
        // Ensure table reference is not null and row is valid before accessing model
        return (donorTable != null && r >= 0) ? (int) donorModel.getValueAt(r, 0) : -1;
    }
    
    public int getSelectedRecipientId() {
        int r = recipientTable.getSelectedRow();
        // Ensure table reference is not null and row is valid before accessing model
        return (recipientTable != null && r >= 0) ? (int) recipientModel.getValueAt(r, 0) : -1;
    }

    // Registration Listeners
    public void addRegisterDonorListener(ActionListener listener) { registerDonorButton.addActionListener(listener); }
    public void addRegisterRecipientListener(ActionListener listener) { registerRecipientButton.addActionListener(listener); }
    public void addLogoutListener(ActionListener listener) { logoutButton.addActionListener(listener); }

    // Donor List Management Listeners
    public void addEditDonorListener(ActionListener listener) { editDonorButton.addActionListener(listener); }
    public void addDeleteDonorListener(ActionListener listener) { deleteDonorButton.addActionListener(listener); }
    public void addUpdateDonorStatusListener(ActionListener listener) { updateDonorStatusButton.addActionListener(listener); }
    
    // Recipient List Management Listeners
    public void addEditRecipientListener(ActionListener listener) { editRecipientButton.addActionListener(listener); }
    public void addDeleteRecipientListener(ActionListener listener) { deleteRecipientButton.addActionListener(listener); }
    public void addUpdateRecipientStatusListener(ActionListener listener) { updateRecipientStatusButton.addActionListener(listener); }
}