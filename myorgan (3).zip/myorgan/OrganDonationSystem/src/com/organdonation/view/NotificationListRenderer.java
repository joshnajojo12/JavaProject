package com.organdonation.view;

import com.organdonation.model.Notification;
import javax.swing.*;
import java.awt.*;

public class NotificationListRenderer extends DefaultListCellRenderer {

    private static final Color URGENCY_CRITICAL_BG = new Color(255, 220, 220); // Red-ish
    private static final Color URGENCY_HIGH_BG = new Color(255, 240, 210);     // Yellow-ish
    private static final Color URGENCY_MEDIUM_BG = new Color(230, 240, 255); // Blue-ish
    private static final Color URGENCY_LOW_BG = Color.WHITE;

    @Override
    public Component getListCellRendererComponent(JList<?> list, Object value, int index,
                                                  boolean isSelected, boolean cellHasFocus) {
        
        // Call the super method to get the default component and styling
        // This handles text and the blue background for selected items
        Component c = super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);

        if (value instanceof Notification) {
            Notification notification = (Notification) value;
            
            // --- THIS IS THE FIX ---
            // We must set the component to opaque for setBackground() to work
            setOpaque(true);
            // --- END FIX ---

            // Set text (HTML for line breaks)
            String text = String.format("<html><body style='width: 300px; padding: 5px;'>" +
                                        "<b>%s</b><br>%s" +
                                        "</html>",
                                        notification.getMessage(),
                                        notification.getDetails() != null ? notification.getDetails() : "");
            setText(text);

            // Set background color based on urgency *ONLY IF NOT SELECTED*
            // If it is selected, we let the super() call's blue background show
            if (!isSelected) {
                switch (notification.getUrgency()) {
                    case "critical":
                        setBackground(URGENCY_CRITICAL_BG);
                        break;
                    case "high":
                        setBackground(URGENCY_HIGH_BG);
                        break;
                    case "medium":
                    default:
                        setBackground(URGENCY_MEDIUM_BG);
                        break;
                    case "low":
                        setBackground(URGENCY_LOW_BG);
                        break;
                }
            }

        } else {
            // Reset to default for non-notification items (like "No notifications")
            setOpaque(true);
            setText(value.toString());
            if (!isSelected) {
                setBackground(Color.WHITE);
            }
        }

        return c; // 'c' is 'this', which we have modified
    }
}