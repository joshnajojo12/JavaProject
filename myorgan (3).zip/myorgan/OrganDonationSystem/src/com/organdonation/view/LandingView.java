package com.organdonation.view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class LandingView extends JFrame {
    private static final long serialVersionUID = 1L;
    
    private JButton hospitalPortalButton;
    private JButton adminPortalButton;

    public LandingView() {
        setTitle("Organ Management System - Portal Selection");
        setSize(500, 350);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setBackground(new Color(230, 245, 255));
        setLayout(new GridBagLayout()); 

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(15, 15, 15, 15);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.ipadx = 50;
        gbc.ipady = 15;
        
        JLabel titleLabel = new JLabel("Please Select Your Portal");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        add(titleLabel, gbc);
        
        hospitalPortalButton = new JButton("Hospital Portal");
        hospitalPortalButton.setFont(new Font("Segoe UI", Font.BOLD, 16));
        hospitalPortalButton.setBackground(new Color(45, 118, 232));
        hospitalPortalButton.setForeground(Color.WHITE);
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        add(hospitalPortalButton, gbc);
        
        adminPortalButton = new JButton("Admin Portal");
        adminPortalButton.setFont(new Font("Segoe UI", Font.BOLD, 16));
        adminPortalButton.setBackground(new Color(220, 53, 69));
        adminPortalButton.setForeground(Color.WHITE);
        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        add(adminPortalButton, gbc);
    }
    
    public void addHospitalPortalListener(ActionListener listener) {
        hospitalPortalButton.addActionListener(listener);
    }
    
    public void addAdminPortalListener(ActionListener listener) {
        adminPortalButton.addActionListener(listener);
    }
    
    public void showMessage(String message) {
        JOptionPane.showMessageDialog(this, message);
    }
    
    // DUMMY IMPLEMENTATIONS for compatibility
    public void addAdminLoginListener(ActionListener listener) {}
    public void addCreateHospitalListener(ActionListener listener) {}
    public void addSignInMouseListener(java.awt.event.MouseAdapter adapter) {}
    public String getAdminUsername() { return ""; }
    public String getAdminPassword() { return ""; }
    public String getHospitalName() { return ""; }
    public String getHospitalEmail() { return ""; }
    public String getHospitalPassword() { return ""; }
    public String getHospitalConfirmPassword() { return ""; }
}