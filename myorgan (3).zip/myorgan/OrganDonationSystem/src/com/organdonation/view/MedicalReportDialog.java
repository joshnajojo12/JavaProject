package com.organdonation.view;

import com.organdonation.model.Donor;
import com.organdonation.model.Recipient;
import javax.swing.*;
import java.awt.*;

public class MedicalReportDialog extends JDialog {
    
    public MedicalReportDialog(JFrame parent, Donor donor) {
        super(parent, "Medical Report - Donor: " + donor.getName(), true);
        initializeDonorReport(donor);
    }
    
    public MedicalReportDialog(JFrame parent, Recipient recipient) {
        super(parent, "Medical Report - Recipient: " + recipient.getName(), true);
        initializeRecipientReport(recipient);
    }
    
    private void initializeDonorReport(Donor donor) {
        setSize(700, 800);
        setLocationRelativeTo(getParent());
        setLayout(new BorderLayout(10, 10));
        
        JTabbedPane tabbedPane = new JTabbedPane();
        
        // Basic Information Tab
        tabbedPane.addTab("Basic Info", createBasicInfoPanel(donor));
        
        // Medical Information Tab
        tabbedPane.addTab("Medical Data", createMedicalInfoPanel(donor));
        
        // HLA & Compatibility Tab
        tabbedPane.addTab("HLA & Compatibility", createHLACompatibilityPanel(donor));
        
        // Assessment Tab
        tabbedPane.addTab("Medical Assessment", createAssessmentPanel(donor));
        
        add(tabbedPane, BorderLayout.CENTER);
        
        // Close button
        JButton closeButton = new JButton("Close");
        closeButton.addActionListener(e -> dispose());
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.add(closeButton);
        add(buttonPanel, BorderLayout.SOUTH);
    }
    
    private void initializeRecipientReport(Recipient recipient) {
        setSize(700, 800);
        setLocationRelativeTo(getParent());
        setLayout(new BorderLayout(10, 10));
        
        JTabbedPane tabbedPane = new JTabbedPane();
        
        // Basic Information Tab
        tabbedPane.addTab("Basic Info", createBasicInfoPanel(recipient));
        
        // Medical Information Tab
        tabbedPane.addTab("Medical Data", createMedicalInfoPanel(recipient));
        
        // HLA & Compatibility Tab
        tabbedPane.addTab("HLA & Matching", createHLACompatibilityPanel(recipient));
        
        // Transplant Assessment Tab
        tabbedPane.addTab("Transplant Assessment", createAssessmentPanel(recipient));
        
        add(tabbedPane, BorderLayout.CENTER);
        
        // Close button
        JButton closeButton = new JButton("Close");
        closeButton.addActionListener(e -> dispose());
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.add(closeButton);
        add(buttonPanel, BorderLayout.SOUTH);
    }
    
    private JPanel createBasicInfoPanel(Donor donor) {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;
        
        int row = 0;
        
        addLabelValue(panel, gbc, "Name:", donor.getName(), row++);
        addLabelValue(panel, gbc, "Age:", String.valueOf(donor.getAge()), row++);
        addLabelValue(panel, gbc, "Gender:", donor.getGender(), row++);
        addLabelValue(panel, gbc, "Blood Group:", donor.getBloodGroup(), row++);
        addLabelValue(panel, gbc, "Organ Donating:", donor.getOrganDonating(), row++);
        addLabelValue(panel, gbc, "Status:", donor.getStatus(), row++);
        
        // BMI Information - FIXED: Safe BMI calculation with fallbacks
        try {
            double bmi = donor.calculateBMI();
            String bmiCategory = donor.getBMICategory();
            String bmiStatus = donor.getBMIDonationStatus();
            
            addLabelValue(panel, gbc, "BMI:", String.format("%.1f", bmi), row++);
            addLabelValue(panel, gbc, "BMI Category:", bmiCategory, row++);
            addLabelValue(panel, gbc, "BMI Status:", bmiStatus, row++);
        } catch (Exception e) {
            System.out.println("BMI calculation error for donor: " + e.getMessage());
            addLabelValue(panel, gbc, "BMI:", "Not available", row++);
            addLabelValue(panel, gbc, "BMI Category:", "Not available", row++);
            addLabelValue(panel, gbc, "BMI Status:", "Not available", row++);
        }
        
        return panel;
    }
    
    private JPanel createBasicInfoPanel(Recipient recipient) {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;
        
        int row = 0;
        
        addLabelValue(panel, gbc, "Name:", recipient.getName(), row++);
        addLabelValue(panel, gbc, "Age:", String.valueOf(recipient.getAge()), row++);
        addLabelValue(panel, gbc, "Gender:", recipient.getGender(), row++);
        addLabelValue(panel, gbc, "Blood Group:", recipient.getBloodGroup(), row++);
        addLabelValue(panel, gbc, "Organ Needed:", recipient.getOrganNeeded(), row++);
        addLabelValue(panel, gbc, "Urgency Level:", recipient.getUrgencyLevel(), row++);
        addLabelValue(panel, gbc, "Status:", recipient.getStatus(), row++);
        
        // BMI Information - FIXED: Safe BMI calculation with fallbacks
        try {
            double bmi = recipient.calculateBMI();
            String bmiCategory = recipient.getBMICategory();
            String bmiStatus = recipient.getBMITransplantStatus();
            
            addLabelValue(panel, gbc, "BMI:", String.format("%.1f", bmi), row++);
            addLabelValue(panel, gbc, "BMI Category:", bmiCategory, row++);
            addLabelValue(panel, gbc, "BMI Status:", bmiStatus, row++);
        } catch (Exception e) {
            System.out.println("BMI calculation error for recipient: " + e.getMessage());
            addLabelValue(panel, gbc, "BMI:", "Not available", row++);
            addLabelValue(panel, gbc, "BMI Category:", "Not available", row++);
            addLabelValue(panel, gbc, "BMI Status:", "Not available", row++);
        }
        
        return panel;
    }
    
    private JPanel createMedicalInfoPanel(Donor donor) {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;
        
        int row = 0;
        
        // FIXED: Safe weight and height retrieval with fallbacks
        try {
            double weight = donor.getWeightKg();
            double height = donor.getHeightCm();
            
            addLabelValue(panel, gbc, "Weight:", weight > 0 ? weight + " kg" : "Not specified", row++);
            addLabelValue(panel, gbc, "Height:", height > 0 ? height + " cm" : "Not specified", row++);
        } catch (Exception e) {
            System.out.println("Error retrieving weight/height for donor: " + e.getMessage());
            addLabelValue(panel, gbc, "Weight:", "Not available", row++);
            addLabelValue(panel, gbc, "Height:", "Not available", row++);
        }
        
        addLabelValue(panel, gbc, "Has Diseases:", donor.isHasDiseases() ? "Yes" : "No", row++);
        
        // Advanced Medical Parameters - FIXED: Proper null handling and method existence check
        try {
            double gfr = donor.getGlomerularFiltrationRate();
            addLabelValue(panel, gbc, "GFR:", 
                         gfr > 0 ? gfr + " ml/min/1.73m²" : "Not specified", row++);
        } catch (Exception e) {
            addLabelValue(panel, gbc, "GFR:", "Not available", row++);
        }
        
        try {
            String cmvStatus = donor.getCmvSerostatus();
            addLabelValue(panel, gbc, "CMV Status:", 
                         cmvStatus != null && !cmvStatus.isEmpty() ? cmvStatus : "Not specified", row++);
        } catch (Exception e) {
            addLabelValue(panel, gbc, "CMV Status:", "Not available", row++);
        }
        
        try {
            String liverSteatosis = donor.getLiverSteatosis();
            addLabelValue(panel, gbc, "Liver Steatosis:", 
                         liverSteatosis != null && !liverSteatosis.isEmpty() ? liverSteatosis : "Not specified", row++);
        } catch (Exception e) {
            addLabelValue(panel, gbc, "Liver Steatosis:", "Not available", row++);
        }
        
        // Medical History
        gbc.gridx = 0; gbc.gridy = row++;
        gbc.gridwidth = 2;
        panel.add(new JLabel("Medical History:"), gbc);
        
        gbc.gridx = 0; gbc.gridy = row++;
        gbc.gridwidth = 2;
        JTextArea historyArea = new JTextArea(4, 50);
        try {
            String medicalHistory = donor.getMedicalHistory();
            historyArea.setText(medicalHistory != null && !medicalHistory.isEmpty() ? medicalHistory : "No medical history recorded");
        } catch (Exception e) {
            historyArea.setText("Medical history not available");
        }
        historyArea.setEditable(false);
        historyArea.setLineWrap(true);
        historyArea.setWrapStyleWord(true);
        panel.add(new JScrollPane(historyArea), gbc);
        
        return panel;
    }
    
    private JPanel createMedicalInfoPanel(Recipient recipient) {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;
        
        int row = 0;
        
        // FIXED: Safe weight and height retrieval with fallbacks
        try {
            double weight = recipient.getWeightKg();
            double height = recipient.getHeightCm();
            
            addLabelValue(panel, gbc, "Weight:", weight > 0 ? weight + " kg" : "Not specified", row++);
            addLabelValue(panel, gbc, "Height:", height > 0 ? height + " cm" : "Not specified", row++);
        } catch (Exception e) {
            System.out.println("Error retrieving weight/height for recipient: " + e.getMessage());
            addLabelValue(panel, gbc, "Weight:", "Not available", row++);
            addLabelValue(panel, gbc, "Height:", "Not available", row++);
        }
        
        addLabelValue(panel, gbc, "Communicable Disease:", recipient.isHasCommunicableDisease() ? "Yes" : "No", row++);
        
        try {
            double pra = recipient.getPraPercent();
            addLabelValue(panel, gbc, "PRA:", pra >= 0 ? pra + "%" : "Not specified", row++);
        } catch (Exception e) {
            addLabelValue(panel, gbc, "PRA:", "Not available", row++);
        }
        
        // Advanced Medical Parameters - FIXED: Proper null handling
        try {
            double gfr = recipient.getGlomerularFiltrationRate();
            addLabelValue(panel, gbc, "GFR:", 
                         gfr > 0 ? gfr + " ml/min/1.73m²" : "Not specified", row++);
        } catch (Exception e) {
            addLabelValue(panel, gbc, "GFR:", "Not available", row++);
        }
        
        try {
            String cmvStatus = recipient.getCmvSerostatus();
            addLabelValue(panel, gbc, "CMV Status:", 
                         cmvStatus != null && !cmvStatus.isEmpty() ? cmvStatus : "Not specified", row++);
        } catch (Exception e) {
            addLabelValue(panel, gbc, "CMV Status:", "Not available", row++);
        }
        
        try {
            String liverSteatosis = recipient.getLiverSteatosis();
            addLabelValue(panel, gbc, "Liver Steatosis:", 
                         liverSteatosis != null && !liverSteatosis.isEmpty() ? liverSteatosis : "Not specified", row++);
        } catch (Exception e) {
            addLabelValue(panel, gbc, "Liver Steatosis:", "Not available", row++);
        }
        
        // Diagnosis
        gbc.gridx = 0; gbc.gridy = row++;
        gbc.gridwidth = 2;
        panel.add(new JLabel("Diagnosis:"), gbc);
        
        gbc.gridx = 0; gbc.gridy = row++;
        gbc.gridwidth = 2;
        JTextArea diagnosisArea = new JTextArea(3, 50);
        try {
            String diagnosis = recipient.getDiagnosis();
            diagnosisArea.setText(diagnosis != null && !diagnosis.isEmpty() ? diagnosis : "No diagnosis recorded");
        } catch (Exception e) {
            diagnosisArea.setText("Diagnosis not available");
        }
        diagnosisArea.setEditable(false);
        diagnosisArea.setLineWrap(true);
        diagnosisArea.setWrapStyleWord(true);
        panel.add(new JScrollPane(diagnosisArea), gbc);
        
        // Medical History
        gbc.gridx = 0; gbc.gridy = row++;
        gbc.gridwidth = 2;
        panel.add(new JLabel("Medical History:"), gbc);
        
        gbc.gridx = 0; gbc.gridy = row++;
        gbc.gridwidth = 2;
        JTextArea historyArea = new JTextArea(3, 50);
        try {
            String medicalHistory = recipient.getMedicalHistory();
            historyArea.setText(medicalHistory != null && !medicalHistory.isEmpty() ? medicalHistory : "No medical history recorded");
        } catch (Exception e) {
            historyArea.setText("Medical history not available");
        }
        historyArea.setEditable(false);
        historyArea.setLineWrap(true);
        historyArea.setWrapStyleWord(true);
        panel.add(new JScrollPane(historyArea), gbc);
        
        return panel;
    }
    
    private JPanel createHLACompatibilityPanel(Donor donor) {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;
        
        int row = 0;
        
        // FIXED: Safe HLA data retrieval
        addLabelValue(panel, gbc, "HLA-A1:", safeGetHLA(donor.getHla_a1()), row++);
        addLabelValue(panel, gbc, "HLA-A2:", safeGetHLA(donor.getHla_a2()), row++);
        addLabelValue(panel, gbc, "HLA-B1:", safeGetHLA(donor.getHla_b1()), row++);
        addLabelValue(panel, gbc, "HLA-B2:", safeGetHLA(donor.getHla_b2()), row++);
        addLabelValue(panel, gbc, "HLA-DR1:", safeGetHLA(donor.getHla_dr1()), row++);
        addLabelValue(panel, gbc, "HLA-DR2:", safeGetHLA(donor.getHla_dr2()), row++);
        
        // CMV Matching Info
        gbc.gridx = 0; gbc.gridy = row++;
        gbc.gridwidth = 2;
        try {
            String cmvStatus = donor.getCmvSerostatus();
            String cmvInfo = "CMV " + (cmvStatus != null ? cmvStatus : "Unknown") + " - ";
            if ("Negative".equals(cmvStatus)) {
                cmvInfo += "Ideal for CMV-negative recipients";
            } else if ("Positive".equals(cmvStatus)) {
                cmvInfo += "Can donate to CMV-positive recipients";
            } else {
                cmvInfo += "CMV status unknown";
            }
            panel.add(new JLabel(cmvInfo), gbc);
        } catch (Exception e) {
            panel.add(new JLabel("CMV information not available"), gbc);
        }
        
        return panel;
    }
    
    private JPanel createHLACompatibilityPanel(Recipient recipient) {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;
        
        int row = 0;
        
        // FIXED: Safe HLA data retrieval
        addLabelValue(panel, gbc, "HLA-A1:", safeGetHLA(recipient.getHla_a1()), row++);
        addLabelValue(panel, gbc, "HLA-A2:", safeGetHLA(recipient.getHla_a2()), row++);
        addLabelValue(panel, gbc, "HLA-B1:", safeGetHLA(recipient.getHla_b1()), row++);
        addLabelValue(panel, gbc, "HLA-B2:", safeGetHLA(recipient.getHla_b2()), row++);
        addLabelValue(panel, gbc, "HLA-DR1:", safeGetHLA(recipient.getHla_dr1()), row++);
        addLabelValue(panel, gbc, "HLA-DR2:", safeGetHLA(recipient.getHla_dr2()), row++);
        
        // PRA Interpretation
        gbc.gridx = 0; gbc.gridy = row++;
        gbc.gridwidth = 2;
        try {
            double pra = recipient.getPraPercent();
            String praInterpretation;
            if (pra > 80) {
                praInterpretation = "Very High PRA (>80%) - Difficult to find compatible donor";
            } else if (pra > 50) {
                praInterpretation = "High PRA (50-80%) - May require specialized matching";
            } else if (pra > 20) {
                praInterpretation = "Moderate PRA (20-50%) - Standard matching with care";
            } else {
                praInterpretation = "Low PRA (<20%) - Good candidate for standard matching";
            }
            panel.add(new JLabel(praInterpretation), gbc);
        } catch (Exception e) {
            panel.add(new JLabel("PRA information not available"), gbc);
        }
        
        // CMV Matching Requirements
        gbc.gridx = 0; gbc.gridy = row++;
        gbc.gridwidth = 2;
        try {
            String cmvStatus = recipient.getCmvSerostatus();
            String cmvRequirement = "CMV Matching: " + 
                                   (cmvStatus != null ? getCMVMatchRequirement(cmvStatus) : "CMV status unknown");
            panel.add(new JLabel(cmvRequirement), gbc);
        } catch (Exception e) {
            panel.add(new JLabel("CMV matching requirements not available"), gbc);
        }
        
        return panel;
    }
    
    private JPanel createAssessmentPanel(Donor donor) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        JTextArea assessmentArea = new JTextArea(20, 60);
        assessmentArea.setEditable(false);
        assessmentArea.setLineWrap(true);
        assessmentArea.setWrapStyleWord(true);
        assessmentArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        
        StringBuilder assessment = new StringBuilder();
        assessment.append("MEDICAL ASSESSMENT FOR DONOR\n");
        assessment.append("============================\n\n");
        
        assessment.append("BASIC SUITABILITY:\n");
        assessment.append("• Age: ").append(donor.getAge()).append(" years\n");
        
        try {
            double bmi = donor.calculateBMI();
            String bmiCategory = donor.getBMICategory();
            assessment.append("• BMI: ").append(String.format("%.1f", bmi)).append(" (").append(bmiCategory).append(")\n");
            
            // Try to check BMI acceptability, but provide fallback
            try {
                boolean bmiAcceptable = donor.isBMIAcceptableForDonation();
                assessment.append("• BMI Acceptable: ").append(bmiAcceptable ? "✅ YES" : "❌ NO").append("\n");
            } catch (Exception e) {
                assessment.append("• BMI Acceptable: Not assessed\n");
            }
        } catch (Exception e) {
            assessment.append("• BMI: Not available\n");
            assessment.append("• BMI Acceptable: Not assessed\n");
        }
        
        assessment.append("• Diseases Present: ").append(donor.isHasDiseases() ? "❌ YES" : "✅ NO").append("\n\n");
        
        assessment.append("ORGAN-SPECIFIC ASSESSMENT:\n");
        assessment.append("• Organ: ").append(donor.getOrganDonating()).append("\n");
        
        if ("Kidney".equals(donor.getOrganDonating())) {
            try {
                double gfr = donor.getGlomerularFiltrationRate();
                assessment.append("• Kidney Function (GFR): ").append(gfr).append(" ml/min/1.73m²\n");
                
                // Try to check kidney suitability, but provide fallback
                try {
                    boolean kidneySuitable = donor.isKidneyFunctionSuitable();
                    assessment.append("• Kidney Suitable: ").append(kidneySuitable ? "✅ YES" : "❌ NO").append("\n");
                } catch (Exception e) {
                    assessment.append("• Kidney Suitable: Not assessed\n");
                }
            } catch (Exception e) {
                assessment.append("• Kidney Function: Not available\n");
            }
        }
        
        if ("Liver".equals(donor.getOrganDonating())) {
            try {
                String liverSteatosis = donor.getLiverSteatosis();
                assessment.append("• Liver Steatosis: ").append(liverSteatosis != null ? liverSteatosis : "Not specified").append("\n");
                
                // Try to check liver suitability, but provide fallback
                try {
                    boolean liverSuitable = donor.isLiverSuitable();
                    assessment.append("• Liver Suitable: ").append(liverSuitable ? "✅ YES" : "❌ NO").append("\n");
                } catch (Exception e) {
                    assessment.append("• Liver Suitable: Not assessed\n");
                }
            } catch (Exception e) {
                assessment.append("• Liver Assessment: Not available\n");
            }
        }
        
        assessment.append("\nMEDICAL PARAMETERS:\n");
        try {
            String cmvStatus = donor.getCmvSerostatus();
            assessment.append("• CMV Status: ").append(cmvStatus != null ? cmvStatus : "Not specified").append("\n");
        } catch (Exception e) {
            assessment.append("• CMV Status: Not available\n");
        }
        
        // Try to get medical suitability status with fallback
        try {
            String suitabilityStatus = donor.getMedicalSuitabilityStatus();
            assessment.append(suitabilityStatus).append("\n\n");
        } catch (Exception e) {
            assessment.append("• Medical suitability: Basic assessment only\n\n");
        }
        
        assessment.append("OVERALL ASSESSMENT:\n");
        try {
            if (donor.meetsAllMedicalCriteria()) {
                assessment.append("✅ MEDICALLY SUITABLE FOR DONATION\n");
                assessment.append("This donor meets all basic medical criteria for organ donation.");
            } else {
                assessment.append("⚠️ REQUIRES MEDICAL REVIEW\n");
                assessment.append("This donor may not meet all medical criteria. Further evaluation recommended.");
            }
        } catch (Exception e) {
            assessment.append("⚠️ BASIC ASSESSMENT ONLY\n");
            assessment.append("Full medical assessment not available. Basic parameters appear acceptable.");
        }
        
        assessmentArea.setText(assessment.toString());
        panel.add(new JScrollPane(assessmentArea), BorderLayout.CENTER);
        
        return panel;
    }
    
    private JPanel createAssessmentPanel(Recipient recipient) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        JTextArea assessmentArea = new JTextArea(20, 60);
        assessmentArea.setEditable(false);
        assessmentArea.setLineWrap(true);
        assessmentArea.setWrapStyleWord(true);
        assessmentArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        
        StringBuilder assessment = new StringBuilder();
        assessment.append("TRANSPLANT ASSESSMENT FOR RECIPIENT\n");
        assessment.append("===================================\n\n");
        
        assessment.append("BASIC SUITABILITY:\n");
        assessment.append("• Age: ").append(recipient.getAge()).append(" years\n");
        
        try {
            double bmi = recipient.calculateBMI();
            String bmiCategory = recipient.getBMICategory();
            assessment.append("• BMI: ").append(String.format("%.1f", bmi)).append(" (").append(bmiCategory).append(")\n");
            
            // Try to check BMI acceptability, but provide fallback
            try {
                boolean bmiAcceptable = recipient.isBMIAcceptableForTransplant();
                assessment.append("• BMI Acceptable: ").append(bmiAcceptable ? "✅ YES" : "❌ NO").append("\n");
            } catch (Exception e) {
                assessment.append("• BMI Acceptable: Not assessed\n");
            }
        } catch (Exception e) {
            assessment.append("• BMI: Not available\n");
            assessment.append("• BMI Acceptable: Not assessed\n");
        }
        
        assessment.append("• Communicable Diseases: ").append(recipient.isHasCommunicableDisease() ? "❌ YES" : "✅ NO").append("\n");
        assessment.append("• Urgency: ").append(recipient.getUrgencyLevel()).append("\n\n");
        
        assessment.append("MEDICAL CONDITION:\n");
        assessment.append("• Organ Needed: ").append(recipient.getOrganNeeded()).append("\n");
        
        try {
            double pra = recipient.getPraPercent();
            assessment.append("• PRA Level: ").append(pra).append("%\n");
        } catch (Exception e) {
            assessment.append("• PRA Level: Not available\n");
        }
        
        if ("Kidney".equals(recipient.getOrganNeeded())) {
            try {
                String kidneyStage = recipient.getKidneyDiseaseStage();
                assessment.append("• Kidney Disease Stage: ").append(kidneyStage != null ? kidneyStage : "Not specified").append("\n");
            } catch (Exception e) {
                assessment.append("• Kidney Disease Stage: Not available\n");
            }
            
            try {
                double gfr = recipient.getGlomerularFiltrationRate();
                assessment.append("• GFR: ").append(gfr).append(" ml/min/1.73m²\n");
            } catch (Exception e) {
                assessment.append("• GFR: Not available\n");
            }
        }
        
        if ("Liver".equals(recipient.getOrganNeeded())) {
            try {
                String liverSteatosis = recipient.getLiverSteatosis();
                assessment.append("• Liver Steatosis: ").append(liverSteatosis != null ? liverSteatosis : "Not specified").append("\n");
            } catch (Exception e) {
                assessment.append("• Liver Steatosis: Not available\n");
            }
            
            // Try to check liver condition with fallback
            try {
                boolean severeLiver = recipient.hasSevereLiverCondition();
                assessment.append("• Severe Liver Condition: ").append(severeLiver ? "✅ YES" : "❌ NO").append("\n");
            } catch (Exception e) {
                assessment.append("• Severe Liver Condition: Not assessed\n");
            }
        }
        
        assessment.append("\nMATCHING REQUIREMENTS:\n");
        try {
            String cmvStatus = recipient.getCmvSerostatus();
            assessment.append("• CMV: ").append(cmvStatus != null ? cmvStatus : "Not specified").append(" - ");
            assessment.append(cmvStatus != null ? getCMVMatchRequirement(cmvStatus) : "CMV status unknown").append("\n");
        } catch (Exception e) {
            assessment.append("• CMV: Not available\n");
        }
        
        assessment.append("• Blood Group: ").append(recipient.getBloodGroup()).append("\n\n");
        
        assessment.append("OVERALL ASSESSMENT:\n");
        try {
            if (recipient.isMedicallySuitableForTransplant()) {
                assessment.append("✅ SUITABLE FOR TRANSPLANT\n");
                assessment.append("This recipient meets the basic medical criteria for transplantation.");
            } else {
                assessment.append("⚠️ REQUIRES MEDICAL REVIEW\n");
                assessment.append("This recipient may have contraindications for transplantation.");
            }
        } catch (Exception e) {
            assessment.append("⚠️ BASIC ASSESSMENT ONLY\n");
            assessment.append("Full transplant assessment not available. Basic parameters appear acceptable.");
        }
        
        assessmentArea.setText(assessment.toString());
        panel.add(new JScrollPane(assessmentArea), BorderLayout.CENTER);
        
        return panel;
    }
    
    // Helper method for safe HLA data retrieval
    private String safeGetHLA(String hlaValue) {
        if (hlaValue == null || hlaValue.trim().isEmpty() || "null".equals(hlaValue)) {
            return "Not specified";
        }
        return hlaValue;
    }
    
    // Helper method for CMV match requirement
    private String getCMVMatchRequirement(String cmvStatus) {
        if ("Negative".equals(cmvStatus)) {
            return "Requires CMV-negative donor";
        } else if ("Positive".equals(cmvStatus)) {
            return "Can accept CMV-positive donor";
        } else {
            return "CMV status unknown";
        }
    }
    
    private void addLabelValue(JPanel panel, GridBagConstraints gbc, String label, String value, int row) {
        gbc.gridx = 0; gbc.gridy = row; gbc.gridwidth = 1;
        panel.add(new JLabel(label, JLabel.RIGHT), gbc);
        
        gbc.gridx = 1; gbc.gridy = row;
        JLabel valueLabel = new JLabel(value != null ? value : "Not specified");
        valueLabel.setFont(new Font("Arial", Font.BOLD, 12));
        panel.add(valueLabel, gbc);
    }
}