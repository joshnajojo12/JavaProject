module OrganDonationSystem {
    requires java.desktop;
    requires java.sql;
    
    exports com.organdonation.controller;
    exports com.organdonation.model;
    exports com.organdonation.view;
    
    // Add these if they exist in your dependencies
    // requires mysql.connector.j;
}